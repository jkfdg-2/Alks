-- State variables
 isLive = false
 watchingUsername = nil
 watchingSources = {}

-- Actions that require interaction check
local interactionRequiredActions = {
    "sendLiveMessage",
    "logIn",
    "toggleFollow",
    "toggleLike",
    "postComment",
    "sendMessage"
}

-- Main Instagram NUI callback handler
RegisterNUICallback("Instagram", function(data, cb)
    if not currentPhone then
        return
    end
    
    local action = data.action
    debugprint("InstaPic:", action or "")
    
    -- Check if action requires interaction
    if table.contains(interactionRequiredActions, action) then
        if not CanInteract() then
            return cb(false)
        end
    end
    
    -- Handle live streaming actions
    if action == "getLives" then
        TriggerCallback("instagram:getLives", cb)
        
    elseif action == "getLiveViewers" then
        TriggerCallback("instagram:getLiveViewers", cb, data.username)
        
    elseif action == "goLive" then
        -- Check if allowed to go live
        local canGoLive = AwaitCallback("instagram:canGoLive")
        if not canGoLive then
            debugprint("not allowed to go live")
            cb(false)
            return
        end
        debugprint("allowed to go live; setting live stream on ui")
        cb(true)
        
    elseif action == "setLive" then
        debugprint("sending server event to start livestream")
        TriggerServerEvent("phone:instagram:startLive", data.id)
        isLive = true
        EnableWalkableCam()
        
    elseif action == "endLive" then
        EndLive()
        cb(true)
        
    elseif action == "viewLive" then
        local liveData = AwaitCallback("instagram:viewLive", data.username)
        if not liveData then
            return cb(false)
        end
        
        -- Set up voice chat for live viewing
        local volume = (settings and settings.sound and settings.sound.volume) or 0.5
        watchingUsername = data.username
        
        -- Add host to watching sources
        table.insert(watchingSources, liveData.host)
        
        -- Add participants to watching sources
        for i = 1, #liveData.participants do
            table.insert(watchingSources, liveData.participants[i].source)
        end
        
        debugprint("InstaPic: adding voice targets. Volume:", volume)
        
        -- Set up Mumble voice targets
        MumbleClearVoiceTargetPlayers(1)
        for i = 1, #watchingSources do
            local source = watchingSources[i]
            MumbleAddVoiceTargetPlayerByServerId(1, source)
            MumbleSetVolumeOverrideByServerId(source, volume)
            debugprint("started listening to", source)
        end
        
        cb(#liveData.viewers)
        
    elseif action == "stopViewing" then
        AwaitCallback("instagram:stopViewing", data.username)
        
        -- Clear voice targets
        MumbleClearVoiceTargetPlayers(1)
        for i = 1, #watchingSources do
            MumbleSetVolumeOverrideByServerId(watchingSources[i], -1.0)
            debugprint("stopped listening to", watchingSources[i])
        end
        
        watchingUsername = nil
        watchingSources = {}
        
    elseif action == "sendLiveMessage" then
        TriggerServerEvent("phone:instagram:sendLiveMessage", data.data)
        
    elseif action == "addCall" then
        TriggerServerEvent("phone:instagram:addCall", data.id)
        
    elseif action == "inviteLive" then
        TriggerServerEvent("phone:instagram:inviteLive", data.username)
        
    elseif action == "removeLive" then
        TriggerServerEvent("phone:instagram:removeLive", data.username)
        
    elseif action == "joinLive" then
        local result = AwaitCallback("instagram:joinLive", data.username, data.streamId)
        cb(result)
        if not result then return end
        isLive = true
        EnableWalkableCam()
    end
    
    -- Handle story actions
    if action == "addToStory" then
        local canCreate = AwaitCallback("instagram:canCreateStory")
        if not canCreate then
            debugprint("not allowed to go create story")
            cb(false)
            return
        end
        debugprint("allowed to create story")
        TriggerCallback("instagram:addToStory", cb, data.media, data.metadata)
        
    elseif action == "removeFromStory" then
        TriggerCallback("instagram:removeFromStory", cb, data.id)
        
    elseif action == "getStories" then
        TriggerCallback("instagram:getStories", cb)
        
    elseif action == "getStory" then
        TriggerCallback("instagram:getStory", cb, data.username)
        
    elseif action == "getViewers" then
        TriggerCallback("instagram:getViewers", cb, data.id, data.page)
        
    elseif action == "viewedStory" then
        TriggerCallback("instagram:viewedStory", cb, data.id)
    end
    
    -- Handle camera actions
    if action == "flipCamera" then
        ToggleSelfieCam(not IsSelfieCam())
        
    -- Handle account actions
    elseif action == "createAccount" then
        TriggerCallback("instagram:createAccount", cb, data.name, data.username, data.password)
        
    elseif action == "changePassword" then
        TriggerCallback("instagram:changePassword", cb, data.oldPassword, data.newPassword)
        
    elseif action == "deleteAccount" then
        TriggerCallback("instagram:deleteAccount", cb, data.password)
        
    elseif action == "logIn" then
        TriggerCallback("instagram:logIn", cb, data.username, data.password)
        
    elseif action == "signOut" then
        TriggerCallback("instagram:signOut", cb)
        
    elseif action == "isLoggedIn" then
        TriggerCallback("instagram:isLoggedIn", cb)
        
    -- Handle profile actions
    elseif action == "getProfile" then
        TriggerCallback("instagram:getProfile", cb, data.username)
        
    elseif action == "updateProfile" then
        TriggerCallback("instagram:updateProfile", cb, data.data)
        
    elseif action == "getFollowers" then
        TriggerCallback("instagram:getData", cb, "followers", data.data)
        
    elseif action == "getFollowing" then
        TriggerCallback("instagram:getData", cb, "following", data.data)
        
    elseif action == "getLikes" then
        TriggerCallback("instagram:getData", cb, "likes", data.data)
        
    elseif action == "toggleFollow" then
        TriggerCallback("instagram:toggleFollow", cb, data.data.username, data.data.following)
        
    -- Handle post actions
    elseif action == "newPost" then
        TriggerCallback("instagram:createPost", cb, json.encode(data.data.images), data.data.caption, data.data.location)
        
    elseif action == "deletePost" then
        TriggerCallback("instagram:deletePost", cb, data.id)
        
    elseif action == "getPosts" then
        TriggerCallback("instagram:getPosts", cb, data.filters, data.page)
        
    elseif action == "getPost" then
        TriggerCallback("instagram:getPost", cb, data.id)
        
    elseif action == "toggleLike" then
        TriggerCallback("instagram:toggleLike", cb, data.data.postId, data.data.toggle, data.data.isComment)
        
    -- Handle comments
    elseif action == "getComments" then
        local comments = AwaitCallback("instagram:getComments", data.postId, data.page or 0)
        local formattedComments = {}
        
        for i = 1, #comments do
            local comment = comments[i]
            formattedComments[i] = {
                user = {
                    username = comment.username,
                    avatar = comment.profile_image,
                    verified = comment.verified
                },
                comment = {
                    content = comment.comment,
                    timestamp = comment.timestamp,
                    likes = comment.like_count,
                    liked = comment.liked,
                    id = comment.id
                }
            }
        end
        
        cb(formattedComments)
        
    elseif action == "postComment" then
        TriggerCallback("instagram:postComment", cb, data.data.postId, data.data.comment)
        
    -- Handle notifications
    elseif action == "getNotifications" then
        TriggerCallback("instagram:getNotifications", cb, data.page or 0)
        
    elseif action == "getFollowRequests" then
        TriggerCallback("instagram:getFollowRequests", cb, data.page or 0)
        
    elseif action == "handleFollowRequest" then
        TriggerCallback("instagram:handleFollowRequest", cb, data.username, data.accept)
    end
    
    -- Handle messages
    if action == "getRecentMessages" then
        local messages = AwaitCallback("instagram:getRecentMessages", data.page)
        
        -- Parse attachments
        for i = 1, #messages do
            local msg = messages[i]
            msg.attachments = msg.attachments and json.decode(msg.attachments)
        end
        
        cb(messages)
        
    elseif action == "getMessages" then
        local messages = AwaitCallback("instagram:getMessages", data.username, data.page)
        
        -- Parse attachments
        for i = 1, #messages do
            local msg = messages[i]
            msg.attachments = msg.attachments and json.decode(msg.attachments)
        end
        
        cb(messages)
        
    elseif action == "sendMessage" then
        TriggerCallback("instagram:sendMessage", cb, data.username, data.message)
        
    -- Handle search
    elseif action == "search" then
        TriggerCallback("instagram:search", cb, data.query)
    end
end)

-- Live streaming event handlers
RegisterNetEvent("phone:instagram:addLiveMessage", function(message)
    SendReactMessage("instagram:addMessage", message)
end)

RegisterNetEvent("phone:instagram:updateLives", function(lives)
    SendReactMessage("instagram:updateLives", lives)
end)

RegisterNetEvent("phone:instagram:endLive", function(username)
    -- If watching this live, clean up voice
    if username == watchingUsername then
        MumbleClearVoiceTargetPlayers(1)
        for i = 1, #watchingSources do
            MumbleSetVolumeOverrideByServerId(watchingSources[i], -1.0)
            debugprint("InstaPic endLive: stopped listening to", watchingSources[i])
        end
        watchingUsername = nil
        watchingSources = {}
    end
    
    SendReactMessage("instagram:liveEnded", username)
end)

RegisterNetEvent("phone:instagram:joinedLive", function(data)
    SendReactMessage("instagram:joinedLive", data)
    
    -- Don't listen to ourselves
    if data.source == GetPlayerServerId(PlayerId()) then
        return
    end
    
    -- Add new participant to voice
    table.insert(watchingSources, data.source)
    
    local volume = (settings and settings.sound and settings.sound.volume) or 0.5
    MumbleAddVoiceTargetPlayerByServerId(1, data.source)
    MumbleSetVolumeOverrideByServerId(data.source, volume)
    
    debugprint("InstaPic joinedLive: started listening to", data.source, "volume:", volume)
end)

-- Update voice volume when settings change
AddEventHandler("Danger_Phone:settingsUpdated", function()
    if not watchingUsername or #watchingSources == 0 then
        return
    end
    
    local volume = (settings and settings.sound and settings.sound.volume) or 0.5
    local myServerId = GetPlayerServerId(PlayerId())
    
    for i = 1, #watchingSources do
        local source = watchingSources[i]
        if source ~= myServerId then
            MumbleSetVolumeOverrideByServerId(source, volume)
            debugprint("InstaPic settingsUpdated: set volume to", volume, "for", source)
        end
    end
end)

RegisterNetEvent("phone:instagram:leftLive", function(host, participant, source)
    SendReactMessage("instagram:leftLive", {
        host = host,
        participant = participant
    })
    
    -- Don't process our own leave
    if source == GetPlayerServerId(PlayerId()) then
        return
    end
    
    -- Remove from voice targets
    for i = 1, #watchingSources do
        if watchingSources[i] == source then
            MumbleSetVolumeOverrideByServerId(source, -1.0)
            MumbleRemoveVoiceTargetPlayerByServerId(1, source)
            debugprint("InstaPic leftLive: stopped listening to", source)
            table.remove(watchingSources, i)
            break
        end
    end
end)

-- Other event handlers
RegisterNetEvent("phone:instagram:endCall", function(callId)
    SendReactMessage("instagram:endCall", callId)
end)

RegisterNetEvent("phone:instagram:updateViewers", function(username, viewers)
    SendReactMessage("instagram:updateViewers", {
        username = username,
        viewers = viewers
    })
end)

RegisterNetEvent("phone:instagram:updateProfileData", function(username, data, increment)
    debugprint("updateProfileData", username, data, increment)
    SendReactMessage("instagram:updateProfileData", {
        username = username,
        data = data,
        increment = increment
    })
end)

RegisterNetEvent("phone:instagram:updatePostData", function(postId, data, increment)
    debugprint("updatePostData", postId, data, increment)
    SendReactMessage("instagram:updatePostData", {
        postId = postId,
        data = data,
        increment = increment
    })
end)

RegisterNetEvent("phone:instagram:updateCommentLikes", function(commentId, increment)
    debugprint("updateCommentLikes", commentId, increment)
    SendReactMessage("instagram:updateCommentLikes", {
        commentId = commentId,
        increment = increment
    })
end)

RegisterNetEvent("phone:instagram:newMessage", function(message)
    SendReactMessage("instagram:newMessage", message)
end)

RegisterNetEvent("phone:instagram:invitedLive", function(data)
    SendReactMessage("instagram:invitedLive", data)
end)

RegisterNetEvent("phone:instagram:removedLive", function()
    EndLive()
end)

RegisterNetEvent("phone:instagram:newPost", function(post)
    TriggerEvent("Danger_Phone:instapic:newPost", post)
end)

-- End live streaming
function EndLive()
    if not isLive then
        return
    end
    
    isLive = false
    DisableWalkableCam()
    AwaitCallback("instagram:endLive")
end

-- Check if currently live
function IsLive()
    return isLive
end

-- Check if watching a live stream
function IsWatchingLive()
    return watchingUsername
end

-- Export functions
exports("IsLive", IsLive)