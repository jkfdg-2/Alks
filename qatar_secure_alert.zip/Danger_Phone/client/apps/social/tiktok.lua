-- Helper function to format video data
local function formatVideoData(video)
    -- Parse metadata
    if video.metadata then
        video.metadata = json.decode(video.metadata)
    end
    
    -- Parse and format music data
    if video.music then
        video.music = json.decode(video.music)
        
        -- Get full song information if available
        local song = Music.Songs[video.music.path]
        if song then
            local album = Music.Albums[song.album]
            
            -- Use album cover if available
            if album and album.Cover then
                song.Cover = album.Cover
            end
            
            -- Format music object
            video.music = {
                title = song.Title,
                artist = song.Artist,
                cover = song.Cover,
                volume = video.music.volume,
                path = video.music.path
            }
        end
    end
    
    -- Convert boolean values
    video.liked = video.liked == 1
    video.saved = video.saved == 1
    video.viewed = video.viewed == 1
    
    return video
end

-- Main TikTok/Trendy NUI callback handler
RegisterNUICallback("TikTok", function(data, cb)
    if not currentPhone then
        return
    end
    
    local action = data.action
    debugprint("Trendy:", action or "")
    
    -- Account management actions
    if action == "login" then
        local loginData = data.data
        TriggerCallback("tiktok:login", cb, loginData.username, loginData.password)
        
    elseif action == "signup" then
        local signupData = data.data
        TriggerCallback("tiktok:signup", cb, signupData.username, signupData.password, signupData.name)
        
    elseif action == "changePassword" then
        TriggerCallback("tiktok:changePassword", cb, data.oldPassword, data.newPassword)
        
    elseif action == "deleteAccount" then
        TriggerCallback("tiktok:deleteAccount", cb, data.password)
        
    elseif action == "logout" then
        TriggerCallback("tiktok:logout", cb)
        
    elseif action == "isLoggedIn" then
        TriggerCallback("tiktok:isLoggedIn", cb)
        
    -- Profile actions
    elseif action == "getProfile" then
        TriggerCallback("tiktok:getProfile", cb, data.username)
        
    elseif action == "updateProfile" then
        TriggerCallback("tiktok:updateProfile", cb, data.data)
        
    elseif action == "searchAccounts" then
        TriggerCallback("tiktok:searchAccounts", cb, data.query, data.page)
        
    elseif action == "toggleFollow" then
        local followData = data.data
        TriggerCallback("tiktok:toggleFollow", cb, followData.username, followData.follow)
        
    elseif action == "getFollowing" then
        TriggerCallback("tiktok:getFollowing", cb, data.username, data.page)
        
    elseif action == "getFollowers" then
        TriggerCallback("tiktok:getFollowers", cb, data.username, data.page)
        
    -- Video actions
    elseif action == "uploadVideo" then
        local uploadData = data.data
        
        -- Validate required fields
        if not uploadData.src or not uploadData.caption then
            return cb({success = false, error = "invalid_caption"})
        end
        
        -- Validate music data if provided
        if uploadData.music then
            if not uploadData.music.path or not uploadData.music.volume then
                return cb({success = false, error = "invalid_music"})
            end
            uploadData.music = json.encode(uploadData.music)
        end
        
        -- Process metadata
        if uploadData.metadata then
            if type(uploadData.metadata) == "table" then
                -- Check if table is empty
                local isEmpty = true
                for k, v in pairs(uploadData.metadata) do
                    isEmpty = false
                    break
                end
                
                if isEmpty then
                    uploadData.metadata = nil
                else
                    uploadData.metadata = json.encode(uploadData.metadata)
                end
            end
        else
            uploadData.metadata = nil
        end
        
        TriggerCallback("tiktok:uploadVideo", cb, uploadData)
        
    elseif action == "deleteVideo" then
        TriggerCallback("tiktok:deleteVideo", cb, data.id)
        
    elseif action == "togglePinnedVideo" then
        TriggerCallback("tiktok:togglePinnedVideo", cb, data.id, data.toggle)
        
    elseif action == "getVideos" then
        TriggerCallback("tiktok:getVideos", function(videos)
            -- Format each video
            for i = 1, #videos do
                videos[i] = formatVideoData(videos[i])
            end
            cb(videos)
        end, data.data, data.page or 0)
        
    elseif action == "getVideo" then
        TriggerCallback("tiktok:getVideo", function(result)
            if result.video then
                result.video = formatVideoData(result.video)
            end
            cb(result)
        end, data.id)
        
    elseif action == "setViewed" then
        TriggerServerEvent("phone:tiktok:setViewed", data.id)
        cb("ok")
        
    elseif action == "toggleLike" then
        TriggerCallback("tiktok:toggleVideoAction", cb, "like", data.id, data.toggle)
        
    elseif action == "toggleSave" then
        TriggerCallback("tiktok:toggleVideoAction", cb, "save", data.id, data.toggle)
        
    -- Comment actions
    elseif action == "postComment" then
        local commentData = data.data
        TriggerCallback("tiktok:postComment", cb, commentData.id, commentData.replyTo, commentData.comment)
        
    elseif action == "getComments" then
        local commentData = data.data
        TriggerCallback("tiktok:getComments", cb, commentData.id, commentData.replyTo, commentData.creator, data.page)
        
    elseif action == "deleteComment" then
        TriggerCallback("tiktok:deleteComment", cb, data.id, data.videoId)
        
    elseif action == "setPinnedComment" then
        TriggerCallback("tiktok:setPinnedComment", cb, data.commentId, data.videoId)
        
    elseif action == "toggleLikeComment" then
        TriggerCallback("tiktok:toggleLikeComment", cb, data.id, data.toggle)
        
    -- Message actions
    elseif action == "getRecentMessages" then
        TriggerCallback("tiktok:getRecentMessages", cb)
        
    elseif action == "getMessages" then
        TriggerCallback("tiktok:getMessages", cb, data.id, data.page)
        
    elseif action == "sendMessage" then
        -- Check if player can interact
        if not CanInteract() then
            return cb(false)
        end
        TriggerCallback("tiktok:sendMessage", cb, data.data)
        
    elseif action == "getChannelId" then
        TriggerCallback("tiktok:getChannelId", cb, data.username)
        
    -- Notification actions
    elseif action == "getNotifications" then
        TriggerCallback("tiktok:getNotifications", cb, data.page)
        
    elseif action == "getUnreadMessages" then
        TriggerCallback("tiktok:getUnreadMessages", cb)
        
    elseif action == "clearUnreadMessages" then
        TriggerServerEvent("phone:tiktok:clearUnreadMessages", data.id)
    end
end)

-- Event handlers for real-time updates
RegisterNetEvent("phone:tiktok:updateFollowers", function(username, method)
    SendReactMessage("tiktok:updateFollowers", {
        username = username,
        method = method
    })
end)

RegisterNetEvent("phone:tiktok:updateFollowing", function(username, method)
    SendReactMessage("tiktok:updateFollowing", {
        username = username,
        method = method
    })
end)

RegisterNetEvent("phone:tiktok:updateVideoStats", function(statType, videoId, method, count)
    local data = {
        id = videoId,
        method = method,
        count = count
    }
    
    if statType == "like" then
        SendReactMessage("tiktok:updateLikes", data)
    elseif statType == "save" then
        SendReactMessage("tiktok:updateSaves", data)
    elseif statType == "comment" then
        SendReactMessage("tiktok:updateComments", data)
    end
end)

RegisterNetEvent("phone:tiktok:updateCommentStats", function(statType, commentId, method)
    if statType == "reply" then
        SendReactMessage("tiktok:updateReplies", {
            id = commentId,
            method = method
        })
    elseif statType == "like" then
        SendReactMessage("tiktok:updateCommentLikes", {
            id = commentId,
            method = method
        })
    end
end)

RegisterNetEvent("phone:tiktok:receivedMessage", function(message)
    SendReactMessage("tiktok:receivedMessage", message)
end)

RegisterNetEvent("phone:tiktok:newVideo", function(video)
    TriggerEvent("Danger_Phone:trendy:newPost", video)
end)