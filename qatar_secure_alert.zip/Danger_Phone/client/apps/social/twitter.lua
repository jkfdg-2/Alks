-- Helper function to format tweet/post data
local function formatTweetData(tweet)
    if not tweet then
        return {}
    end
    
    -- Parse attachments
    local attachments = tweet.attachments
    if type(tweet.attachments) == "string" then
        attachments = json.decode(tweet.attachments)
    end
    
    -- Validate attachments format
    if attachments and (type(attachments) ~= "table" or table.type(attachments) ~= "array") then
        attachments = nil
        debugprint("Malformed attachments for birdy post", tweet.id)
    end
    
    -- Format the tweet data
    return {
        user = {
            profile_picture = tweet.profile_image,
            name = tweet.display_name,
            username = tweet.username,
            verified = tweet.verified == true,
            private = tweet.private == true
        },
        tweet = {
            id = tweet.id,
            content = tweet.content,
            date_created = tweet.timestamp,
            replies = tweet.reply_count,
            likes = tweet.like_count,
            retweets = tweet.retweet_count,
            attachments = attachments,
            replyToId = tweet.reply_to,
            liked = tweet.liked == true,
            retweeted = tweet.retweeted == true,
            replyToAuthor = tweet.replyToAuthor,
            retweetedByName = tweet.retweeted_by_display_name,
            retweetedByUsername = tweet.retweeted_by_username
        }
    }
end

-- Helper function to get tweets with optional promoted posts
local function getTweetsWithPromoted(filter, page)
    local tweets = AwaitCallback("birdy:getPosts", filter, page)
    local formattedTweets = {}
    
    -- Format all tweets
    for i = 1, #tweets do
        formattedTweets[i] = formatTweetData(tweets[i])
    end
    
    -- Insert promoted tweet if enabled
    if Config.PromoteBirdy and Config.PromoteBirdy.Enabled and #tweets > 1 then
        local promotedPost = AwaitCallback("birdy:getRandomPromoted")
        if promotedPost then
            local formattedPromoted = formatTweetData(promotedPost)
            formattedPromoted.tweet.promoted = true
            
            -- Insert at random position (3-6 or less)
            local insertPosition = math.random(3, 6)
            if insertPosition >= #formattedTweets then
                insertPosition = #formattedTweets - 1
            end
            
            table.insert(formattedTweets, insertPosition, formattedPromoted)
        end
    end
    
    return formattedTweets
end

-- Actions that require interaction check
local interactionRequiredActions = {
    "login",
    "toggleFollow",
    "toggleLike",
    "toggleRetweet",
    "sendMessage"
}

-- Main Twitter/Birdy NUI callback handler
RegisterNUICallback("Twitter", function(data, cb)
    if not currentPhone then
        return
    end
    
    local action = data.action
    debugprint("Birdy:", action or "")
    
    -- Check if action requires interaction
    if table.contains(interactionRequiredActions, action) then
        if not CanInteract() then
            return cb(false)
        end
    end
    
    -- Account management
    if action == "createAccount" then
        local accountData = data.data
        TriggerCallback("birdy:createAccount", cb, accountData.name, accountData.username, accountData.password)
        
    elseif action == "changePassword" then
        TriggerCallback("birdy:changePassword", cb, data.oldPassword, data.newPassword)
        
    elseif action == "deleteAccount" then
        TriggerCallback("birdy:deleteAccount", cb, data.password)
        
    elseif action == "login" then
        local loginData = data.data
        TriggerCallback("birdy:login", cb, loginData.username, loginData.password)
        
    elseif action == "isLoggedIn" then
        TriggerCallback("birdy:isLoggedIn", cb)
        
    elseif action == "signOut" then
        TriggerCallback("birdy:signOut", cb)
        
    -- Tweet actions
    elseif action == "sendTweet" then
        local tweetData = data.data
        TriggerCallback("birdy:sendPost", cb, tweetData.content, tweetData.attachments, tweetData.replyTo, tweetData.hashtags)
        
    elseif action == "getTweets" then
        -- Handle filter compatibility
        local filter = data.filter or data.filters
        if filter and next(filter) == nil then
            filter = nil
        end
        
        cb(getTweetsWithPromoted(filter, data.page))
        
    elseif action == "getTweet" then
        TriggerCallback("birdy:getPost", function(tweet)
            cb(formatTweetData(tweet))
        end, data.tweetId)
        
    elseif action == "deleteTweet" then
        TriggerCallback("birdy:deletePost", cb, data.tweet_id)
        
    elseif action == "promoteTweet" then
        TriggerCallback("birdy:promotePost", cb, data.tweet_id)
        
    elseif action == "pinTweet" then
        TriggerCallback("birdy:pinPost", cb, data.toggle and data.tweet_id or nil)
        
    -- Profile actions
    elseif action == "updateProfile" then
        TriggerCallback("birdy:updateProfile", cb, data.data)
        
    elseif action == "getProfile" then
        TriggerCallback("birdy:getProfile", function(profile)
            if not profile then
                debugprint("Birdy: failed to get profile", data.data.username)
                return cb()
            end
            
            -- Format pinned tweet if exists
            if profile.pinnedTweet then
                profile.pinnedTweet = formatTweetData(profile.pinnedTweet)
            end
            
            cb(profile)
        end, data.data.username)
        
    -- Search actions
    elseif action == "searchAccounts" then
        TriggerCallback("birdy:searchAccounts", function(accounts)
            local formattedAccounts = {}
            for i = 1, #accounts do
                local account = accounts[i]
                formattedAccounts[i] = {
                    username = account.username,
                    name = account.display_name,
                    profile_picture = account.profile_image,
                    verified = account.verified == true,
                    private = account.private == true
                }
            end
            cb(formattedAccounts)
        end, data.query)
        
    elseif action == "searchTweets" then
        TriggerCallback("birdy:searchTweets", function(tweets)
            local formattedTweets = {}
            for i = 1, #tweets do
                formattedTweets[i] = formatTweetData(tweets[i])
            end
            cb(formattedTweets)
        end, data.query, data.page)
        
    -- Social actions
    elseif action == "toggleFollow" then
        TriggerCallback("birdy:toggleFollow", cb, data.data.username, data.data.following)
        
    elseif action == "toggleNotifications" then
        TriggerCallback("birdy:toggleNotifications", cb, data.data.username, data.data.toggle)
        
    elseif action == "toggleLike" then
        TriggerCallback("birdy:toggleInteraction", cb, "like", data.tweet_id, data.liked)
        
    elseif action == "toggleRetweet" then
        TriggerCallback("birdy:toggleInteraction", cb, "retweet", data.tweet_id, data.retweeted)
        
    elseif action == "getAuthor" then
        TriggerCallback("birdy:getAuthor", cb, data.tweetId)
        
    -- Data lists
    elseif action == "getFollowers" then
        TriggerCallback("birdy:getData", cb, "followers", data.data.username, data.data.page)
        
    elseif action == "getFollowing" then
        TriggerCallback("birdy:getData", cb, "following", data.data.username, data.data.page)
        
    elseif action == "getLikes" then
        TriggerCallback("birdy:getData", cb, "likes", data.data.tweet_id, data.data.page)
        
    elseif action == "getRetweeters" then
        TriggerCallback("birdy:getData", cb, "retweeters", data.data.tweet_id, data.data.page)
        
    -- Messages
    elseif action == "sendMessage" then
        local messageData = data.data
        TriggerCallback("birdy:sendMessage", cb, messageData.recipient, messageData.content, messageData.attachments)
        
    elseif action == "getMessages" then
        local messageData = data.data
        TriggerCallback("birdy:getMessages", function(messages)
            -- Parse attachments
            for i = 1, #messages do
                local msg = messages[i]
                if msg.attachments then
                    msg.attachments = json.decode(msg.attachments)
                end
            end
            cb(messages)
        end, messageData.username, messageData.page)
        
    elseif action == "getRecentMessages" then
        TriggerCallback("birdy:getRecentMessages", cb, data.page)
        
    -- Notifications
    elseif action == "getNotifications" then
        TriggerCallback("birdy:getNotifications", function(result)
            -- Parse attachments in notifications
            for _, notification in pairs(result.notifications) do
                if notification.attachments then
                    notification.attachments = json.decode(notification.attachments)
                end
            end
            cb(result)
        end, data.page)
        
    -- Other features
    elseif action == "getRecentHashtags" then
        TriggerCallback("birdy:getRecentHashtags", cb)
        
    elseif action == "getFollowRequests" then
        TriggerCallback("birdy:getFollowRequests", cb, data.page or 0)
        
    elseif action == "handleFollowRequest" then
        TriggerCallback("birdy:handleFollowRequest", cb, data.username, data.accept)
    end
end)

-- Event handlers for real-time updates
RegisterNetEvent("phone:twitter:updateTweetData", function(tweetId, data, increment)
    debugprint("updateTweetData", tweetId, data, increment)
    SendReactMessage("twitter:updateTweetData", {
        tweetId = tweetId,
        data = data,
        increment = increment
    })
end)

RegisterNetEvent("phone:twitter:updateProfileData", function(username, data, increment)
    debugprint("updateProfileData", username, data, increment)
    SendReactMessage("twitter:updateProfileData", {
        username = username,
        data = data,
        increment = increment
    })
end)

RegisterNetEvent("phone:twitter:newMessage", function(message)
    SendReactMessage("twitter:newMessage", message)
end)

RegisterNetEvent("phone:twitter:newtweet", function(tweet)
    TriggerEvent("Danger_Phone:birdy:newPost", tweet)
    SendReactMessage("twitter:newTweet", formatTweetData(tweet))
end)

-- Export function to send tweets
function SendTweet(data)
    -- Validate input
    assert(type(data) == "table", "Expected table for data, got " .. type(data))
    assert(type(data.content) == "string", "Expected string for data.content, got " .. type(data.content))
    assert(type(data.attachments) == "table", "Expected table / nil for data.attachments, got " .. type(data.attachments))
    assert(type(data.replyTo) == "string", "Expected string / nil for data.replyTo, got " .. type(data.replyTo))
    assert(type(data.hashtags) == "table", "Expected table / nil for data.hashtags, got " .. type(data.hashtags))
    
    -- Check if player can interact
    if not CanInteract() then
        return
    end
    
    return AwaitCallback("birdy:sendPost", data.content, data.attachments, data.replyTo, data.hashtags)
end

-- Export the function
exports("SendTweet", SendTweet)
exports("PostBirdy", SendTweet)  -- Alternative name for compatibility