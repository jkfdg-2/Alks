-- Actions that require interaction check
local interactionRequiredActions = {
    "createAccount",
    "saveProfile",
    "sendMessage"
}

-- Main Tinder/Spark NUI callback handler
RegisterNUICallback("Tinder", function(data, cb)
    if not currentPhone then
        return
    end
    
    local action = data.action
    debugprint("Spark:", action or "")
    
    -- Check if action requires interaction
    if table.contains(interactionRequiredActions, action) then
        if not CanInteract() then
            return cb(false)
        end
    end
    
    -- Account management
    if action == "createAccount" then
        TriggerCallback("tinder:createAccount", cb, data.data)
        
    elseif action == "deleteAccount" then
        TriggerCallback("tinder:deleteAccount", cb)
        
    elseif action == "saveProfile" then
        TriggerCallback("tinder:updateAccount", cb, data.data)
        
    elseif action == "isLoggedIn" then
        local accountData = AwaitCallback("tinder:isLoggedIn")
        
        if not accountData then
            return cb(false)
        end
        
        -- Format account data for frontend
        local formattedData = {
            name = accountData.name,
            photos = json.decode(accountData.photos),
            dob = accountData.dob,
            bio = accountData.bio,
            showMen = accountData.interested_men,
            showWomen = accountData.interested_women,
            isMale = accountData.is_male,
            active = accountData.active
        }
        
        cb(formattedData)
        
    -- Feed and swiping
    elseif action == "getFeed" then
        local profiles = AwaitCallback("tinder:getFeed", data.page)
        local formattedProfiles = {}
        
        -- Format each profile
        for i = 1, #profiles do
            local profile = profiles[i]
            formattedProfiles[i] = {
                name = profile.name,
                dob = profile.dob,
                bio = profile.bio,
                photos = json.decode(profile.photos),
                number = profile.phone_number
            }
        end
        
        cb(formattedProfiles)
        
    elseif action == "swipe" then
        TriggerCallback("tinder:swipe", cb, data.number, data.like)
        
    -- Matches
    elseif action == "getMatches" then
        local matches = AwaitCallback("tinder:getMatches")
        local formattedMatches = {
            newMatches = {},
            messages = {}
        }
        
        -- Sort matches into new matches and conversations
        for i = 1, #matches do
            local match = matches[i]
            local formattedMatch = {
                name = match.name,
                number = match.phone_number,
                photos = json.decode(match.photos),
                dob = match.dob,
                bio = match.bio,
                isMale = match.is_male
            }
            
            -- Check if there's a conversation
            if match.latest_message then
                formattedMatch.lastMessage = match.latest_message
                table.insert(formattedMatches.messages, formattedMatch)
            else
                table.insert(formattedMatches.newMatches, formattedMatch)
            end
        end
        
        cb(formattedMatches)
        
    -- Messaging
    elseif action == "sendMessage" then
        local messageData = data.data
        
        -- Clean up empty attachments
        if messageData.attachments and #messageData.attachments == 0 then
            messageData.attachments = nil
        end
        
        TriggerCallback("tinder:sendMessage", cb, 
            messageData.recipient, 
            messageData.content, 
            messageData.attachments and json.encode(messageData.attachments)
        )
        
    elseif action == "getMessages" then
        local messages = AwaitCallback("tinder:getMessages", data.number, data.page)
        
        -- Parse attachments for each message
        for i = 1, #messages do
            local message = messages[i]
            if message.attachments then
                message.attachments = json.decode(message.attachments)
            else
                message.attachments = {}
            end
        end
        
        cb(messages)
    end
end)

-- Handle incoming messages
RegisterNetEvent("phone:tinder:receiveMessage", function(message)
    -- Parse attachments
    if message.attachments then
        message.attachments = json.decode(message.attachments)
    else
        message.attachments = {}
    end
    
    SendReactMessage("tinder:newMessage", message)
end)