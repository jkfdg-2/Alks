-- Actions that require interaction check
local interactionRequiredActions = {
    "sendMessage",
    "createGroup", 
    "renameGroup"
}

-- Messages NUI Callback Handler
RegisterNUICallback("Messages", function(data, cb)
    if not currentPhone then
        return
    end
    
    local action = data.action
    debugprint("Messages:" .. (action or ""))
    
    -- Check if player can interact for certain actions
    if table.contains(interactionRequiredActions, action) then
        if not CanInteract() then
            return cb(false)
        end
    end
    
    -- Handle attachments encoding
    if data.attachments and #data.attachments == 0 then
        data.attachments = nil
    elseif data.attachments then
        data.attachments = json.encode(data.attachments)
    end
    
    if action == "sendMessage" then
        TriggerServerEvent("phone:messages:messageSent", data.number, data.content, data.attachments)
        TriggerCallback("messages:sendMessage", cb, data.number, data.content, data.attachments, data.id)
        
    elseif action == "createGroup" then
        -- Extract member numbers from members array
        local memberNumbers = {}
        for i = 1, #data.members do
            memberNumbers[i] = data.members[i].number
        end
        
        TriggerCallback("messages:createGroup", cb, memberNumbers, data.content, data.attachments)
        
    elseif action == "renameGroup" then
        TriggerCallback("messages:renameGroup", cb, data.id, data.name)
        
    elseif action == "getRecentMessages" then
        local messages = AwaitCallback("messages:getRecentMessages")
        local conversations = {}
        
        -- Helper function to find existing conversation
        local function findConversation(channelId)
            for i = 1, #conversations do
                if conversations[i].id == channelId then
                    return i
                end
            end
            return false
        end
        
        -- Process messages into conversations
        for i = 1, #messages do
            local msg = messages[i]
            local existingIndex = findConversation(msg.channel_id)
            
            if not existingIndex then
                if msg.is_group then
                    -- Create new group conversation
                    table.insert(conversations, {
                        id = msg.channel_id,
                        lastMessage = msg.last_message,
                        timestamp = msg.last_message_timestamp,
                        name = msg.name,
                        isGroup = true,
                        members = {{
                            isOwner = msg.is_owner,
                            number = msg.phone_number
                        }}
                    })
                elseif msg.phone_number ~= currentPhone then
                    -- Create new direct message conversation
                    table.insert(conversations, {
                        id = msg.channel_id,
                        lastMessage = msg.last_message,
                        timestamp = msg.last_message_timestamp,
                        number = msg.phone_number,
                        isGroup = false
                    })
                end
            elseif msg.is_group then
                -- Add member to existing group
                table.insert(conversations[existingIndex].members, {
                    isOwner = msg.is_owner,
                    number = msg.phone_number
                })
            end
        end
        
        -- Add deleted and unread status for current user
        for i = 1, #messages do
            local msg = messages[i]
            local convIndex = findConversation(msg.channel_id)
            
            if convIndex and msg.phone_number == currentPhone then
                conversations[convIndex].deleted = msg.deleted
                conversations[convIndex].unread = msg.unread > 0
            end
        end
        
        cb(conversations)
        
    elseif action == "getMessages" then
        TriggerCallback("messages:getMessages", function(messages)
            -- Decode attachments for each message
            for i = 1, #messages do
                messages[i].attachments = json.decode(messages[i].attachments or "[]")
            end
            cb(messages)
        end, data.id, data.page)
        
    elseif action == "deleteMessage" then
        if Config.DeleteMessages then
            TriggerCallback("messages:deleteMessage", cb, data.id, data.channel)
        end
        
    elseif action == "addMember" then
        TriggerCallback("messages:addMember", cb, data.id, data.number)
        
    elseif action == "removeMember" then
        TriggerCallback("messages:removeMember", cb, data.id, data.number)
        
    elseif action == "leaveGroup" then
        TriggerCallback("messages:leaveGroup", cb, data.id)
        
    elseif action == "markRead" then
        TriggerCallback("messages:markRead", cb, data.id)
        
    elseif action == "deleteConversations" then
        TriggerCallback("messages:deleteConversations", cb, data.channels)
    end
end)

-- Message Event Handlers
RegisterNetEvent("phone:messages:newMessage", function(channelId, messageId, sender, content, attachments)
    SendReactMessage("messages:newMessage", {
        channelId = channelId,
        messageId = messageId,
        sender = sender,
        content = content,
        attachments = attachments and json.decode(attachments) or {}
    })
end)

RegisterNetEvent("phone:messages:messageDeleted", function(channelId, messageId, isLastMessage)
    SendReactMessage("messages:messageDeleted", {
        channelId = channelId,
        messageId = messageId,
        isLastMessage = isLastMessage
    })
end)

RegisterNetEvent("phone:messages:renameGroup", function(channelId, name)
    SendReactMessage("messages:renameGroup", {
        channelId = channelId,
        name = name
    })
end)

RegisterNetEvent("phone:messages:memberAdded", function(channelId, number)
    SendReactMessage("messages:addMember", {
        channelId = channelId,
        number = number
    })
end)

RegisterNetEvent("phone:messages:memberRemoved", function(channelId, number)
    SendReactMessage("messages:removeMember", {
        channelId = channelId,
        number = number
    })
end)

RegisterNetEvent("phone:messages:ownerChanged", function(channelId, number)
    SendReactMessage("messages:changeOwner", {
        channelId = channelId,
        number = number
    })
end)

RegisterNetEvent("phone:messages:newChannel", function(channelData)
    SendReactMessage("messages:newChannel", channelData)
end)