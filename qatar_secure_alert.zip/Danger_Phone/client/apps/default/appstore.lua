-- App Store NUI Callback Handler
RegisterNUICallback("AppStore", function(data, cb)
    -- Early return if no phone is active
    if not currentPhone then
        return
    end
    
    local action = data.action
    debugprint("AppStore:" .. (action or ""))
    
    if action == "buyApp" then
        TriggerCallback("appstore:buyApp", cb, data.price)
    end
end)