-- Map tracking state
local isTrackingPosition = false
local playerPed = PlayerPedId()
local lastPosition = vector3(0, 0, 0)

-- Add a new saved location
local function addSavedLocation(name, coordinates)
    if not name then
        return false
    end
    
    -- Use provided coordinates or get current player position
    local position = coordinates and vector2(coordinates[2], coordinates[1]) or GetEntityCoords(PlayerPedId())
    
    -- Save location to database
    local locationId = AwaitCallback("maps:addLocation", name, position.x, position.y)
    if not locationId then
        return false
    end
    
    -- Add to local saved locations
    local newLocation = {
        id = locationId,
        name = name,
        position = {position.y, position.x}
    }
    
    table.insert(SavedLocations, newLocation)
    return newLocation
end

-- Update player position tracking
local function trackPlayerPosition()
    playerPed = PlayerPedId()
    lastPosition = GetEntityCoords(playerPed)
    
    -- Send initial position
    SendReactMessage("maps:updateCoords", {
        x = math.floor(lastPosition.x + 0.5),
        y = math.floor(lastPosition.y + 0.5)
    })
    
    -- Track position changes
    while isTrackingPosition do
        local currentPosition = GetEntityCoords(playerPed)
        
        -- Only update if phone is open and player has moved more than 1 unit
        if phoneOpen and #(lastPosition - currentPosition) > 1.0 then
            lastPosition = currentPosition
            SendReactMessage("maps:updateCoords", {
                x = math.floor(currentPosition.x + 0.5),
                y = math.floor(currentPosition.y + 0.5)
            })
        end
        
        Wait(250)
    end
end

-- Maps NUI Callback Handler
RegisterNUICallback("Maps", function(data, cb)
    local action = data.action
    debugprint("Maps:" .. (action or ""))
    
    if action == "getCurrentLocation" then
        local coords = GetEntityCoords(PlayerPedId())
        cb({x = coords.x, y = coords.y})
        
    elseif action == "toggleUpdateCoords" then
        cb("ok")
        
        -- Don't do anything if state hasn't changed
        if isTrackingPosition == data.toggle then
            return
        end
        
        isTrackingPosition = data.toggle == true
        trackPlayerPosition()
        
    elseif action == "setWaypoint" then
        cb("ok")
        
        local waypoint = data.data
        local x = tonumber(waypoint.x)
        local y = tonumber(waypoint.y)
        
        if not x or not y then
            return
        end
        
        SetNewWaypoint(x / 1, y / 1)
        
    elseif action == "getLocations" then
        cb(SavedLocations)
        
    elseif action == "addLocation" then
        cb(addSavedLocation(data.name, data.location))
        
    elseif action == "renameLocation" then
        local newName = data.name
        local success = newName and AwaitCallback("maps:renameLocation", data.id, newName)
        
        if not success then
            return cb(false)
        end
        
        -- Update local saved locations
        for i = 1, #SavedLocations do
            if SavedLocations[i].id == data.id then
                SavedLocations[i].name = newName
                break
            end
        end
        
        cb(true)
        
    elseif action == "removeLocation" then
        local success = AwaitCallback("maps:removeLocation", data.id)
        
        if not success then
            return cb(false)
        end
        
        -- Remove from local saved locations
        for i = 1, #SavedLocations do
            if SavedLocations[i].id == data.id then
                table.remove(SavedLocations, i)
                break
            end
        end
        
        cb(true)
    end
end)