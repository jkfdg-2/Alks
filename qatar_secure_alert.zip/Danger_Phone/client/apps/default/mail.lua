-- Store the current mail for action handling
local currentMail = nil

-- Process mail data by decoding JSON attachments and actions
local function processMailData(mail)
    if not mail then
        return false
    end
    
    -- Decode attachments
    if not mail.attachments then
        mail.attachments = {}
    else
        mail.attachments = json.decode(mail.attachments)
    end
    
    -- Decode actions
    if not mail.actions then
        mail.actions = {}
    else
        mail.actions = json.decode(mail.actions)
    end
    
    return mail
end

-- Mail NUI Callback Handler
RegisterNUICallback("Mail", function(data, cb)
    local action = data.action
    debugprint("Mail:" .. (action or ""))
    
    if action == "isLoggedIn" then
        TriggerCallback("mail:isLoggedIn", cb)
        
    elseif action == "createMail" then
        TriggerCallback("mail:createAccount", cb, data.data.email, data.data.password)
        
    elseif action == "changePassword" then
        TriggerCallback("mail:changePassword", cb, data.oldPassword, data.newPassword)
        
    elseif action == "deleteAccount" then
        TriggerCallback("mail:deleteAccount", cb, data.password)
        
    elseif action == "login" then
        TriggerCallback("mail:login", cb, data.data.email, data.data.password)
        
    elseif action == "logout" then
        TriggerCallback("mail:logout", cb)
        
    elseif action == "getMails" then
        TriggerCallback("mail:getMails", cb, data.page)
        
    elseif action == "getMail" then
        TriggerCallback("mail:getMail", function(mail)
            currentMail = processMailData(mail)
            cb(currentMail)
        end, data.id)
        
    elseif action == "search" then
        TriggerCallback("mail:search", cb, data.query, data.page)
        
    elseif action == "sendMail" then
        TriggerCallback("mail:sendMail", cb, data.data)
        
    elseif action == "deleteMail" then
        TriggerCallback("mail:deleteMail", cb, data.id)
        
    elseif action == "action" then
        -- Validate mail ID matches
        if currentMail.id ~= data.id then
            return debugprint("wrong mail id for action")
        end
        
        -- Get the action from the mail
        local actionIndex = (data.actionId or 0) + 1
        local mailAction = currentMail.actions[actionIndex]
        
        if not mailAction or not mailAction.data then
            return debugprint("no action found", actionIndex)
        end
        
        -- Handle QB-Core legacy mail actions
        if mailAction.data.qbMail then
            TriggerEvent(mailAction.event, mailAction.data.data)
            return cb("ok")
        end
        
        -- Trigger the appropriate event
        if mailAction.isServer then
            TriggerServerEvent(mailAction.event, data.id, mailAction.data)
        else
            TriggerEvent(mailAction.event, data.id, mailAction.data)
        end
        
        cb("ok")
    end
end)

-- New mail notification event
RegisterNetEvent("phone:mail:newMail", function(mailData)
    SendReactMessage("mail:newMail", mailData)
end)

-- Mail deletion notification event
RegisterNetEvent("phone:mail:mailDeleted", function(mailId)
    SendReactMessage("mail:deleteMail", mailId)
end)