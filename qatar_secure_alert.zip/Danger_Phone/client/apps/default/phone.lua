-- Call state variables
InExportCall = false
local isVideoCall = false
local callId = nil
local isInCustomCall = false
local currentCustomCall = nil
local callStartTime = 0
local hasAnswered = false
local customNumbers = {}

-- End custom call and cleanup
local function endCustomCall()
    debugprint("EndCustomCall triggered")
    
    if currentCustomCall then
        local callDuration = math.floor((GetGameTimer() - callStartTime) / 1000 + 0.5)
        debugprint("Custom call to", currentCustomCall.number, "ended after", callDuration, "seconds", "answered:", hasAnswered)
        TriggerServerEvent("phone:logCall", currentCustomCall.number, callDuration)
    end
    
    -- Reset state
    isInCustomCall = false
    currentCustomCall = nil
    callId = nil
    callStartTime = 0
    hasAnswered = false
    
    SetPhoneAction("default")
    SendReactMessage("call:endCall")
    
    if not phoneOpen then
        PlayCloseAnim()
    end
end

-- Start a custom call
local function startCustomCall(number)
    local customNumber = customNumbers[number]
    if not customNumber then
        return false
    end
    
    local customCallId = "CUSTOM_NUMBER_" .. math.random(9999999)
    
    isInCustomCall = true
    callId = customCallId
    currentCustomCall = customNumber
    callStartTime = GetGameTimer()
    hasAnswered = false
    
    Citizen.CreateThreadNow(function()
        customNumber.onCall({
            id = customCallId,
            accept = function()
                if not hasAnswered and callId == customCallId then
                    hasAnswered = true
                    SetPhoneAction("call")
                    SendReactMessage("call:connected")
                end
            end,
            deny = function()
                if callId == customCallId then
                    endCustomCall()
                end
            end,
            setName = function(name)
                if callId == customCallId then
                    SendReactMessage("call:setContactData", {name = name})
                end
            end,
            hasEnded = function()
                return callId ~= customCallId
            end
        })
    end)
    
    return true
end

-- Handle custom call actions
local function handleCustomCallAction(action)
    if not currentCustomCall then
        return
    end
    
    if action == "end" then
        if currentCustomCall.onEnd then
            Citizen.CreateThreadNow(currentCustomCall.onEnd)
        end
        endCustomCall()
        return
    end
    
    -- Handle keypad input
    if action:find("keypad_") then
        if not currentCustomCall.onKeypad then
            return
        end
        
        local key = action:sub(8)
        if not key then
            return
        end
        
        Citizen.CreateThreadNow(function()
            currentCustomCall.onKeypad(key)
        end)
        return
    end
    
    -- Handle other actions
    if currentCustomCall.onAction then
        currentCustomCall.onAction(action)
    end
end

-- Phone NUI Callback Handler
RegisterNUICallback("Phone", function(data, cb)
    if not currentPhone then
        return
    end
    
    local action = data.action
    debugprint("Phone:" .. (action or ""))
    
    if action == "getContacts" then
        TriggerCallback("getContacts", function(contacts)
            -- Add company contacts if enabled
            if Config.Companies.Enabled then
                for company, contact in pairs(Config.Companies.Contacts) do
                    table.insert(contacts, {
                        firstname = contact.name,
                        avatar = contact.photo,
                        company = company
                    })
                end
            end
            cb(contacts)
        end)
        
    elseif action == "toggleFavourite" then
        TriggerCallback("toggleFavourite", cb, data.number, data.favourite)
        
    elseif action == "toggleBlock" then
        TriggerCallback("toggleBlock", cb, data.number, data.blocked)
        
    elseif action == "removeContact" then
        TriggerCallback("removeContact", cb, data.number)
        
    elseif action == "updateContact" then
        TriggerCallback("updateContact", cb, data.data)
        
    elseif action == "saveContact" then
        TriggerCallback("saveContact", cb, data.data)
        
    elseif action == "getRecent" then
        TriggerCallback("getRecentCalls", cb, data.missed == true, data.page)
        
    elseif action == "getBlockedNumbers" then
        TriggerCallback("getBlockedNumbers", function(blocked)
            local numbers = {}
            for _, entry in pairs(blocked) do
                table.insert(numbers, entry.number)
            end
            cb(numbers)
        end)
        
    elseif action == "toggleMute" then
        if not callId then
            return cb(false)
        elseif currentCustomCall then
            handleCustomCallAction(data.toggle and "mute" or "unmute")
            return cb(data.toggle)
        end
        
        if data.toggle then
            RemoveFromCall(callId)
        else
            AddToCall(callId)
        end
        
        TriggerServerEvent("phone:phone:toggleMute", data.toggle)
        cb(data.toggle)
        
    elseif action == "toggleSpeaker" then
        if not callId then
            return cb(false)
        elseif currentCustomCall then
            handleCustomCallAction(data.toggle and "enable_speaker" or "disable_speaker")
            return cb(data.toggle)
        end
        
        TriggerServerEvent("phone:phone:toggleSpeaker", data.toggle)
        ToggleSpeaker(data.toggle)
        cb(data.toggle)
        
    elseif action == "sendVoicemail" then
        TriggerCallback("sendVoicemail", cb, data.data)
        
    elseif action == "getVoiceMails" then
        TriggerCallback("getRecentVoicemails", cb, data.page)
        
    elseif action == "deleteVoiceMail" then
        TriggerCallback("deleteVoiceMail", cb, data.id)
        
    elseif action == "keypad" then
        cb("ok")
        if currentCustomCall then
            handleCustomCallAction("keypad_" .. data.key)
        end
        
    elseif action == "call" then
        -- Check for custom number
        if startCustomCall(data.number) then
            return cb("CUSTOM_NUMBER")
        end
        
        -- Handle company calls
        if data.company then
            if Config.Companies.Enabled and not data.videoCall then
                local validCompany = Config.Companies.Contacts[data.company]
                
                if not validCompany then
                    -- Check services
                    for i = 1, #Config.Companies.Services do
                        if Config.Companies.Services[i].job == data.company then
                            validCompany = true
                            break
                        end
                    end
                end
                
                if not validCompany then
                    return
                end
            else
                return
            end
        end
        
        isVideoCall = data.videoCall
        TriggerCallback("call", cb, data)
        
    elseif action == "answerCall" then
        if IsInCall() then
            debugprint("answerCall: Already in call")
            return
        end
        
        -- End any active live streams
        if IsLive() then
            debugprint("answerCall: Ending live")
            TriggerCallback("instagram:endLive")
        elseif IsWatchingLive() then
            debugprint("answerCall: Leaving live")
            SendReactMessage("instagram:liveEnded", IsWatchingLive())
        end
        
        debugprint("Answering call", data.callId)
        TriggerCallback("answerCall", cb, data.callId)
        cb("ok")
        
    elseif action == "endCall" then
        EndCall()
        cb("ok")
        
    elseif action == "flipCamera" then
        ToggleSelfieCam(not IsSelfieCam())
        
    elseif action == "requestVideoCall" then
        TriggerCallback("requestVideoCall", cb, data.callId, data.peerId)
        
    elseif action == "answerVideoRequest" then
        TriggerCallback("answerVideoRequest", cb, data.callId, data.accept)
        if data.accept then
            isVideoCall = true
            EnableWalkableCam()
        end
        
    elseif action == "stopVideoCall" then
        TriggerCallback("stopVideoCall", cb, data.callId)
    end
end)

-- End the current call
function EndCall()
    TriggerServerEvent("phone:endCall")
    if currentCustomCall then
        handleCustomCallAction("end")
    end
end

-- Phone Event Handlers
RegisterNetEvent("phone:phone:setCall", function(call)
    -- Validation checks
    if not HasPhoneItem(currentPhone) then
        debugprint("no phone, not showing call")
        return
    end
    
    if phoneDisabled then
        debugprint("phone is disabled, not showing call")
        return
    end
    
    if currentCustomCall or isInCustomCall then
        debugprint("in a (custom?) call", tostring(currentCustomCall), tostring(isInCustomCall))
        return
    end
    
    if IsPedDeadOrDying(PlayerPedId(), false) then
        debugprint("player is dead, not showing call")
        return
    elseif CanOpenPhone and not CanOpenPhone() then
        debugprint("can't open phone, not showing call")
        return
    end
    
    isVideoCall = call.videoCall
    SendReactMessage("incomingCall", call)
end)

RegisterNetEvent("phone:phone:enableExportCall", function()
    InExportCall = true
end)

RegisterNetEvent("phone:phone:connectCall", function(id, skipAction)
    debugprint("phone:phone:connectCall", id, skipAction)
    
    isInCustomCall = true
    callId = id
    AddToCall(id)
    
    if skipAction then
        return
    end
    
    SetPhoneAction("call")
    SendReactMessage("call:connected")
    
    if isVideoCall then
        EnableWalkableCam()
    end
end)

RegisterNetEvent("phone:phone:endCall", function()
    debugprint("phone:phone:endCall")
    
    local wasInCall = isInCustomCall
    isInCustomCall = false
    isVideoCall = false
    
    SetPhoneAction("default")
    DisableWalkableCam()
    
    if not phoneOpen and wasInCall then
        debugprint("close anim")
        PlayCloseAnim()
    end
    
    RemoveFromCall(callId)
    callId = nil
    InExportCall = false
    
    SendReactMessage("call:endCall")
end)

RegisterNetEvent("phone:phone:userUnavailable", function()
    debugprint("phone:phone:userUnavailable")
    SendReactMessage("call:userUnavailable")
end)

RegisterNetEvent("phone:phone:userBusy", function()
    debugprint("phone:phone:userBusy")
    SendReactMessage("call:userBusy")
end)

-- Export functions
function IsInCall()
    return isInCustomCall
end

exports("IsInCall", IsInCall)

exports("AddContact", function(contact)
    assert(type(contact) == "table", "contact must be a table")
    assert(type(contact.number) == "string", "contact.number must be a string")
    assert(type(contact.firstname) == "string", "contact.firstname must be a string")
    
    local success = AwaitCallback("saveContact", contact)
    if success then
        SendReactMessage("phone:contactAdded", contact)
    end
    return success
end)

-- Video call event handlers
RegisterNetEvent("phone:phone:videoRequested", function(data)
    debugprint("phone:phone:videoRequested", data)
    SendReactMessage("call:videoRequested", data)
end)

RegisterNetEvent("phone:phone:videoRequestAnswered", function(accepted)
    debugprint("phone:phone:videoRequestAnswered", accepted)
    SendReactMessage("call:videoRequestAnswered", accepted)
    
    if accepted then
        isVideoCall = true
        EnableWalkableCam()
    end
end)

RegisterNetEvent("phone:phone:stopVideoCall", function()
    debugprint("phone:phone:stopVideoCall")
    SendReactMessage("call:stopVideoCall")
    isVideoCall = false
    DisableWalkableCam()
end)

RegisterNetEvent("phone:phone:contactAdded", function(contact)
    debugprint("phone:phone:contactAdded", contact)
    SendReactMessage("phone:contactAdded", contact)
end)

-- Create a call programmatically
function CreateCall(options)
    assert(type(options) == "table", "options must be a table")
    assert(options.number or options.company, "options must contain either a number or company")
    
    if not currentPhone then
        return debugprint("no phone")
    end
    
    if options.company then
        if not Config.Companies.Enabled then
            return debugprint("company calls are disabled in config")
        end
        
        local validCompany = false
        local companyName = options.company
        
        -- Check contacts
        if Config.Companies.Contacts[options.company] then
            companyName = Config.Companies.Contacts[options.company].name
            validCompany = true
        else
            -- Check services
            for i = 1, #Config.Companies.Services do
                local service = Config.Companies.Services[i]
                if service.job == options.company then
                    validCompany = true
                    companyName = service.name
                    break
                end
            end
        end
        
        if not validCompany then
            return debugprint("invalid company")
        end
        
        debugprint("CreateCall: company", options)
        SendReactMessage("call", {
            company = options.company,
            companylabel = companyName,
            hideCallerId = options.hideNumber == true
        })
    else
        debugprint("CreateCall: number", options)
        SendReactMessage("call", {
            number = options.number,
            videoCall = options.videoCall == true,
            hideCallerId = options.hideNumber == true
        })
    end
end

exports("CreateCall", CreateCall)

-- Custom number management
exports("CreateCustomNumber", function(number, data)
    local resource = GetInvokingResource()
    
    assert(type(number) == "string", "number must be a string")
    assert(type(data) == "table", "data must be a table")
    assert(type(data.onCall) == "function", "data.onCall must be a function")
    
    if customNumbers[number] then
        return false, "Number already exists"
    end
    
    customNumbers[number] = {
        resource = resource,
        number = number,
        onCall = data.onCall,
        onEnd = data.onEnd,
        onAction = data.onAction,
        onKeypad = data.onKeypad
    }
    
    return true
end)

exports("RemoveCustomNumber", function(number)
    local resource = GetInvokingResource()
    
    assert(type(number) == "string", "number must be a string")
    
    if not customNumbers[number] then
        return false, "Number does not exist"
    end
    
    if customNumbers[number].resource ~= resource then
        return false, "Number was not created by " .. resource
    end
    
    customNumbers[number] = nil
    return true
end)

exports("EndCustomCall", function()
    if currentCustomCall then
        endCustomCall()
        return true
    end
    return false
end)

-- Clean up custom numbers when resources stop
AddEventHandler("onResourceStop", function(resource)
    if resource == GetCurrentResourceName() then
        return
    end
    
    for number, data in pairs(customNumbers) do
        if data.resource == resource then
            debugprint("Removed custom number", number, "due to resource stopping")
            
            if currentCustomCall == data then
                handleCustomCallAction("end")
            end
            
            customNumbers[number] = nil
        end
    end
end)