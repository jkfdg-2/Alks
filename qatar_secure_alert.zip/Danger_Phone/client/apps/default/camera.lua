-- Camera state variables
local cameraOpen = false
local isSelfieMode = false
local isVideoMode = false
local isHudHidden = false
local recordingPeerId = nil
local baseUrl = nil

-- Album type mappings
local albumTypes = {
    selfies = "selfie",
    screenshots = "screenshot",
    imports = "import"
}

-- Initialize camera mode
local function initializeCameraMode()
    CreateMobilePhone(0)
    CellCamActivate(true, true)
    Citizen.InvokeNative(0x2494A456D6C7FB15, isSelfieMode)
    
    -- Clean up any nearby phone objects
    SetTimeout(500, function()
        local objects = GetGamePool("CObject")
        local playerCoords = GetEntityCoords(PlayerPedId())
        
        for i = 1, #objects do
            local obj = objects[i]
            local objCoords = GetEntityCoords(obj)
            
            if #(playerCoords - objCoords) < 4.0 then
                if GetEntityModel(obj) == 413312110 then
                    SetEntityAsMissionEntity(obj, true, true)
                    DeleteObject(obj)
                end
            end
        end
    end)
    
    -- Keep camera active while open
    while phoneOpen and cameraOpen and not IsWalkingCamEnabled() do
        Wait(250)
        InvalidateIdleCam()
        InvalidateVehicleIdleCam()
    end
    
    DestroyMobilePhone()
    
    -- Reinitialize if camera is still open but phone was closed
    if cameraOpen and not IsWalkingCamEnabled() then
        while not phoneOpen do
            Wait(500)
        end
        initializeCameraMode()
    end
end

-- Display camera control tips
local function showCameraTips()
    if not isHudHidden and Config.Camera and Config.Camera.ShowTip ~= false then
        local tips = {}
        
        -- Build tips based on available keybinds
        if Config.KeyBinds.TakePhoto and Config.KeyBinds.TakePhoto.Command then
            table.insert(tips, L("BACKEND.CAMERA.TAKE_PHOTO", {
                key = Config.KeyBinds.TakePhoto.bindData.instructional
            }))
        end
        
        if Config.KeyBinds.FlipCamera and Config.KeyBinds.FlipCamera.Command then
            table.insert(tips, L("BACKEND.CAMERA.FLIP_CAMERA", {
                key = Config.KeyBinds.FlipCamera.bindData.instructional
            }))
        end
        
        if Config.KeyBinds.ToggleFlash and Config.KeyBinds.ToggleFlash.Command then
            table.insert(tips, L("BACKEND.CAMERA.TOGGLE_FLASH", {
                key = Config.KeyBinds.ToggleFlash.bindData.instructional
            }))
        end
        
        if Config.KeyBinds.LeftMode and Config.KeyBinds.LeftMode.Command and
           Config.KeyBinds.RightMode and Config.KeyBinds.RightMode.Command then
            table.insert(tips, L("BACKEND.CAMERA.CHANGE_MODE", {
                key = Config.KeyBinds.LeftMode.bindData.instructional,
                key2 = Config.KeyBinds.RightMode.bindData.instructional
            }))
        end
        
        if Config.KeyBinds.RollLeft and Config.KeyBinds.RollLeft.Command and
           Config.KeyBinds.RollRight and Config.KeyBinds.RollRight.Command then
            table.insert(tips, L("BACKEND.CAMERA.ROLL", {
                key = Config.KeyBinds.RollLeft.bindData.instructional,
                key2 = Config.KeyBinds.RollRight.bindData.instructional
            }))
        end
        
        if Config.Camera and Config.Camera.Freeze and Config.Camera.Freeze.Enabled and
           Config.KeyBinds.FreezeCamera and Config.KeyBinds.FreezeCamera.Command then
            table.insert(tips, L("BACKEND.CAMERA.FREEZE", {
                key = Config.KeyBinds.FreezeCamera.bindData.instructional
            }))
        end
        
        if Config.KeyBinds.Focus and Config.KeyBinds.Focus.Command then
            table.insert(tips, L("BACKEND.CAMERA.TOGGLE_CURSOR", {
                key = Config.KeyBinds.Focus.bindData.instructional
            }))
        end
        
        -- Display tips if any exist
        if #tips > 0 then
            local tipText = table.concat(tips, "\n")
            AddTextEntry("CAMERA_TIP2", tipText)
            BeginTextCommandDisplayHelp("CAMERA_TIP2")
            EndTextCommandDisplayHelp(0, true, true, 0)
        end
    end
end

-- Process image filter parameters
local function processImageFilter(filter)
    -- Convert special album names
    if filter.album == "recents" then
        filter.album = nil
    elseif filter.album == "favourites" then
        filter.album = nil
        filter.favourites = true
    end
    
    -- Handle video type filter
    if filter.type == "videos" then
        return {
            showPhotos = false,
            showVideos = true
        }
    end
    
    -- Handle other type filters
    if filter.type then
        filter.album = nil
        if albumTypes[filter.type] then
            filter.type = albumTypes[filter.type]
        else
            filter.type = nil
            filter.duplicates = true
        end
    end
    
    -- Set default show options
    if not filter.showPhotos and not filter.showVideos then
        filter.showPhotos = true
        filter.showVideos = true
    end
    
    return filter
end

-- Get upload configuration for a specific type
local function getUploadConfig(uploadType)
    local config = nil
    
    if CustomGetUploadMethod then
        config = CustomGetUploadMethod(uploadType)
    else
        local uploadMethods = UploadMethods[Config.UploadMethod[uploadType]]
        if not uploadMethods then
            infoprint("error", "Upload methods not found for " .. uploadType)
            return
        end
        
        config = uploadMethods[uploadType] or uploadMethods.Default
        if not config then
            infoprint("error", "Upload method not found for " .. uploadType)
            return
        end
    end
    
    -- Set method if not specified
    if not config.method then
        config.method = Config.UploadMethod[uploadType]
    end
    
    -- Add player data if needed
    if config.sendPlayer and not config.player then
        config.player = {
            identifier = GetIdentifier(),
            name = GetPlayerName(PlayerId())
        }
    end
    
    -- Replace BASE_URL placeholder
    if config.url:find("BASE_URL") then
        if not baseUrl then
            baseUrl = AwaitCallback("camera:getBaseUrl")
        end
        config.url = config.url:gsub("BASE_URL", baseUrl)
    end
    
    -- Handle API_KEY placeholder
    local needsApiKey = false
    if config.url:find("API_KEY") then
        needsApiKey = true
    else
        if config.headers then
            for _, header in pairs(config.headers) do
                if header:find("API_KEY") then
                    needsApiKey = true
                    break
                end
            end
        end
    end
    
    if needsApiKey then
        local apiKey = AwaitCallback("camera:getUploadApiKey", uploadType)
        config.url = config.url:gsub("API_KEY", apiKey)
        
        if config.headers then
            for key, value in pairs(config.headers) do
                config.headers[key] = value:gsub("API_KEY", apiKey)
            end
        end
    end
    
    -- Handle PRESIGNED_URL placeholder
    if config.url:find("PRESIGNED_URL") then
        local presignedUrl = AwaitCallback("camera:getPresignedUrl", uploadType)
        if not presignedUrl then
            infoprint("error", "Failed to get presigned url for " .. uploadType)
            return
        end
        config.presignedUrl = config.url:gsub("PRESIGNED_URL", presignedUrl)
    end
    
    return config
end

-- Camera NUI Callback Handler
RegisterNUICallback("Camera", function(data, cb)
    if not currentPhone then
        return
    end
    
    if not data then
        return debugprint("Camera data is nil")
    end
    
    local action = data.action
    debugprint("Camera:" .. (action or ""))
    
    if action == "open" then
        cb("ok")
        cameraOpen = true
        showCameraTips()
        
        if Config.Camera and Config.Camera.Enabled then
            EnableWalkableCam()
        else
            initializeCameraMode()
        end
        
    elseif action == "saveToGallery" then
        TriggerCallback("camera:saveToGallery", cb, data.link, data.size, 
                       data.isVideo and true or false, data.type, data.shouldLog)
        
    elseif action == "deleteFromGallery" then
        if type(data.ids) ~= "table" then
            data.ids = {data.ids}
        end
        TriggerCallback("camera:deleteFromGallery", cb, data.ids)
        
    elseif action == "getLastImage" then
        TriggerCallback("camera:getLastImage", cb)
        
    elseif action == "getImages" then
        local filter = processImageFilter(data.filter or {})
        local images = AwaitCallback("camera:getImages", filter, data.page or 0)
        
        local formattedImages = {}
        for i = 1, #images do
            local image = images[i]
            formattedImages[i] = {
                id = image.id,
                src = image.link,
                isVideo = image.is_video,
                type = image.metadata,
                favourite = image.is_favourite,
                timestamp = image.timestamp,
                size = image.size or 0
            }
        end
        
        cb(formattedImages)
        
    elseif action == "getAlbums" then
        TriggerCallback("camera:getHomePageData", cb)
        
    elseif action == "createAlbum" then
        TriggerCallback("camera:createAlbum", cb, data.title)
        
    elseif action == "renameAlbum" then
        TriggerCallback("camera:renameAlbum", cb, data.id, data.title)
        
    elseif action == "addToAlbum" then
        TriggerCallback("camera:addToAlbum", cb, data.album, data.ids)
        
    elseif action == "removeFromAlbum" then
        TriggerCallback("camera:removeFromAlbum", cb, data.album, data.ids)
        
    elseif action == "deleteAlbum" then
        TriggerCallback("camera:deleteAlbum", cb, data.id)
        
    elseif action == "removeMemberFromAlbum" then
        TriggerCallback("camera:removeMemberFromAlbum", cb, data.number, data.album)
        
    elseif action == "leaveSharedAlbum" then
        TriggerCallback("camera:leaveSharedAlbum", cb, data.id)
        
    elseif action == "getAlbumMembers" then
        TriggerCallback("camera:getAlbumMembers", cb, data.id)
        
    elseif action == "toggleFavourites" then
        TriggerCallback("camera:toggleFavourites", cb, data.favourite, data.ids)
        
    elseif action == "toggleVideo" then
        if isVideoMode == data.toggled then
            return cb("ok")
        end
        
        isVideoMode = data.toggled
        cameraOpen = true
        cb("ok")
        
        SendReactMessage("camera:toggleMicrophone", IsTalking())
        
        if isVideoMode or (Config.Camera and Config.Camera.Enabled) then
            EnableWalkableCam(isSelfieMode)
        else
            DisableWalkableCam()
            initializeCameraMode()
        end
        
    elseif action == "toggleHud" then
        isHudHidden = not data.toggled
        TriggerEvent("Danger_Phone:toggleHud", isHudHidden)
        
        SetTimeout(100, function()
            cb(true)
        end)
        
        while isHudHidden do
            Wait(0)
            HideHudComponents()
        end
        
    elseif action == "getUploadApi" then
        cb(getUploadConfig(data.uploadType) or false)
        
    elseif action == "toggleLandscape" then
        local phone = GetPhoneObject()
        local ped = PlayerPedId()
        
        if not DoesEntityExist(phone) then
            return
        end
        
        if data.toggled then
            AttachEntityToEntity(phone, ped, GetPedBoneIndex(ped, 28422),
                -0.03, -0.005, -0.02, 0.0, 90.0, 180.0,
                false, false, false, false, 2, true)
        else
            AttachEntityToEntity(phone, ped, GetPedBoneIndex(ped, 28422),
                0.0, -0.005, 0.0, 0.0, 0.0, 180.0,
                false, false, false, false, 2, true)
        end
        
        cb("ok")
        
    elseif action == "flipCamera" then
        data.value = data.value == true
        
        if isSelfieMode == data.value then
            return cb("ok")
        end
        
        isSelfieMode = data.value
        
        if IsWalkingCamEnabled() then
            ToggleSelfieCam(isSelfieMode)
        else
            Citizen.InvokeNative(0x2494A456D6C7FB15, isSelfieMode)
        end
        
        cb("ok")
        
    elseif action == "setQuickZoom" then
        if IsWalkingCamEnabled() then
            SetCameraZoom(data.value)
        end
        cb(true)
        
    elseif action == "setRecordingPeerId" then
        TriggerServerEvent("phone:camera:setPeer", data.peerId)
        recordingPeerId = data.peerId
        cb("ok")
        
    elseif action == "endedRecording" then
        if recordingPeerId then
            TriggerServerEvent("phone:camera:endedRecording", recordingPeerId)
            recordingPeerId = nil
            cb("ok")
        end
        
    elseif action == "close" then
        cameraOpen = false
        isVideoMode = false
        isSelfieMode = false
        ClearAllHelpMessages()
        ClearHelp(true)
        DisableWalkableCam()
        cb("ok")
    end
end)

-- Export function to save media to gallery
exports("SaveToGallery", function(link)
    assert(type(link) == "string", "Expected string for link, got " .. type(link))
    SendReactMessage("saveMedia", link)
end)

-- Album member management events
RegisterNetEvent("phone:photos:addMemberToAlbum", function(albumId, phoneNumber)
    SendReactMessage("photos:addMemberToAlbum", {
        albumId = albumId,
        phoneNumber = phoneNumber
    })
end)

RegisterNetEvent("phone:photos:removeMemberFromAlbum", function(albumId, phoneNumber)
    SendReactMessage("photos:removeMemberFromAlbum", {
        albumId = albumId,
        phoneNumber = phoneNumber
    })
end)

RegisterNetEvent("phone:photos:addSharedAlbum", function(albumData)
    SendReactMessage("photos:addSharedAlbum", albumData)
end)

RegisterNetEvent("phone:photos:updateAlbum", function(albumData)
    debugprint("phone:photos:updateAlbum", albumData)
    SendReactMessage("photos:updateAlbum", albumData)
end)