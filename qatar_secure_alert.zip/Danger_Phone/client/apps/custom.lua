-- Callbacks storage
local callbacks = {}
local colorOptions = {
    blue = true,
    red = true,
    green = true,
    yellow = true
}

-- Generate unique callback ID
local function generateCallbackId()
    local id = math.random(999999999)
    while callbacks[id] do
        id = math.random(999999999)
    end
    return id
end

-- Custom App Handler
RegisterNUICallback("CustomApp", function(data, cb)
    local appName = data.app
    local action = data.action
    cb("ok")
    
    if not action or not appName then
        debugprint("invalid data")
        return
    end
    
    local customApp = Config.CustomApps[appName]
    
    if action == "open" then
        -- Trigger server event if needed
        if customApp and customApp.onServerUse then
            TriggerServerEvent("Danger_Phone:customApp", appName)
        end
        
        -- Close phone if app has no UI and doesn't keep phone open
        if customApp and not customApp.ui and not customApp.keepOpen then
            debugprint("Closing phone due to custom app without ui")
            ToggleOpen(false)
        end
        
        -- Execute onUse callback
        if customApp and customApp.onUse then
            Citizen.CreateThreadNow(function()
                customApp.onUse()
            end)
        end
        
        -- Execute onOpen callback
        if customApp and customApp.onOpen then
            Citizen.CreateThreadNow(function()
                customApp.onOpen()
            end)
        end
        
    elseif action == "close" then
        if customApp and customApp.onClose then
            customApp.onClose()
        end
        
    elseif action == "install" then
        if customApp and customApp.onInstall then
            customApp.onInstall()
        end
        
    elseif action == "uninstall" then
        if customApp and customApp.onDelete then
            customApp.onDelete()
        end
    end
end)

-- Popup Handler
RegisterNUICallback("PopUp", function(data, cb)
    if not callbacks[data] then
        return
    end
    
    cb("ok")
    callbacks[data]()
    callbacks[data] = nil
end)

-- Popup Input Change Handler
RegisterNUICallback("PopUpInputChanged", function(data, cb)
    local id = data.id
    local value = data.value
    
    if not callbacks[id] then
        return
    end
    
    cb("ok")
    callbacks[id](value)
end)

-- Set Popup
local function setPopup(data, isExport)
    assert(data.buttons and #data.buttons > 0, "You need at least one button")
    
    for _, button in pairs(data.buttons) do
        assert(button.title, "You need a title for each button")
        assert(colorOptions[button.color or "blue"], "Invalid color")
        
        if isExport == true then
            if button.cb then
                local callbackId = generateCallbackId()
                local originalCb = button.cb
                callbacks[callbackId] = function()
                    originalCb(button.callbackId)
                end
                button.cb = callbackId
            end
        else
            if button.callbackId then
                local callbackId = generateCallbackId()
                callbacks[callbackId] = function()
                    isExport(button.callbackId)
                end
                button.cb = callbackId
            end
        end
    end
    
    -- Handle input onChange callback
    local input = data.input
    if input and input.onChange then
        local callbackId = generateCallbackId()
        
        if isExport == true then
            callbacks[callbackId] = input.onChange
        else
            callbacks[callbackId] = function(value)
                SendReactMessage("customApp:sendMessage", {
                    identifier = "any",
                    message = {
                        type = "popUpInputChanged",
                        value = value
                    }
                })
            end
        end
        
        input.onChange = callbackId
    end
    
    SendReactMessage("onComponentUse", {
        type = "popup",
        data = data
    })
end

RegisterNUICallback("SetPopUp", setPopup)
exports("SetPopUp", function(data)
    setPopup(data, true)
end)

-- Context Menu Handler
RegisterNUICallback("ContextMenu", function(data, cb)
    if not callbacks[data] then
        return
    end
    
    callbacks[data]()
    callbacks[data] = nil
    cb("ok")
end)

-- Set Context Menu
local function setContextMenu(data, isExport)
    assert(data.buttons and #data.buttons > 0, "You need at least one button")
    
    for _, button in pairs(data.buttons) do
        assert(button.title, "You need a title for each button")
        assert(colorOptions[button.color or "blue"], "Invalid colour")
        
        if isExport == true then
            assert(button.cb, "You need a callback for each button")
        else
            assert(button.callbackId, "You need a callback for each button")
        end
        
        local callbackId = generateCallbackId()
        local originalCb = button.cb
        
        callbacks[callbackId] = function()
            if isExport == true then
                originalCb()
            else
                isExport(button.callbackId)
            end
        end
        
        button.cb = callbackId
    end
    
    SendReactMessage("onComponentUse", {
        type = "contextmenu",
        data = data
    })
end

RegisterNUICallback("SetContextMenu", setContextMenu)
exports("SetContextMenu", function(data)
    setContextMenu(data, true)
end)

-- Camera Component
local function setCameraComponent(data, callback)
    if type(data) ~= "table" or not data then
        data = {}
    end
    
    local promise = nil
    local wasPhoneOpen = phoneOpen
    data.id = generateCallbackId()
    
    -- Open phone if not already open
    if not wasPhoneOpen then
        debugprint("Opening phone due to camera component")
        ToggleOpen(true)
    end
    
    -- Create promise if no callback provided
    if not callback then
        promise = promise.new()
    end
    
    -- Set up callback
    callbacks[data.id] = function(result)
        if callback then
            callback(result.url)
        else
            promise:resolve(result.url)
        end
        
        -- Close phone if it wasn't open before
        if not wasPhoneOpen then
            debugprint("Closing phone due to camera component")
            ToggleOpen(false)
        end
    end
    
    SendReactMessage("onComponentUse", {
        type = "camera",
        data = data
    })
    
    -- Return promise result if no callback
    if not callback then
        return Citizen.Await(promise)
    end
end

exports("SetCameraComponent", setCameraComponent)

-- Contact Modal
local function setContactModal(phoneNumber)
    assert(phoneNumber, "You need to provide a phone number")
    
    SendReactMessage("onComponentUse", {
        type = "contactmodal",
        data = phoneNumber
    })
end

RegisterNUICallback("SetContactModal", function(data, cb)
    setContactModal(data)
    cb("ok")
end)

exports("SetContactModal", setContactModal)

-- Component Types and Properties
local componentProperties = {
    gallery = {"image"},
    gif = {"gif"},
    emoji = {"emoji"},
    camera = {"url"},
    colorpicker = {"color"},
    contactselector = {"contact"}
}

-- Component Usage Handler
RegisterNUICallback("UsedComponent", function(data, cb)
    local id = data and data.id
    
    if not id or not callbacks[id] then
        return
    end
    
    callbacks[id](data)
    callbacks[id] = nil
    cb("ok")
end)

-- Show Component
local function showComponent(data, callback)
    local component = data.component
    
    assert(component, "You need to specify a component")
    assert(componentProperties[component], "Invalid component")
    
    local callbackId = generateCallbackId()
    
    callbacks[callbackId] = function(result)
        local args = {}
        for _, prop in pairs(componentProperties[component]) do
            table.insert(args, result[prop])
        end
        callback(table.unpack(args))
    end
    
    data.id = callbackId
    
    SendReactMessage("onComponentUse", {
        type = component,
        data = data
    })
end

RegisterNUICallback("ShowComponent", showComponent)
exports("ShowComponent", showComponent)

-- Call Creation
RegisterNUICallback("CreateCall", function(data, cb)
    CreateCall(data)
    cb("ok")
end)

-- Settings
RegisterNUICallback("GetSettings", function(data, cb)
    cb(settings)
end)

-- Locale
RegisterNUICallback("GetLocale", function(data, cb)
    cb(L(data.path, data.format))
end)

-- Notifications
RegisterNUICallback("SendNotification", function(data, cb)
    TriggerEvent("phone:sendNotification", data)
    cb(true)
end)