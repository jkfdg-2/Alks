if Config.HouseScript ~= "Danger_housing" then
    return
end

RegisterNUICallback("Home", function(data, cb)
    local action = data.action
    debugprint("Danger_housing - Home:" .. (action or ""))

    if action == "getHomes" then
        local ownedHouses = exports.Danger_housing:GetOwnedHouses()
        local toSend = {}

        for _, v in pairs(ownedHouses) do
            if v then
                toSend[#toSend+1] = {
                    label = v.label .. " (" .. v.uniqueId .. ")",
                    id = v.id,
                    uniqueId = v.uniqueId,
                    locked = AwaitCallback("home:getLocked", v.id, v.uniqueId),
                    keyholders = v.keyHolders
                }
            end
        end

        cb(toSend)
    elseif action == "removeKeyholder" then
        cb(exports.Danger_housing:RemoveKeyHolder(data.id, data.identifier))
    elseif action == "addKeyholder" then
        if exports.Danger_housing:GiveKey(data.id, tonumber(data.source)) then
            SetTimeout(500, function()
                cb(exports.Danger_housing:GetKeyHolders(data.id))
            end)
        end
    elseif action == "toggleLocked" then
        local locked = AwaitCallback("home:toggleLocked", data.id, data.uniqueId)

        cb(locked)
    elseif action == "setWaypoint" then
        exports.Danger_housing:MarkProperty(data.id)
        cb(true)
    end
end)
