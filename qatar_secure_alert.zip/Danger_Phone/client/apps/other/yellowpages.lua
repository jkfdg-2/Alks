-- Yellow Pages NUI Callback Handler
RegisterNUICallback("YellowPages", function(data, cb)
    local action = data.action
    debugprint("Pages:" .. (action or ""))
    
    if action == "getPosts" then
        TriggerCallback("yellowPages:getPosts", cb, data.page, {
            search = data.query
        })
        
    elseif action == "sendPost" then
        TriggerCallback("yellowPages:createPost", cb, data.data)
        
    elseif action == "deletePost" then
        TriggerCallback("yellowPages:deletePost", cb, data.id)
    end
end)

-- Yellow Pages New Post Event Handler
RegisterNetEvent("phone:yellowPages:newPost", function(postData)
    TriggerEvent("Danger_Phone:pages:newPost", postData)
    SendReactMessage("yellowPages:newPost", postData)
end)