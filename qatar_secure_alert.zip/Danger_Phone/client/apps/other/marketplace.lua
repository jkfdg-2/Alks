-- Marketplace NUI Callback Handler
RegisterNUICallback("MarketPlace", function(data, cb)
    local action = data.action
    debugprint("MarketPlace:" .. (action or ""))
    
    if action == "getPosts" then
        local posts = AwaitCallback("marketplace:getPosts", data)
        
        -- Decode attachments for each post
        for i = 1, #posts do
            posts[i].attachments = json.decode(posts[i].attachments)
        end
        
        cb(posts)
        
    elseif action == "sendPost" then
        TriggerCallback("marketplace:createPost", cb, data.data)
        
    elseif action == "deletePost" then
        TriggerCallback("marketplace:deletePost", cb, data.id)
    end
end)

-- Marketplace New Post Event Handler
RegisterNetEvent("phone:marketplace:newPost", function(postData)
    TriggerEvent("Danger_Phone:marketplace:newPost", postData)
    SendReactMessage("marketPlace:newPost", postData)
end)