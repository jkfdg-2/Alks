-- Main DarkChat NUI callback handler
RegisterNUICallback("DarkChat", function(data, cb)
    if not currentPhone then
        return
    end
    
    local action = data.action
    debugprint("DarkChat:", action or "")
    
    -- Account management actions
    if action == "getUsername" then
        TriggerCallback("darkchat:getUsername", cb)
        
    elseif action == "setPassword" then
        TriggerCallback("darkchat:setPassword", cb, data.password)
        
    elseif action == "login" then
        TriggerCallback("darkchat:login", cb, data.username, data.password)
        
    elseif action == "logout" then
        TriggerCallback("darkchat:logout", cb)
        
    elseif action == "changePassword" then
        TriggerCallback("darkchat:changePassword", cb, data.oldPassword, data.newPassword)
        
    elseif action == "deleteAccount" then
        TriggerCallback("darkchat:deleteAccount", cb, data.password)
        
    elseif action == "register" then
        TriggerCallback("darkchat:register", cb, data.username, data.password)
        
    -- Channel actions
    elseif action == "getChannels" then
        TriggerCallback("darkchat:getChannels", cb)
        
    elseif action == "joinChannel" then
        TriggerCallback("darkchat:joinChannel", cb, data.channel)
        
    elseif action == "leaveChannel" then
        TriggerCallback("darkchat:leaveChannel", cb, data.channel)
        
    -- Message actions
    elseif action == "getMessages" then
        TriggerCallback("darkchat:getMessages", cb, data.channel, data.page)
        
    elseif action == "sendMessage" then
        TriggerCallback("darkchat:sendMessage", cb, data.channel, data.content)
    end
end)

-- Handle new message event
RegisterNetEvent("phone:darkChat:newMessage", function(channel, sender, content)
    SendReactMessage("darkChat:newMessage", {
        channel = channel,
        sender = sender,
        content = content
    })
end)

-- Handle channel update event
RegisterNetEvent("phone:darkChat:updateChannel", function(channel, username, updateAction)
    SendReactMessage("darkChat:updateChannel", {
        action = updateAction,
        channel = channel,
        username = username
    })
end)