-- Get and format playlists from the database
local function getFormattedPlaylists()
    local rawPlaylists = AwaitCallback("music:getPlaylists")
    local playlists = {}
    local processedIds = {}
    
    for i = 1, #rawPlaylists do
        local playlist = rawPlaylists[i]
        
        -- Create new playlist entry if not already processed
        if not processedIds[playlist.id] then
            processedIds[playlist.id] = true
            
            table.insert(playlists, {
                Id = playlist.id,
                Title = playlist.name,
                Cover = playlist.cover,
                IsOwner = playlist.phone_number == currentPhone,
                Songs = {}
            })
        end
        
        -- Add song to the playlist if it exists
        if playlist.song_id then
            local currentPlaylist = playlists[#playlists]
            table.insert(currentPlaylist.Songs, playlist.song_id)
        end
    end
    
    return playlists
end

-- Music NUI Callback Handler
RegisterNUICallback("Music", function(data, cb)
    local action = data.action
    debugprint("Music:" .. (action or ""))
    
    if action == "getConfig" then
        cb(Music)
        
    elseif action == "createPlaylist" then
        TriggerCallback("music:createPlaylist", cb, data.name)
        
    elseif action == "editPlaylist" then
        TriggerCallback("music:editPlaylist", cb, data.id, data.title, data.cover)
        
    elseif action == "getPlaylists" then
        cb(getFormattedPlaylists())
        
    elseif action == "deletePlaylist" then
        TriggerCallback("music:deletePlaylist", cb, data.id)
        
    elseif action == "savePlaylist" then
        TriggerCallback("music:savePlaylist", cb, data.id)
        
    elseif action == "addSong" then
        TriggerCallback("music:addSong", cb, data.id, data.song)
        
    elseif action == "removeSong" then
        TriggerCallback("music:removeSong", cb, data.id, data.song)
    end
end)