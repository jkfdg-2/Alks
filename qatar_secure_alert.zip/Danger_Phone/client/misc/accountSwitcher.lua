-- Apps that support account switching
local supportedApps = {
    Twitter = true,
    Instagram = true,
    TikTok = true,
    Mail = true,
    DarkChat = true
}

-- Account Switcher NUI Callback Handler
RegisterNUICallback("AccountSwitcher", function(data, cb)
    debugprint("AccountSwitcher:" .. (data.action or ""))
    
    -- Validate request
    if not currentPhone or not supportedApps[data.app] then
        debugprint("AccountSwitcher: Invalid app / no currentPhone", data.app)
        return cb(false)
    end
    
    local action = data.action
    
    if action == "switch" then
        TriggerCallback("accountSwitcher:switchAccount", cb, data.app, data.account)
        
    elseif action == "getAccounts" then
        TriggerCallback("accountSwitcher:getAccounts", function(accounts)
            if not accounts then
                cb(false)
            end
            
            -- Extract usernames from account data
            local usernames = {}
            for i = 1, #accounts do
                usernames[i] = accounts[i].username
            end
            
            cb(usernames)
        end, data.app)
    end
end)