-- Controller cursor position and settings
local cursorX = 0.5
local cursorY = 0.5
local cursorSpeed = 0.005
local keyboardInputActive = false

-- Check if using gamepad instead of keyboard
local function isUsingGamepad()
    return IsUsingKeyboard(0) == false
end

-- Get normalized control input with deadzone
local function getControlInput(control)
    local input = GetDisabledControlNormal(0, control)
    local deadzone = 0.1
    
    -- Apply deadzone
    if input < -deadzone or input > deadzone then
        return input
    end
    
    return 0.0
end

-- Toggle keyboard input for controller
RegisterNUICallback("toggleInput", function(enabled)
    if not isUsingGamepad() then
        return
    end
    
    keyboardInputActive = (enabled == true)
    
    -- Delay before disabling to prevent accidental toggle
    if not enabled then
        Wait(250)
        if keyboardInputActive then
            return
        end
    end
    
    SendReactMessage("controller:toggleKeyboard", keyboardInputActive)
end)

-- Handle controller input
local function handleControllerInput()
    -- Get analog stick inputs
    local leftRightInput = getControlInput(1)  -- Left stick X
    local upDownInput = getControlInput(2)     -- Left stick Y
    local scrollInput = getControlInput(31)    -- Right stick Y (for scrolling)
    
    -- Update cursor position
    cursorX = cursorX + (leftRightInput * cursorSpeed)
    cursorY = cursorY + (upDownInput * cursorSpeed)
    
    -- Clamp cursor position to screen bounds
    cursorX = math.min(0.99999, math.max(0, cursorX))
    cursorY = math.min(1.0, math.max(0, cursorY))
    
    -- Handle button presses
    if IsDisabledControlJustPressed(0, 18) then  -- Enter/A button
        SendReactMessage("controller:press", {
            x = cursorX,
            y = cursorY
        })
    elseif IsDisabledControlJustReleased(0, 18) then
        SendReactMessage("controller:release", {
            x = cursorX,
            y = cursorY
        })
    elseif IsDisabledControlJustReleased(0, 199) or  -- Pause menu
           IsDisabledControlJustReleased(0, 177) then  -- Back button
        ToggleOpen(false)
    end
    
    -- Update cursor position if there's movement
    if leftRightInput ~= 0.0 or upDownInput ~= 0.0 then
        SetCursorLocation(cursorX, cursorY)
    end
    
    -- Handle scrolling
    if scrollInput ~= 0.0 then
        SendReactMessage("controller:scroll", {
            amount = math.floor(scrollInput * 25),
            x = cursorX,
            y = cursorY
        })
    end
    
    -- Disable all control actions while phone is open
    DisableAllControlActions(0)
    DisableAllControlActions(1)
    DisableAllControlActions(2)
    InvalidateIdleCam()
end

-- Main controller support thread
function ControllerThread()
    while phoneOpen do
        Wait(0)
        
        if isUsingGamepad() and IsNuiFocused() then
            handleControllerInput()
        else
            -- Less frequent checks when not using gamepad
            Wait(500)
        end
    end
    
    -- Reset cursor to center when phone closes
    cursorX = 0.5
    cursorY = 0.5
    
    if isUsingGamepad() then
        SetCursorLocation(cursorX, cursorY)
    end
end