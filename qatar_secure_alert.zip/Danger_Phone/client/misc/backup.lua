-- Apply a phone backup
local function applyPhoneBackup(phoneNumber, callback)
    -- Prevent applying backup to currently equipped phone
    if phoneNumber == currentPhone then
        debugprint("can't apply backup since it's the currently equipped number")
        return callback(false)
    end
    
    -- Request backup application from server
    local success = AwaitCallback("backup:applyBackup", phoneNumber)
    debugprint("phone:backup:applyBackup", phoneNumber, ":", success)
    
    callback(success)
    
    if not success then
        return
    end
    
    -- Refresh phone after backup is applied
    Wait(5000)
    OnDeath()  -- Reset phone state
    Wait(500)
    FetchPhone()  -- Reload phone data
    Wait(500)
    ToggleOpen(true)  -- Open the phone
end

-- Phone Backup NUI Callback Handler
RegisterNUICallback("Backup", function(data, cb)
    local action = data.action
    debugprint("Backup:" .. (action or ""))
    
    if action == "create" then
        -- Create a new backup of current phone
        TriggerCallback("backup:createBackup", cb)
        
    elseif action == "delete" then
        -- Delete an existing backup
        TriggerCallback("backup:deleteBackup", cb, data.number)
        
    elseif action == "apply" then
        -- Apply a backup to current phone
        applyPhoneBackup(data.number, cb)
        
    elseif action == "get" then
        -- Get list of all backups
        TriggerCallback("backup:getBackups", cb)
    end
end)