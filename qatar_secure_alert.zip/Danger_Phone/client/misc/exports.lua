-- Export: Toggle home indicator visibility
exports("ToggleHomeIndicator", function(visible)
    SendReactMessage("toggleShowHomeIndicator", visible)
end)

-- Export: Toggle landscape mode
exports("ToggleLandscape", function(enabled)
    SendReactMessage("toggleLandscape", enabled)
end)

-- Export: Open a specific app
exports("OpenApp", function(appName, metadata)
    SendReactMessage("setApp", {
        name = appName,
        metadata = metadata
    })
end)

-- Export: Close app
exports("CloseApp", function(options)
    -- Default to empty options if not provided
    if not options then
        options = {}
    end
    
    -- Debug logging
    debugprint("CloseApp: " .. (options.app or "nil") .. 
               ", closeCompletely: " .. tostring(options.closeCompletely))
    
    -- Send close app message
    SendReactMessage("closeApp", {
        app = options.app or nil,
        closeCompletely = options.closeCompletely == true
    })
end)