-- Voice proximity system for hearing nearby players
if not Config.Voice.HearNearby then
    return
end

-- Track players in Instagram live proximity
local playersInLiveProximity = {}

-- Enter Instagram live proximity
local function enterLiveProximity(liveId)
    if not playersInLiveProximity[liveId] then
        playersInLiveProximity[liveId] = true
        debugprint("entered live", liveId)
        TriggerServerEvent("phone:instagram:enteredLiveProximity", liveId)
    end
end

-- Leave Instagram live proximity
local function leaveLiveProximity(liveId)
    if playersInLiveProximity[liveId] then
        playersInLiveProximity[liveId] = nil
        debugprint("left live 1", liveId)
        TriggerServerEvent("phone:instagram:leftLiveProximity", liveId)
    end
end

-- Handle Instagram live end event
RegisterNetEvent("phone:instagram:endLive", function(liveId, shouldNotify)
    if not shouldNotify then
        playersInLiveProximity[liveId] = nil
        debugprint("left live 2", liveId)
        return
    end
    
    if playersInLiveProximity[liveId] then
        playersInLiveProximity[liveId] = nil
        TriggerServerEvent("phone:instagram:leftLiveProximity", shouldNotify, true)
    end
end)

-- Track players we're listening to (receiving audio)
local listeningToPlayers = {}

-- Start listening to a player's voice
local function startListeningToPlayer(playerId)
    if not playerId or table.contains(listeningToPlayers, playerId) then
        return
    end
    
    debugprint("started listening to", playerId)
    TriggerServerEvent("phone:phone:listenToPlayer", playerId)
    listeningToPlayers[#listeningToPlayers + 1] = playerId
    return true
end

-- Stop listening to a player's voice
local function stopListeningToPlayer(playerId)
    if not playerId then
        return
    end
    
    local isListening, index = table.contains(listeningToPlayers, playerId)
    if not isListening then
        return
    end
    
    debugprint("stopped listening to", playerId)
    TriggerServerEvent("phone:phone:stopListeningToPlayer", playerId)
    table.remove(listeningToPlayers, index)
    return true
end

-- Track players in call proximity (can hear us)
local playersInCallProximity = {}

-- Player left call proximity (they can no longer hear us)
local function playerLeftCallProximity(playerId)
    if not playerId then
        return
    end
    
    local inProximity, index = table.contains(playersInCallProximity, playerId)
    if not inProximity then
        return
    end
    
    debugprint("started talking to", playerId)
    TriggerServerEvent("phone:phone:leftCallProximity", playerId)
    table.remove(playersInCallProximity, index)
    return true
end

-- Player entered call proximity (they can now hear us)
local function playerEnteredCallProximity(playerId)
    if not playerId or table.contains(playersInCallProximity, playerId) then
        return
    end
    
    debugprint("stopped talking to", playerId)
    TriggerServerEvent("phone:phone:enteredCallProximity", playerId)
    playersInCallProximity[#playersInCallProximity + 1] = playerId
    return true
end

-- Main proximity check loop
while true do
    Wait(250)
    
    local nearbyPlayers = GetNearbyPlayers()
    local myCoords = GetEntityCoords(PlayerPedId())
    
    for i = 1, #nearbyPlayers do
        local player = nearbyPlayers[i]
        local playerState = Player(player.source).state
        
        -- Check if player is on speakerphone call
        local isOnSpeakerphone = playerState.onCallWith and 
                                playerState.speakerphone and 
                                playerState.callAnswered
        
        -- Check if player is live on Instagram
        local instagramLiveId = playerState.instapicIsLive
        
        -- Calculate distance to player
        local distance = #(myCoords - GetEntityCoords(player.ped))
        
        if distance <= 5 then  -- Within 5 units proximity
            -- Handle Instagram live proximity
            if instagramLiveId then
                enterLiveProximity(instagramLiveId)
            end
            
            -- Handle call proximity
            if isOnSpeakerphone then
                -- Handle listening to their call partner
                if playerState.otherMutedCall then
                    -- Stop listening if their partner is muted
                    if stopListeningToPlayer(playerState.onCallWith) then
                        if not playerState.mutedCall then
                            TriggerServerEvent("phone:phone:enteredCallProximity", player.source)
                        end
                    end
                else
                    -- Start listening to their call partner
                    startListeningToPlayer(playerState.onCallWith)
                end
                
                -- Handle them listening to us
                if playerState.mutedCall then
                    -- They muted, so they can't hear us
                    if playerLeftCallProximity(player.source) then
                        if not playerState.otherMutedCall then
                            TriggerServerEvent("phone:phone:listenToPlayer", playerState.onCallWith)
                        end
                    end
                else
                    -- They unmuted, so they can hear us
                    playerEnteredCallProximity(player.source)
                end
            else
                -- Not on speakerphone anymore, cleanup
                if playerState.onCallWith then
                    stopListeningToPlayer(playerState.onCallWith)
                    playerLeftCallProximity(player.source)
                end
            end
        else  -- Outside proximity range
            -- Leave Instagram live proximity
            if instagramLiveId then
                leaveLiveProximity(instagramLiveId)
            end
            
            -- Cleanup call proximity
            if playerState.onCallWith then
                stopListeningToPlayer(playerState.onCallWith)
                playerLeftCallProximity(player.source)
            end
        end
    end
end