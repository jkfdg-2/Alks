-- Flashlight state
flashlightEnabled = false

-- Custom flashlight drawing function (fallback if not defined)
if not DrawFlashlight then
    function DrawFlashlight(ped)
        -- Get position from phone holding hand
        local handCoords = GetPedBoneCoords(ped, 28422, 0.5, 0.0, 0.0)
        local forwardVector = GetEntityForwardVector(ped)
        
        -- Draw main spotlight
        DrawSpotLightWithShadow(
            handCoords.x, handCoords.y, handCoords.z,
            forwardVector.x, forwardVector.y, forwardVector.z,
            255, 255, 255,  -- Color (white)
            15.0,           -- Distance
            3.0,            -- Brightness
            0.0,            -- Roundness
            50.0,           -- Radius
            100.0,          -- Falloff
            1               -- Shadow ID
        )
        
        -- Draw secondary spotlight for better illumination
        DrawSpotLightWithShadow(
            handCoords.x, handCoords.y, handCoords.z,
            forwardVector.x, forwardVector.y, forwardVector.z,
            255, 255, 255,  -- Color (white)
            30.0,           -- Distance
            10.0,           -- Brightness
            0.0,            -- Roundness
            20.0,           -- Radius
            25.0,           -- Falloff
            1               -- Shadow ID
        )
    end
end

-- Toggle flashlight state
local function toggleFlashlight(enabled)
    local previousState = flashlightEnabled
    flashlightEnabled = (enabled == true)
    
    -- No change needed
    if flashlightEnabled == previousState then
        return
    end
    
    -- Sync with server
    TriggerServerEvent("phone:toggleFlashlight", flashlightEnabled)
    
    -- Start flashlight drawing thread
    if flashlightEnabled then
        Citizen.CreateThreadNow(function()
            local playerPed = PlayerPedId()
            
            while flashlightEnabled do
                if phoneOpen then
                    DrawFlashlight(playerPed)
                else
                    Wait(500)  -- Less frequent checks when phone is closed
                end
                Wait(0)
            end
        end)
    end
end

-- NUI Callback for flashlight toggle
RegisterNUICallback("toggleFlashlight", function(data, cb)
    toggleFlashlight(data.toggled)
    
    -- Delayed callback to ensure state is set
    SetTimeout(100, function()
        cb(flashlightEnabled)
    end)
end)

-- Export: Toggle flashlight
exports("ToggleFlashlight", function(enabled)
    if not phoneOpen then
        return
    end
    
    toggleFlashlight(enabled)
    SendReactMessage("toggleFlashlight", flashlightEnabled)
end)

-- Export: Get flashlight state
exports("GetFlashlight", function()
    return flashlightEnabled == true
end)

-- Synced flashlight system (other players)
if not Config.SyncFlash then
    return
end

local nearbyFlashlights = {}
local isDrawingFlashlights = false

-- Start drawing nearby flashlights
local function startDrawingFlashlights()
    if isDrawingFlashlights then
        return
    end
    
    isDrawingFlashlights = true
    
    Citizen.CreateThreadNow(function()
        debugprint("Started drawing flashlights")
        
        while isDrawingFlashlights do
            -- Draw all nearby flashlights
            for i = 1, #nearbyFlashlights do
                DrawFlashlight(nearbyFlashlights[i])
            end
            Wait(0)
        end
        
        debugprint("Stopped drawing flashlights")
    end)
end

-- Handle state bag changes for flashlight sync
AddStateBagChangeHandler("flashlight", nil, function(bagName, key, value, reserved, replicated)
    local playerId = GetPlayerFromStateBagName(bagName)
    
    -- Ignore if it's us or invalid player
    if not playerId or playerId == 0 or playerId == PlayerId() then
        return
    end
    
    local playerPed = GetPlayerPed(playerId)
    local distance = #(GetEntityCoords(PlayerPedId()) - GetEntityCoords(playerPed))
    
    -- Only sync flashlights within 30 units
    if distance > 30.0 then
        return
    end
    
    local isInList, index = table.contains(nearbyFlashlights, playerPed)
    
    if not isInList and value then
        -- Add to list
        nearbyFlashlights[#nearbyFlashlights + 1] = playerPed
    elseif isInList and not value then
        -- Remove from list
        table.remove(nearbyFlashlights, index)
    end
    
    -- Start/stop drawing based on list
    if #nearbyFlashlights > 0 then
        startDrawingFlashlights()
    else
        isDrawingFlashlights = false
    end
end)

-- Periodic cleanup and sync check
CreateThread(function()
    while true do
        -- Clear list for refresh
        if #nearbyFlashlights > 0 then
            table.wipe(nearbyFlashlights)
        end
        
        local myCoords = GetEntityCoords(PlayerPedId())
        local nearbyPlayers = GetNearbyPlayers()
        
        -- Check all nearby players
        for i = 1, #nearbyPlayers do
            local player = nearbyPlayers[i]
            local playerState = Player(player.source).state
            
            -- Add if they have flashlight enabled and phone open
            if playerState.flashlight and playerState.phoneOpen then
                local distance = #(myCoords - GetEntityCoords(player.ped))
                
                if distance <= 30.0 then
                    nearbyFlashlights[#nearbyFlashlights + 1] = player.ped
                end
            end
        end
        
        -- Start/stop drawing based on list
        if #nearbyFlashlights > 0 then
            startDrawingFlashlights()
        else
            isDrawingFlashlights = false
        end
        
        Wait(1000)  -- Check every second
    end
end)