-- Cached function for performance
local GetEntityCoords = GetEntityCoords

-- Store nearby listening players
local listeningPlayers = {}

-- Update nearby players who are listening/recording
local function updateNearbyListeners()
    local nearbyListeners = {}
    local nearbyPlayers = GetNearbyPlayers()
    local myCoords = GetEntityCoords(PlayerPedId())
    
    for i = 1, #nearbyPlayers do
        local player = nearbyPlayers[i]
        local playerState = Player(player.source).state
        
        -- Check if player is listening/recording
        local listeningChannel = playerState and playerState.listeningPeerId
        
        if listeningChannel then
            local distance = #(myCoords - GetEntityCoords(player.ped))
            
            -- Only include players within 25 units
            if distance <= 25.0 then
                local listenerData = {
                    source = player.source,
                    ped = player.ped,
                    channel = listeningChannel
                }
                
                -- Check if we already track this player to preserve volume
                for j = 1, #listeningPlayers do
                    local existingListener = listeningPlayers[j]
                    if existingListener.source == player.source then
                        listenerData.volume = existingListener.volume
                        goto found_existing
                    end
                end
                
                -- New listener - calculate initial volume
                listenerData.volume = GetVoiceVolume(distance)
                
                -- Notify UI about new channel
                SendReactMessage("voice:joinChannel", {
                    channel = listeningChannel,
                    volume = GetVoiceVolume(distance)
                })
                
                ::found_existing::
                nearbyListeners[#nearbyListeners + 1] = listenerData
            end
        end
    end
    
    listeningPlayers = nearbyListeners
end

-- Update voice volumes based on distance
local function updateVoiceVolumes()
    local myCoords = GetEntityCoords(PlayerPedId())
    
    for i = 1, #listeningPlayers do
        local listener = listeningPlayers[i]
        local distance = #(myCoords - GetEntityCoords(listener.ped))
        local newVolume = GetVoiceVolume(distance)
        
        -- Only update if volume changed
        if newVolume ~= listener.volume then
            listener.volume = newVolume
            
            SendReactMessage("voice:setVolume", {
                channel = listener.channel,
                volume = newVolume
            })
        end
    end
end

-- Only run if voice recording is enabled
if not Config.Voice.RecordNearby then
    return
end

-- Thread to update nearby listeners every second
CreateThread(function()
    while true do
        Wait(1000)
        updateNearbyListeners()
    end
end)

-- Thread to update voice volumes more frequently when needed
CreateThread(function()
    while true do
        if #listeningPlayers > 0 then
            updateVoiceVolumes()
            Wait(50)  -- Update frequently when players are nearby
        else
            Wait(500) -- Check less often when no one is listening
        end
    end
end)

-- Handle when a player starts listening/recording
RegisterNetEvent("phone:startedListening", function(playerServerId, channelId)
    local playerId = GetPlayerFromServerId(playerServerId)
    
    -- Validate player
    if not playerId or playerId == PlayerId() or playerId == -1 then
        return
    end
    
    local myPed = PlayerPedId()
    local playerPed = GetPlayerPed(playerId)
    local distance = #(GetEntityCoords(myPed) - GetEntityCoords(playerPed))
    
    -- Check if player exists and is within range
    if not DoesEntityExist(playerPed) or playerPed == myPed or distance > 25.0 then
        return
    end
    
    -- Check if we're already tracking this player
    for i = 1, #listeningPlayers do
        if listeningPlayers[i].source == playerServerId then
            return
        end
    end
    
    -- Add new listening player
    listeningPlayers[#listeningPlayers + 1] = {
        source = playerServerId,
        ped = playerPed,
        channel = channelId,
        volume = GetVoiceVolume(distance)
    }
    
    -- Notify UI
    SendReactMessage("voice:joinChannel", {
        channel = channelId,
        volume = GetVoiceVolume(distance)
    })
end)

-- Handle when a player stops listening/recording
RegisterNetEvent("phone:stoppedListening", function(channelId)
    SendReactMessage("voice:leaveChannel", channelId)
end)

-- NUI Callback: Set listening peer ID
RegisterNUICallback("setListeningPeerId", function(peerId, cb)
    TriggerServerEvent("phone:setListeningPeerId", peerId)
    cb("ok")
end)

-- NUI Callback: Get voice config
RegisterNUICallback("voice:getConfig", function(data, cb)
    cb({
        recordNearbyVoices = Config.Voice.RecordNearby,
        rtc = Config.RTCConfig
    })
end)