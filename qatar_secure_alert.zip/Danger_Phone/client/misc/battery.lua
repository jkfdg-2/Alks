-- Battery System Variables
local batteryLevel = 100
local isCharging = false

-- Set Battery Level
local function setBattery(battery)
    -- Check if battery system is enabled
    if not Config.Battery.Enabled then
        return
    end
    
    -- Validate battery parameter
    assert(type(battery) == "number", "setBattery: battery must be a number")
    assert(battery >= 0 and battery <= 100, "setBattery: battery must be between 0 and 100")
    
    batteryLevel = battery
    
    -- Handle phone death when battery reaches 0
    if battery == 0 then
        OnDeath()
        TriggerEvent("Danger_Phone:phoneDied")
    end
    
    -- Sync battery level with server
    TriggerServerEvent("phone:battery:setBattery", battery)
end

-- NUI Callback for setting battery
RegisterNUICallback("setBattery", function(data, cb)
    setBattery(data)
    cb("ok")
end)

-- Export: Set Battery
exports("SetBattery", function(battery)
    setBattery(battery)
    SendReactMessage("battery:setBattery", battery)
end)

-- Export: Get Battery
exports("GetBattery", function()
    return batteryLevel
end)

-- Toggle Charging State
function ToggleCharging(toggle)
    assert(type(toggle) == "boolean", "ToggleCharging: toggle must be a boolean")
    
    -- Avoid redundant updates
    if isCharging == toggle then
        debugprint("ToggleCharging: charging is already set to", toggle)
        return
    end
    
    isCharging = toggle
    SendReactMessage("battery:toggleCharging", toggle)
end

-- Export: Toggle Charging
exports("ToggleCharging", ToggleCharging)

-- Export: Is Charging
exports("IsCharging", function()
    return isCharging
end)

-- Check if Phone is Dead
function IsPhoneDead()
    if not Config.Battery.Enabled then
        return false
    end
    
    return batteryLevel == 0
end

-- Export: Is Phone Dead
exports("IsPhoneDead", IsPhoneDead)