-- Format custom app data for UI display
function FormatCustomAppDataForUI(appData)
    return {
        identifier = appData.identifier,
        resourceName = appData.resourceName,
        custom = true,
        name = appData.name,
        icon = appData.icon,
        description = appData.description,
        images = appData.images,
        developer = appData.developer,
        size = appData.size or 42000,
        price = appData.price,
        game = appData.game,
        landscape = appData.landscape or false,
        removable = not appData.defaultApp,
        disableInAppNotifications = appData.disableInAppNotifications,
        ui = appData.ui,
        fixBlur = appData.fixBlur,
        access = HasAccessToApp(appData.identifier)
    }
end

-- Export: Send message to custom app
exports("SendCustomAppMessage", function(identifier, message)
    local invokingResource = GetInvokingResource()
    
    -- Validate identifier
    if not identifier then
        return false, "No identifier provided"
    end
    
    -- Check if app exists
    if not Config.CustomApps[identifier] then
        return false, "App does not exist"
    end
    
    -- Verify ownership
    if Config.CustomApps[identifier].resourceName ~= invokingResource then
        return false, "App was not created by " .. invokingResource
    end
    
    -- Send message to app
    SendReactMessage("customApp:sendMessage", {
        identifier = identifier,
        message = message
    })
    
    return true
end)

-- Export: Add custom app
exports("AddCustomApp", function(appData)
    local invokingResource = GetInvokingResource()
    
    -- Validate required fields
    if not appData or not appData.identifier then
        return false, "No identifier provided"
    end
    
    if not appData.name then
        return false, "No name provided"
    end
    
    if not appData.description then
        return false, "No description provided"
    end
    
    -- Check if app already exists
    if Config.CustomApps[appData.identifier] then
        return false, "App already exists"
    end
    
    -- Create app configuration
    Config.CustomApps[appData.identifier] = {
        identifier = appData.identifier,
        resourceName = invokingResource,
        custom = true,
        name = appData.name,
        icon = appData.icon,
        description = appData.description,
        images = appData.images,
        developer = appData.developer,
        size = appData.size or 42000,
        price = appData.price,
        game = appData.game,
        landscape = appData.landscape or false,
        removable = not appData.defaultApp,
        defaultApp = appData.defaultApp,
        disableInAppNotifications = appData.disableInAppNotifications,
        ui = appData.ui,
        fixBlur = appData.fixBlur,
        onOpen = appData.onOpen,
        onClose = appData.onClose,
        onUse = appData.onUse,
        onDelete = appData.onDelete,
        onInstall = appData.onInstall
    }
    
    debugprint("adding custom app", appData.identifier)
    
    -- Notify UI about new app
    SendReactMessage("addCustomApp", 
        FormatCustomAppDataForUI(Config.CustomApps[appData.identifier])
    )
    
    return true
end)

-- Export: Remove custom app
exports("RemoveCustomApp", function(identifier)
    local invokingResource = GetInvokingResource()
    
    -- Validate identifier
    if not identifier then
        return false, "No identifier provided"
    end
    
    -- Check if app exists
    if not Config.CustomApps[identifier] then
        return false, "App does not exist"
    end
    
    -- Verify ownership
    if Config.CustomApps[identifier].resourceName ~= invokingResource then
        return false, "App was not created by " .. invokingResource
    end
    
    -- Remove app
    Config.CustomApps[identifier] = nil
    
    -- Notify UI about removal
    SendReactMessage("removeCustomApp", identifier)
    
    return true
end)

-- Clean up apps when resource stops
AddEventHandler("onResourceStop", function(resourceName)
    for identifier, appData in pairs(Config.CustomApps) do
        if appData.resourceName == resourceName then
            -- Remove app from config
            Config.CustomApps[identifier] = nil
            
            -- Notify UI
            SendReactMessage("removeCustomApp", identifier)
            
            debugprint("Removed app " .. identifier .. " due to resource stopping")
        end
    end
end)