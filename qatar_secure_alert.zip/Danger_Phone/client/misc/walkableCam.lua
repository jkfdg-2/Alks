-- Camera Configuration
local config = {
    -- Regular camera
    maxFOV = Config.Camera and Config.Camera.MaxFOV or 70.0,
    defaultFOV = Config.Camera and Config.Camera.DefaultFOV or 60.0,
    minFOV = Config.Camera and Config.Camera.MinFOV or 10.0,
    maxLookUp = Config.Camera and Config.Camera.MaxLookUp or 80.0,
    maxLookDown = Config.Camera and Config.Camera.MaxLookDown or -80.0,
    allowRunning = Config.Camera and Config.Camera.AllowRunning == true,
    
    -- Vehicle camera
    vehicle = {
        zoom = Config.Camera and Config.Camera.Vehicle and Config.Camera.Vehicle.Zoom == true,
        maxFOV = Config.Camera and Config.Camera.Vehicle and Config.Camera.Vehicle.MaxFOV or 80.0,
        defaultFOV = Config.Camera and Config.Camera.Vehicle and Config.Camera.Vehicle.DefaultFOV or 60.0,
        minFOV = Config.Camera and Config.Camera.Vehicle and Config.Camera.Vehicle.MinFOV or 10.0,
        maxLookUp = Config.Camera and Config.Camera.Vehicle and Config.Camera.Vehicle.MaxLookUp or 50.0,
        maxLookDown = Config.Camera and Config.Camera.Vehicle and Config.Camera.Vehicle.MaxLookDown or -30.0,
        maxLeftRight = Config.Camera and Config.Camera.Vehicle and Config.Camera.Vehicle.MaxLeftRight or 120.0,
        minLeftRight = Config.Camera and Config.Camera.Vehicle and Config.Camera.Vehicle.MinLeftRight or -120.0,
    },
    
    -- Selfie camera
    selfie = {
        maxFOV = Config.Camera and Config.Camera.Selfie and Config.Camera.Selfie.MaxFOV or 80.0,
        defaultFOV = Config.Camera and Config.Camera.Selfie and Config.Camera.Selfie.DefaultFOV or 60.0,
        minFOV = Config.Camera and Config.Camera.Selfie and Config.Camera.Selfie.MinFOV or 50.0,
        offset = Config.Camera and Config.Camera.Selfie and Config.Camera.Selfie.Offset or vector3(0.1, 0.55, 0.6),
        rotation = Config.Camera and Config.Camera.Selfie and Config.Camera.Selfie.Rotation or vector3(10.0, 0.0, -180.0),
    },
    
    -- Freeze camera
    freeze = {
        enabled = Config.Camera and Config.Camera.Freeze and Config.Camera.Freeze.Enabled == true,
        maxDistance = Config.Camera and Config.Camera.Freeze and Config.Camera.Freeze.MaxDistance or 10.0,
        maxTime = (Config.Camera and Config.Camera.Freeze and Config.Camera.Freeze.MaxTime or 60) * 1000,
    },
    
    -- Roll feature
    rollEnabled = Config.Camera and Config.Camera.Roll == true,
}

-- Camera state variables
local cameraState = {
    rearCameraOffset = vector3(0.0, 0.5, 0.6),
    pitch = 0.0,
    roll = 0.0,
    fov = config.defaultFOV,
    savedViewMode = 0,
    vehicleYaw = 0.0,
    disabledRadio = false,
    isFrozen = false,
    freezeTimer = 0,
    playerPed = PlayerPedId(),
    isSelfie = false,
    isStrafing = false,
    sensitivityMultiplier = 0.0,
    baseSensitivity = GetProfileSetting(754) + 10,
    currentZoom = 1.0,
    activeCamera = nil,
}

-- Camera modes enum
local CameraModes = {
    REAR = 0,
    SELFIE = 1,
    IN_VEHICLE = 2,
}

local currentCameraMode = CameraModes.REAR

-- Get FOV limits based on current mode
local function getFOVLimits()
    local isInVehicle = IsPedInAnyVehicle(cameraState.playerPed, true)
    
    local maxFOV = config.maxFOV
    local minFOV = config.minFOV
    local defaultFOV = config.defaultFOV
    
    if cameraState.isSelfie then
        maxFOV = config.selfie.maxFOV
        minFOV = config.selfie.minFOV
        defaultFOV = config.selfie.defaultFOV
    elseif isInVehicle then
        maxFOV = config.vehicle.maxFOV
        minFOV = config.vehicle.zoom and config.vehicle.minFOV or config.vehicle.maxFOV
        defaultFOV = config.vehicle.defaultFOV
    end
    
    return maxFOV, minFOV, defaultFOV
end

-- Convert FOV to zoom level
function ConvertFovToZoom(fov)
    local maxFOV, minFOV, defaultFOV = getFOVLimits()
    local clampedFov = math.clamp(fov, minFOV, maxFOV)
    
    if clampedFov == defaultFOV then
        return 1.0
    elseif defaultFOV > clampedFov then
        return clampedFov > 0 and defaultFOV / clampedFov or 1.0
    else
        local range = maxFOV - defaultFOV
        local normalized = (clampedFov - defaultFOV) / range
        return 1.0 - (normalized * 0.5)
    end
end

-- Convert zoom level to FOV
local function convertZoomToFov(zoom)
    local maxFOV, minFOV, defaultFOV = getFOVLimits()
    
    local maxZoom = defaultFOV < maxFOV and 0.5 or 1.0
    local minZoom = minFOV < defaultFOV and minFOV > 0 and defaultFOV / minFOV or 1.0
    
    local clampedZoom = math.clamp(zoom, maxZoom, minZoom)
    
    if clampedZoom == 1.0 then
        return defaultFOV
    elseif clampedZoom > 1.0 then
        return defaultFOV / clampedZoom
    else
        local normalized = (1.0 - clampedZoom) * 2.0
        return defaultFOV + (normalized * (maxFOV - defaultFOV))
    end
end

-- Update available zoom levels in UI
local function updateZoomLevels()
    local maxFOV, minFOV, defaultFOV = getFOVLimits()
    local maxZoom = ConvertFovToZoom(maxFOV)
    local minZoom = ConvertFovToZoom(minFOV)
    
    local zoomLevels = {1.0}
    
    if maxZoom < 1.0 then
        table.insert(zoomLevels, 1, maxZoom)
    end
    
    if minZoom > 2.0 then
        table.insert(zoomLevels, 2)
    end
    
    if minZoom > 5.0 then
        table.insert(zoomLevels, 5)
    elseif minZoom > 3.0 then
        table.insert(zoomLevels, 3)
    end
    
    SendReactMessage("camera:setZoomLevels", zoomLevels)
end

-- Set camera zoom
function SetCameraZoom(zoom)
    cameraState.fov = convertZoomToFov(zoom)
end

-- Update camera mode and settings
local function updateCameraMode()
    local isInVehicle = IsPedInAnyVehicle(cameraState.playerPed, true)
    local newMode = cameraState.isSelfie and CameraModes.SELFIE or CameraModes.REAR
    
    if isInVehicle then
        newMode = newMode | CameraModes.IN_VEHICLE
    end
    
    if currentCameraMode ~= newMode then
        local _, _, defaultFOV = getFOVLimits()
        currentCameraMode = newMode
        cameraState.fov = defaultFOV
        
        debugprint("Camera mode changed to: " .. currentCameraMode)
        updateZoomLevels()
        SetCamFov(cameraState.activeCamera, cameraState.fov)
    end
    
    -- Update strafe detection
    cameraState.isStrafing = IsDisabledControlPressed(0, 33) or 
                            IsDisabledControlPressed(0, 34) or 
                            IsDisabledControlPressed(0, 35)
    
    cameraState.isStrafing = cameraState.isStrafing and not isInVehicle
end

-- Main camera update loop
local function updateCamera()
    updateCameraMode()
    
    -- Set gameplay cam settings
    SetFollowPedCamViewMode(0)
    SetGameplayCamRelativeHeading(0.0)
    
    -- Disable weapon wheel and related controls
    DisableControlAction(0, 1, true)    -- Look LR
    DisableControlAction(0, 14, true)   -- Weapon Wheel Next
    DisableControlAction(0, 15, true)   -- Weapon Wheel Prev
    DisableControlAction(0, 16, true)   -- Select Next Weapon
    DisableControlAction(0, 17, true)   -- Select Prev Weapon
    DisableControlAction(0, 99, true)   -- VehicleSelectNextWeapon
    DisableControlAction(0, 100, true)  -- VehicleSelectPrevWeapon
    DisableControlAction(0, 115, true)  -- Weapon Wheel Next (alt)
    DisableControlAction(0, 116, true)  -- Weapon Wheel Prev (alt)
    DisableControlAction(0, 261, true)  -- Weapon Wheel LR
    DisableControlAction(0, 262, true)  -- Weapon Wheel UD
    
    -- Keep ped facing forward
    SetPedResetFlag(cameraState.playerPed, 47, true)
    
    -- Handle frozen camera
    if cameraState.isFrozen and not IsPedInAnyVehicle(cameraState.playerPed, true) then
        local pedCoords = GetEntityCoords(cameraState.playerPed)
        local camCoords = GetCamCoord(cameraState.activeCamera)
        local distance = #(pedCoords - camCoords)
        
        if distance > config.freeze.maxDistance or GetGameTimer() > cameraState.freezeTimer then
            cameraState.isFrozen = false
            TogglePhoneAnimation(true, "camera")
        end
        return
    end
    
    -- Disable sprint if needed
    if not config.allowRunning then
        DisableControlAction(0, 21, true) -- Sprint
    end
    
    -- Position camera based on mode
    local isInVehicle = IsPedInAnyVehicle(cameraState.playerPed, true)
    
    if cameraState.isSelfie and not isInVehicle then
        -- Selfie camera attached to head
        AttachCamToPedBone_2(
            cameraState.activeCamera, cameraState.playerPed, 0,
            config.selfie.rotation.x + cameraState.pitch,
            config.selfie.rotation.y,
            config.selfie.rotation.z,
            config.selfie.offset.x,
            config.selfie.offset.y,
            config.selfie.offset.z,
            true
        )
    elseif not cameraState.isSelfie and not isInVehicle then
        -- Rear camera
        local offset = GetOffsetFromEntityInWorldCoords(
            cameraState.playerPed,
            cameraState.rearCameraOffset.x,
            cameraState.rearCameraOffset.y,
            cameraState.rearCameraOffset.z
        )
        
        -- Get head position for height reference
        local headCoords = GetPedBoneCoords(cameraState.playerPed, 31086, 0.0, 0.0, 0.0)
        local camZ = math.abs(headCoords.z - offset.z) > 0.2 and headCoords.z or offset.z
        
        DetachCam(cameraState.activeCamera)
        SetCamCoord(cameraState.activeCamera, offset.x, offset.y, camZ)
        SetCamRot(cameraState.activeCamera, cameraState.pitch, cameraState.roll, GetEntityHeading(cameraState.playerPed), 2)
    elseif cameraState.isSelfie and isInVehicle then
        -- Selfie in vehicle
        AttachCamToPedBone_2(
            cameraState.activeCamera, cameraState.playerPed, 0,
            80.0 + cameraState.pitch, 0.0, -180.0,
            0.0, 0.2, 0.5, true
        )
    elseif not cameraState.isSelfie and isInVehicle then
        -- Rear camera in vehicle
        SetEntityLocallyInvisible(GetPhoneObject())
        SetEntityLocallyInvisible(cameraState.playerPed)
        
        AttachCamToPedBone_2(
            cameraState.activeCamera, cameraState.playerPed,
            GetPedBoneIndex(cameraState.playerPed, 11816),
            cameraState.pitch, 0.0, cameraState.vehicleYaw,
            0.0, 0.0, 0.55, true
        )
    end
    
    -- Handle radio in vehicle
    if isInVehicle then
        if not cameraState.disabledRadio then
            cameraState.disabledRadio = true
            SetUserRadioControlEnabled(false)
        end
    else
        if cameraState.disabledRadio then
            cameraState.disabledRadio = false
            SetUserRadioControlEnabled(true)
        end
        cameraState.vehicleYaw = 0.0
    end
    
    -- Handle strafe animation
    if cameraState.isStrafing then
        SetPedResetFlag(cameraState.playerPed, 69, true)
    elseif not cameraState.isSelfie and not isInVehicle then
        DisableControlAction(0, 30, true) -- Move LR
    end
    
    -- Update FOV and zoom
    local currentFov = GetCamFov(cameraState.activeCamera)
    local maxFOV, minFOV = getFOVLimits()
    
    cameraState.fov = math.clamp(cameraState.fov, minFOV, maxFOV)
    
    -- Update UI zoom level
    local currentZoomLevel = math.round(ConvertFovToZoom(currentFov), 1)
    if currentZoomLevel ~= cameraState.currentZoom then
        debugprint("Zoom changed to: " .. currentZoomLevel, ConvertFovToZoom(currentFov), currentFov)
        cameraState.currentZoom = currentZoomLevel
        SendReactMessage("camera:setZoom", currentZoomLevel)
    end
    
    -- Smooth FOV transitions
    if math.abs(currentFov - cameraState.fov) > 0.05 then
        SetCamFov(cameraState.activeCamera, currentFov + (cameraState.fov - currentFov) / 25)
    end
    
    -- Handle controls when not in NUI focus
    if not IsNuiFocused() then
        -- Update sensitivity
        cameraState.sensitivityMultiplier = (cameraState.baseSensitivity * (cameraState.fov / config.maxFOV)) / 5
        
        -- Look left/right
        local lookLR = GetDisabledControlNormal(0, 1)
        if isInVehicle then
            cameraState.vehicleYaw = math.clamp(
                cameraState.vehicleYaw - (lookLR * cameraState.sensitivityMultiplier),
                config.vehicle.minLeftRight,
                config.vehicle.maxLeftRight
            )
        elseif lookLR ~= 0.0 then
            SetEntityHeading(cameraState.playerPed, GetEntityHeading(cameraState.playerPed) - (lookLR * cameraState.sensitivityMultiplier))
        end
        
        -- Zoom controls
        if IsDisabledControlPressed(0, 180) then      -- Scroll up
            cameraState.fov = cameraState.fov + 5
        elseif IsDisabledControlPressed(0, 181) then  -- Scroll down
            cameraState.fov = cameraState.fov - 5
        end
        
        -- Look up/down
        local lookUD = GetDisabledControlNormal(0, 2)
        if lookUD ~= 0.0 then
            local pitchDelta = lookUD * cameraState.sensitivityMultiplier
            local maxUp = isInVehicle and config.vehicle.maxLookUp or config.maxLookUp
            local maxDown = isInVehicle and config.vehicle.maxLookDown or config.maxLookDown
            
            cameraState.pitch = math.clamp(cameraState.pitch - pitchDelta, maxDown, maxUp)
        end
    end
end

-- Handle rotation when camera is frozen
local function handleFrozenRotation()
    local lookLR = GetDisabledControlNormal(0, 1)
    if lookLR ~= 0.0 then
        SetEntityHeading(
            cameraState.playerPed,
            GetEntityHeading(cameraState.playerPed) - (lookLR * cameraState.sensitivityMultiplier)
        )
    end
end

-- Enable walkable camera
function EnableWalkableCam(selfie)
    if cameraState.activeCamera then
        return
    end
    
    cameraState.isSelfie = selfie == true
    cameraState.isStrafing = false
    cameraState.fov = cameraState.isSelfie and config.selfie.defaultFOV or config.defaultFOV
    cameraState.playerPed = PlayerPedId()
    cameraState.savedViewMode = GetFollowPedCamViewMode()
    cameraState.pitch = 0.0
    cameraState.vehicleYaw = 0.0
    cameraState.roll = 0.0
    cameraState.isFrozen = false
    
    -- Create camera
    cameraState.activeCamera = CreateCam("DEFAULT_SCRIPTED_CAMERA", true)
    cameraState.baseSensitivity = GetProfileSetting(754) + 10
    cameraState.currentZoom = 1.0
    
    SetPhoneAction("camera")
    
    -- Start rotation thread for frozen camera
    CreateThread(function()
        while cameraState.activeCamera do
            Wait(0)
            if (cameraState.isStrafing or cameraState.isFrozen) and not IsNuiFocused() then
                handleFrozenRotation()
            end
        end
    end)
    
    -- Start main camera thread
    CreateThread(function()
        while cameraState.activeCamera do
            Wait(0)
            updateCamera()
        end
        
        -- Cleanup radio state
        if cameraState.disabledRadio then
            cameraState.disabledRadio = false
            SetUserRadioControlEnabled(true)
        end
    end)
    
    -- Setup camera
    SetCamFov(cameraState.activeCamera, cameraState.fov)
    RenderScriptCams(true, false, 0, true, true)
    SetCamActive(cameraState.activeCamera, true)
    
    SendReactMessage("camera:setZoom", 1.0)
    updateZoomLevels()
end

-- Disable walkable camera
function DisableWalkableCam()
    if not cameraState.activeCamera then
        return
    end
    
    RenderScriptCams(false, false, 0, true, true)
    DestroyCam(cameraState.activeCamera, false)
    SetFollowPedCamViewMode(cameraState.savedViewMode)
    SetPhoneAction(IsInCall() and "call" or "default")
    
    cameraState.activeCamera = nil
    
    if cameraState.isFrozen then
        TogglePhoneAnimation(true, "camera")
    end
end

-- Toggle selfie camera
function ToggleSelfieCam(enabled)
    local wasSelfieCam = cameraState.isSelfie
    cameraState.isSelfie = enabled == true
    
    if wasSelfieCam ~= cameraState.isSelfie then
        cameraState.roll = 0.0
        cameraState.pitch = 0.0
    end
end

-- Toggle camera frozen state
function ToggleCameraFrozen()
    if not config.freeze.enabled or not cameraState.activeCamera or cameraState.isSelfie then
        return
    end
    
    cameraState.isFrozen = not cameraState.isFrozen
    
    if cameraState.isFrozen then
        TogglePhoneAnimation(false, "camera")
        cameraState.freezeTimer = GetGameTimer() + config.freeze.maxTime
    end
end

-- Check if walking cam is enabled
function IsWalkingCamEnabled()
    return cameraState.activeCamera ~= nil
end

-- Check if selfie cam is active
function IsSelfieCam()
    return cameraState.isSelfie
end

-- Handle key press events
AddEventHandler("Danger_Phone:keyPressed", function(key)
    if not cameraState.activeCamera then
        return
    end
    
    if key == "FreezeCamera" then
        if config.freeze.enabled and not cameraState.isSelfie then
            ToggleCameraFrozen()
        end
    elseif key == "RollLeft" or key == "RollRight" then
        if not config.rollEnabled then
            return
        end
        
        local rollDirection = key == "RollLeft" and -0.5 or 0.5
        local keyBind = Config.KeyBinds[key].bindData
        
        while keyBind.pressed do
            Wait(0)
            cameraState.roll = cameraState.roll + rollDirection
        end
    end
end)

-- Exports
exports("EnableWalkableCam", EnableWalkableCam)
exports("DisableWalkableCam", DisableWalkableCam)
exports("ToggleSelfieCam", ToggleSelfieCam)
exports("ToggleCameraFrozen", ToggleCameraFrozen)
exports("IsWalkingCamEnabled", IsWalkingCamEnabled)
exports("IsSelfieCam", IsSelfieCam)