-- Security state variables
local cachedPin = nil
local cachedFaceId = nil
local userIdentifier = nil

-- Reset all security data
function ResetSecurity(skipUI)
    debugprint("ResetSecurity triggered")
    
    cachedPin = nil
    cachedFaceId = nil
    userIdentifier = nil
    
    if not skipUI then
        SendReactMessage("resetSecurity")
    end
end

-- Get user identifier for face unlock
function GetIdentifier()
    if not userIdentifier then
        userIdentifier = AwaitCallback("security:getIdentifier")
        debugprint("getIdentifier:", userIdentifier)
    end
    
    return userIdentifier or "unknown"
end

-- Validate PIN format
local function validatePin(pin)
    if not pin or type(pin) ~= "string" then
        return false
    end
    
    if #pin ~= 4 then
        debugprint("invalid data.pin: invalid length", pin)
        return false
    end
    
    if not tonumber(pin) then
        debugprint("invalid data.pin: failed to convert to number", pin)
        return false
    end
    
    return true
end

-- Security NUI Callback Handler
RegisterNUICallback("Security", function(data, cb)
    local action = data.action
    debugprint("Security:" .. (action or ""), data)
    
    -- Set PIN
    if action == "setPin" then
        -- Check if new PIN is same as old
        if data.pin == cachedPin then
            debugprint("Failed to set pin: new pin is the same as the old pin")
            return cb(false)
        end
        
        -- Validate PIN format
        if not validatePin(data.pin) then
            debugprint("Failed to set pin: invalid pin")
            return cb(false)
        end
        
        -- Update PIN on server
        local success = AwaitCallback("security:setPin", data.pin, cachedPin)
        
        if success then
            debugprint("Successfully set pin to", data.pin)
            cachedPin = data.pin
        else
            debugprint("Failed to set pin")
        end
        
        cb(success)
        
    -- Remove PIN
    elseif action == "removePin" then
        local success = AwaitCallback("security:removePin", cachedPin)
        
        if success then
            ResetSecurity()
        end
        
        cb(success)
        
    -- Verify PIN
    elseif action == "verifyPin" then
        -- Check cached PIN first
        if cachedPin then
            debugprint("Has cached pin", cachedPin, data.pin)
            return cb(cachedPin == data.pin)
        end
        
        -- Validate PIN format
        if not validatePin(data.pin) then
            debugprint("Failed to verify pin: invalid pin")
            return cb(false)
        end
        
        -- Verify with server
        local success = AwaitCallback("security:verifyPin", data.pin)
        debugprint("security:verifyPin returned:", success)
        
        if success then
            debugprint("Correct pin, caching it", data.pin)
            cachedPin = data.pin
        end
        
        cb(success)
        
    -- Enable Face Unlock
    elseif action == "setFaceId" then
        -- Verify PIN first
        if not cachedPin or cachedPin ~= data.pin then
            debugprint("Failed to enable Face Unlock: incorrect pin")
            debugprint(cachedPin, data.pin)
            return cb(false)
        end
        
        debugprint("Correct pin, triggering enableFaceUnlock")
        TriggerCallback("security:enableFaceUnlock", cb, data.pin)
        
    -- Disable Face Unlock
    elseif action == "removeFaceId" then
        -- Verify PIN first
        if not cachedPin or cachedPin ~= data.pin then
            debugprint("Failed to disable Face Unlock: incorrect pin")
            return cb(false)
        end
        
        debugprint("Correct pin, triggering disableFaceUnlock")
        TriggerCallback("security:disableFaceUnlock", cb, data.pin)
        
    -- Verify Face
    elseif action == "verifyFace" then
        -- Check if face is obstructed (mask, helmet, etc.)
        if IsFaceObstructed() then
            debugprint("Face is obstructed")
            return cb(false)
        end
        
        -- Get identifier if not cached
        if not userIdentifier then
            GetIdentifier()
        end
        
        -- Check cached face ID first
        if cachedFaceId then
            debugprint("Has cached face, returning:", cachedFaceId == userIdentifier)
            return cb(cachedFaceId == userIdentifier)
        end
        
        -- Verify with server
        local success = AwaitCallback("security:verifyFace")
        debugprint("security:verifyFace returned:", success)
        
        if success then
            cachedFaceId = userIdentifier
        end
        
        cb(success)
        
    -- Factory Reset
    elseif action == "factoryReset" then
        TriggerServerEvent("phone:factoryReset")
    end
end)

-- Handle factory reset event
RegisterNetEvent("phone:factoryReset", function()
    OnDeath()  -- Clear phone state
    ResetSecurity()
    FetchPhone()  -- Reload phone data
end)

-- Handle security reset for specific phone
RegisterNetEvent("phone:security:reset", function(phoneNumber)
    if phoneNumber == currentPhone then
        ResetSecurity()
        Wait(500)
        FetchPhone()
    end
end)

-- Exports
exports("ResetSecurity", ResetSecurity)
exports("GetIdentifier", GetIdentifier)