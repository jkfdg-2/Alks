-- Handle UI errors and phone crashes
RegisterNUICallback("logError", function(data, cb)
    -- Check if using production build
    local uiPage = GetResourceMetadata(GetCurrentResourceName(), "ui_page", 0)
    
    if uiPage == "ui/dist/index.html" then
        -- Extract error details
        local errorMessage = data.error or "No error message"
        local stackTrace = data.stack or "No stack"
        local componentStack = data.componentStack or "No component stack"
        
        -- Send error to server for logging
        TriggerServerEvent("phone:logError", errorMessage, stackTrace, componentStack)
    end
    
    -- Store phone state before crash recovery
    local wasPhoneOpen = phoneOpen
    
    -- Reset phone state
    OnDeath()
    
    -- Reopen phone if it was open before crash
    if wasPhoneOpen then
        debugprint("Opening phone due to error")
        ToggleOpen(true)
    end
    
    -- Wait before showing notification
    Wait(5000)
    
    -- Notify user about the crash
    TriggerEvent("phone:sendNotification", {
        app = "Settings",
        title = "System Crash",
        content = "Your phone crashed. Press F8 for more info."
    })
    
    cb("ok")
end)