-- Get nearby devices (phones/tablets) that are currently open
local function getNearbyDevices()
    local devices = {}
    local nearbyPlayers = GetNearbyPlayers()
    local myCoords = GetEntityCoords(PlayerPedId())
    
    debugprint("Nearby players:", nearbyPlayers)
    
    for i = 1, #nearbyPlayers do
        local player = nearbyPlayers[i]
        local playerState = Player(player.source).state
        
        debugprint("Player data", player.source, player)
        
        -- Check if player is within 7.5 units distance
        local playerCoords = GetEntityCoords(player.ped)
        local distance = #(myCoords - playerCoords)
        
        if distance <= 7.5 then
            -- Check if player has tablet open
            if playerState.lbTabletOpen and playerState.lbTabletName then
                table.insert(devices, {
                    name = playerState.lbTabletName,
                    source = player.source,
                    device = "tablet"
                })
            -- Check if player has phone open
            elseif playerState.phoneOpen and playerState.phoneName then
                table.insert(devices, {
                    name = playerState.phoneName,
                    source = player.source,
                    device = "phone"
                })
            end
        end
    end
    
    debugprint("Nearby devices:", devices)
    return devices
end

-- AirShare NUI Callback Handler
RegisterNUICallback("AirShare", function(data, cb)
    if not currentPhone then
        return
    end
    
    local action = data.action
    debugprint("AirShare:" .. (action or ""))
    
    if action == "getNearby" then
        -- Return list of nearby devices
        cb(getNearbyDevices())
        
    elseif action == "share" then
        -- Share data with another device
        TriggerCallback("airShare:share", cb, data.source, data.device, data.data)
        
    elseif action == "accept" then
        -- Accept incoming share request
        TriggerServerEvent("phone:airShare:interacted", data.source, data.device, true)
        cb("ok")
        
    elseif action == "deny" then
        -- Deny incoming share request
        TriggerServerEvent("phone:airShare:interacted", data.source, data.device, false)
        cb("ok")
    end
end)

-- Handle received AirShare data
RegisterNetEvent("phone:airShare:received", function(data)
    debugprint("phone:airShare:received", data)
    SendReactMessage("airShare:received", data)
end)

-- Handle AirShare interaction response
RegisterNetEvent("phone:airShare:interacted", function(source, accepted)
    SendReactMessage("airShare:interacted", {
        source = source,
        accepted = accepted
    })
end)