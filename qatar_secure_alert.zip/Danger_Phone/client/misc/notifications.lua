-- Store notifications with actions
local notificationsWithActions = {}

-- Get all notifications from server
local function getNotifications()
    local notifications = AwaitCallback("getNotifications")
    
    for i = 1, #notifications do
        local notification = notifications[i]
        
        -- Handle legacy format (content as title)
        if notification.content == nil then
            notification.content = notification.title
            notification.title = nil
        end
        
        -- Parse custom data for action buttons
        if notification.custom_data then
            local customData = json.decode(notification.custom_data)
            
            if customData.buttons then
                notification.actions = customData.buttons
                notificationsWithActions[notification.id] = notification
            end
            
            notification.custom_data = nil
        end
    end
    
    return notifications
end

-- Delete a notification
local function deleteNotification(notificationId)
    if not notificationId then
        return true
    end
    
    -- Handle client-side notifications
    if type(notificationId) == "string" and notificationId:find("client%-notification%-") then
        notificationsWithActions[notificationId] = nil
        return true
    end
    
    -- Delete server-side notification
    local success = AwaitCallback("deleteNotification", notificationId)
    
    if not success then
        return false
    end
    
    -- Clean up local storage
    if notificationsWithActions[notificationId] then
        notificationsWithActions[notificationId] = nil
    end
    
    return success
end

-- Clear all notifications for an app
local function clearNotifications(appName)
    local success = AwaitCallback("clearNotifications", appName)
    
    if not success then
        return false
    end
    
    -- Clean up local storage
    for i = 1, #notificationsWithActions do
        local notification = notificationsWithActions[i]
        if notification.app == appName then
            notificationsWithActions[i] = nil
        end
    end
    
    return success
end

-- Handle notification button press
local function handleNotificationButton(notificationId, buttonIndex)
    local notification = notificationsWithActions[notificationId]
    
    if not notification or not notification.actions then
        debugprint("No buttons found for notification", notificationId)
        return false
    end
    
    local button = notification.actions[buttonIndex]
    
    if not button then
        debugprint("Button not found for notification", notificationId, buttonIndex)
        return false
    end
    
    -- Trigger button event
    if button.event then
        if button.server then
            TriggerServerEvent(button.event, button.data)
        else
            TriggerEvent(button.event, button.data)
        end
    end
    
    return true
end

-- NUI Callback for notifications
RegisterNUICallback("Notifications", function(data, cb)
    local action = data.action
    debugprint("Notifications:" .. (action or ""))
    
    if action == "getNotifications" then
        return cb(getNotifications())
        
    elseif action == "deleteNotification" then
        if data.id ~= nil then
            return cb(deleteNotification(data.id))
        end
        
    elseif action == "clearNotifications" then
        return cb(clearNotifications(data.app))
        
    elseif action == "button" then
        cb(handleNotificationButton(data.id, (data.buttonId or 0) + 1))
    end
end)

-- Handle incoming notifications
RegisterNetEvent("phone:sendNotification", function(notification)
    -- Check if player has phone and it's not disabled
    if not HasPhoneItem(currentPhone) or phoneDisabled then
        debugprint("no phone, not showing notification")
        return
    end
    
    -- Handle legacy format
    if notification.content == nil then
        notification.content = notification.title
        notification.title = nil
    end
    
    -- Process custom data for action buttons
    if notification.customData and notification.customData.buttons and notification.id then
        notification.actions = notification.customData.buttons
        notificationsWithActions[notification.id] = notification
        notification.customData = nil
    end
    
    -- Send to UI
    SendReactMessage("newNotification", notification)
end)

-- Export: Send client-side notification
exports("SendNotification", function(notification)
    -- Generate unique client-side ID
    notification.id = "client-notification-" .. math.random()
    
    -- Trigger the notification event
    TriggerEvent("phone:sendNotification", notification)
end)