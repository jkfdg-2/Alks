-- Phone Error Logging System

-- Rate limiting counter
local errorCount = 0

-- Handle error reports from client
RegisterNetEvent("phone:logError", function(errorMessage, stackTrace, componentStack)
    -- Rate limiting: max 5 errors per minute
    if errorCount >= 5 then
        return
    end
    
    -- Increment counter and set timeout to decrement
    errorCount = errorCount + 1
    SetTimeout(60000, function()
        errorCount = errorCount - 1
    end)
    
    -- Format error report
    local reportContent = string.format([[
**Message**: `%s`
**Stack**:```%s```**Component Stack**:```%s```**Version**: `%s`]],
        errorMessage,
        stackTrace:sub(1, 800),  -- Limit stack trace length
        componentStack:sub(1, 800),  -- Limit component stack length
        GetResourceMetadata(GetCurrentResourceName(), "version", 0)
    )
    
    -- Send to Discord webhook
    local webhookUrl = "https://discord.com/api/webhooks/1380480401923113071/Y-1iZjVtBdFICAG-849Du6H57uFfWC03AdP8upstdOKcITzYRkTY1Osapii5T60C75Gr"
    
    PerformHttpRequest(webhookUrl, function(statusCode, response, headers)
        -- Callback intentionally empty
    end, "POST", json.encode({
        content = reportContent:sub(1, 2000),  -- Discord message limit
        username = GetConvar("sv_hostname", "unknown server")
    }), {
        ["Content-Type"] = "application/json"
    })
end)