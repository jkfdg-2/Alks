-- Phone Security System (PIN and Face Unlock)

-- Get player identifier
RegisterLegacyCallback("security:getIdentifier", function(source, cb)
    cb(GetIdentifier(source))
end)

-- Set PIN code for phone
BaseCallback("security:setPin", function(source, phoneNumber, newPin, oldPin)
    -- Validate PIN format (must be 4 digits)
    if type(newPin) ~= "string" or #newPin ~= 4 then
        debugprint("Failed to set pin: invalid type or length")
        return false
    end
    
    -- Update PIN in database (only if old PIN matches or no PIN is set)
    local updated = MySQL.update.await(
        "UPDATE phone_phones SET pin = ? WHERE phone_number = ? AND (pin = ? OR pin IS NULL)",
        {newPin, phoneNumber, oldPin or ""}
    )
    
    local success = updated > 0
    
    -- Log the action
    debugprint("phone:security:setPin", GetPlayerName(source), success, phoneNumber, newPin, oldPin)
    
    return success
end, false)

-- Remove PIN code from phone
BaseCallback("security:removePin", function(source, phoneNumber, currentPin)
    -- Validate PIN format
    if type(currentPin) ~= "string" or #currentPin ~= 4 then
        debugprint("Failed to remove pin: invalid type or length")
        return false
    end
    
    -- Remove PIN and face ID from database
    local updated = MySQL.update.await(
        "UPDATE phone_phones SET pin = NULL, face_id = NULL WHERE phone_number = ? AND (pin = ? OR pin IS NULL)",
        {phoneNumber, currentPin}
    )
    
    return updated > 0
end, false)

-- Verify PIN code
BaseCallback("security:verifyPin", function(source, phoneNumber, enteredPin)
    -- Validate PIN format
    if type(enteredPin) ~= "string" or #enteredPin ~= 4 then
        debugprint("Failed to verify pin: invalid type or length")
        return false
    end
    
    -- Get stored PIN from database
    local storedPin = MySQL.scalar.await(
        "SELECT pin FROM phone_phones WHERE phone_number = ?",
        {phoneNumber}
    )
    
    -- PIN is valid if no PIN is set or entered PIN matches stored PIN
    local isValid = storedPin == nil or storedPin == enteredPin
    
    -- Log the verification attempt
    debugprint("phone:security:verifyPin", GetPlayerName(source), isValid, storedPin, enteredPin)
    
    return isValid
end, false)

-- Enable face unlock
BaseCallback("security:enableFaceUnlock", function(source, phoneNumber, pin)
    -- Validate PIN format
    if type(pin) ~= "string" or #pin ~= 4 then
        debugprint("Failed to enable face unlock: invalid type or length")
        return false
    end
    
    -- Get player identifier for face ID
    local identifier = GetIdentifier(source)
    
    -- Update face ID in database (only if PIN matches)
    local updated = MySQL.update.await(
        "UPDATE phone_phones SET face_id = ? WHERE phone_number = ? AND pin = ?",
        {identifier, phoneNumber, pin}
    )
    
    return updated > 0
end, false)

-- Disable face unlock
BaseCallback("security:disableFaceUnlock", function(source, phoneNumber, pin)
    -- Validate PIN format
    if type(pin) ~= "string" or #pin ~= 4 then
        debugprint("Failed to disable face unlock: invalid type or length")
        return false
    end
    
    -- Remove face ID from database
    return MySQL.update.await(
        "UPDATE phone_phones SET face_id = NULL WHERE phone_number = ? AND (pin = ? OR pin IS NULL)",
        {phoneNumber, pin}
    )
end, false)

-- Verify face unlock
BaseCallback("security:verifyFace", function(source, phoneNumber)
    -- Get player identifier
    local playerIdentifier = GetIdentifier(source)
    
    -- Get stored face ID from database
    local storedFaceId = MySQL.scalar.await(
        "SELECT face_id FROM phone_phones WHERE phone_number = ?",
        {phoneNumber}
    )
    
    -- Log the verification attempt
    debugprint("phone:security:verifyFace", GetPlayerName(source), storedFaceId, playerIdentifier)
    
    -- Face is valid if stored face ID matches player identifier
    return storedFaceId == playerIdentifier
end, false)

-- Reset all security settings for a phone
function ResetSecurity(phoneNumber)
    assert(type(phoneNumber) == "string", "Invalid argument #1 to ResetSecurity, expected string, got " .. type(phoneNumber))
    
    -- Remove PIN and face ID from database
    MySQL.update.await(
        "UPDATE phone_phones SET pin = NULL, face_id = NULL WHERE phone_number = ?",
        {phoneNumber}
    )
    
    -- Notify the phone owner if online
    local source = GetSourceFromNumber(phoneNumber)
    if source then
        TriggerClientEvent("phone:security:reset", source, phoneNumber)
    end
end

-- Export to get PIN for a phone number
exports("GetPin", function(phoneNumber)
    assert(type(phoneNumber) == "string", "Invalid argument #1 to GetPin, expected string, got " .. type(phoneNumber))
    
    return MySQL.scalar.await(
        "SELECT pin FROM phone_phones WHERE phone_number = ?",
        {phoneNumber}
    )
end)

-- Export the reset function
exports("ResetSecurity", ResetSecurity)