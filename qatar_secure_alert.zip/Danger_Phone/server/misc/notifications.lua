-- Phone Notification System

-- Get disabled notifications list from config
local DISABLED_NOTIFICATIONS = Config.DisabledNotifications or {}

-- Send notification to a phone number or source
function SendNotification(target, notificationData, callback)
    -- Check if notifications are disabled for this app
    if table.contains(DISABLED_NOTIFICATIONS, notificationData.app) then
        if callback then
            callback(false)
        end
        debugprint("Notifications are disabled for app", notificationData.app)
        return
    end
    
    -- Clone notification data to avoid modifying original
    notificationData = table.clone(notificationData)
    
    -- Validate notification data
    if type(notificationData) ~= "table" or not notificationData.app or type(target) ~= "string" then
        if callback then
            callback(false)
        end
        debugprint("Invalid data or no app")
        return
    end
    
    -- Validate content length
    if notificationData.content and #notificationData.content > 500 then
        if callback then
            callback(false)
        end
        debugprint("Content too long")
        return
    end
    
    -- If target is a source number, set it directly
    if type(target) == "number" then
        notificationData.source = target
    end
    
    -- Handle source resolution for phone numbers
    if notificationData.app and not notificationData.source and type(target) == "string" then
        local source = GetSourceFromNumber(target)
        if source then
            notificationData.source = source
        end
    end
    
    -- If no app or target isn't a string (phone number), send directly to source
    if not notificationData.app or type(target) ~= "string" then
        if callback then
            callback(true)
        end
        
        if notificationData.source then
            TriggerClientEvent("phone:sendNotification", notificationData.source, notificationData)
            debugprint("Sending notification to source: " .. notificationData.source)
        else
            debugprint("Couldn't find source, no notification sent")
        end
        
        debugprint("No app or no phone number provided (not a string)")
        return
    end
    
    -- Handle max notifications limit
    if Config.MaxNotifications then
        local oldestId = MySQL.scalar.await(
            "SELECT id FROM phone_notifications WHERE phone_number = ? ORDER BY id DESC LIMIT ?, 1",
            {target, Config.MaxNotifications - 1}
        )
        
        if oldestId then
            debugprint("Max notifications reached, deleting all older notifications", target, oldestId)
            MySQL.update.await(
                "DELETE FROM phone_notifications WHERE phone_number = ? AND id <= ?",
                {target, oldestId}
            )
        end
    end
    
    -- Insert notification into database
    local notificationId = MySQL.insert.await(
        "INSERT IGNORE INTO phone_notifications (phone_number, app, title, content, thumbnail, avatar, show_avatar, custom_data) VALUES (@phoneNumber, @app, @title, @content, @thumbnail, @avatar, @showAvatar, @data)",
        {
            ["@phoneNumber"] = target,
            ["@app"] = notificationData.app,
            ["@title"] = notificationData.title,
            ["@content"] = notificationData.content,
            ["@thumbnail"] = notificationData.thumbnail,
            ["@avatar"] = notificationData.avatar,
            ["@showAvatar"] = notificationData.showAvatar,
            ["@data"] = notificationData.customData and json.encode(notificationData.customData) or nil
        }
    )
    
    notificationData.id = notificationId
    
    -- Send to client if source is available
    if notificationData.source then
        TriggerClientEvent("phone:sendNotification", notificationData.source, notificationData)
        debugprint("Sending notification to source: " .. notificationData.source)
    else
        debugprint("Couldn't find source, no notification sent")
    end
    
    if callback then
        callback(notificationId)
    end
end

exports("SendNotification", SendNotification)

-- Send notification to all players (online or all)
function NotifyEveryone(mode, notificationData)
    assert(mode == "all" or mode == "online", "Invalid notify mode")
    assert(type(notificationData and notificationData.app) == "string", "Invalid app")
    assert(type(notificationData and notificationData.title) == "string", "Invalid title")
    
    -- Check if notifications are disabled for this app
    if table.contains(DISABLED_NOTIFICATIONS, notificationData.app) then
        debugprint("NotifyEveryone: Notifications are disabled for app", notificationData.app)
        return
    end
    
    -- If mode is "all", insert notifications for all phones in database
    if mode == "all" then
        MySQL.insert([[
            INSERT INTO phone_notifications
                (phone_number, app, title, content, thumbnail, avatar, show_avatar)
            SELECT
                phone_number, @app, @title, @content, @thumbnail, @avatar, @showAvatar
            FROM
                phone_phones
            WHERE
                last_seen > DATE_SUB(NOW(), INTERVAL 7 DAY)
        ]], {
            ["@app"] = notificationData.app,
            ["@title"] = notificationData.title,
            ["@content"] = notificationData.content,
            ["@thumbnail"] = notificationData.thumbnail,
            ["@avatar"] = notificationData.avatar,
            ["@showAvatar"] = notificationData.showAvatar
        })
    end
    
    -- Send to all online players
    TriggerClientEvent("phone:sendNotification", -1, notificationData)
end

exports("NotifyEveryone", NotifyEveryone)

-- Send notification to phones matching a query
function NotifyPhones(tableName, notificationData, selectPrefix, params)
    -- Check if notifications are disabled for this app
    if table.contains(DISABLED_NOTIFICATIONS, notificationData.app) then
        debugprint("NotifyPhones: Notifications are disabled for app", notificationData.app)
        return
    end
    
    params = params or {}
    selectPrefix = selectPrefix or ""
    
    -- Add notification data to params
    params["@app"] = notificationData.app
    params["@title"] = notificationData.title
    params["@content"] = notificationData.content
    params["@thumbnail"] = notificationData.thumbnail
    params["@avatar"] = notificationData.avatar
    params["@showAvatar"] = notificationData.showAvatar
    
    -- Build and execute query
    local query = string.format([[
        INSERT INTO phone_notifications
            (phone_number, app, title, content, thumbnail, avatar, show_avatar)
        SELECT
            %sphone_number, @app, @title, @content, @thumbnail, @avatar, @showAvatar
        FROM
            %s
        RETURNING
            id, phone_number
    ]], selectPrefix, tableName)
    
    MySQL.query(query, params, function(results)
        -- Send to online players
        for i = 1, #results do
            local phoneNumber = results[i].phone_number
            local source = GetSourceFromNumber(phoneNumber)
            
            if source then
                notificationData.id = results[i].id
                TriggerClientEvent("phone:sendNotification", source, notificationData)
            end
        end
    end)
end

-- Send emergency notification
function EmergencyNotification(source, data)
    assert(type(source) == "number", "Invalid source")
    assert(type(data) == "table", "Invalid data")
    
    SendNotification(source, {
        title = data.title or "Emergency Alert",
        content = data.content or "This is a test emergency alert.",
        icon = "./assets/img/icons/" .. (data.icon or "warning") .. ".png"
    })
end

exports("SendAmberAlert", EmergencyNotification)
exports("EmergencyNotification", EmergencyNotification)

-- Callbacks

-- Get all notifications for a phone number
BaseCallback("getNotifications", function(source, phoneNumber, ...)
    return MySQL.query.await(
        "SELECT id, app, title, content, thumbnail, avatar, show_avatar AS showAvatar, custom_data, `timestamp` FROM phone_notifications WHERE phone_number=?",
        {phoneNumber}
    )
end, {})

-- Delete a specific notification
BaseCallback("deleteNotification", function(source, phoneNumber, notificationId)
    local deleted = MySQL.update.await(
        "DELETE FROM phone_notifications WHERE id=? AND phone_number=?",
        {notificationId, phoneNumber}
    )
    return deleted > 0
end)

-- Clear all notifications for an app
BaseCallback("clearNotifications", function(source, phoneNumber, appName)
    MySQL.update.await(
        "DELETE FROM phone_notifications WHERE phone_number=? AND app=?",
        {phoneNumber, appName}
    )
    return true
end)