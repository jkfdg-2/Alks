-- Social Media Account Management System

-- Supported apps configuration
local SUPPORTED_APPS = {
    twitter = true,
    instagram = true,
    tiktok = true
}

-- App name aliases (frontend names to backend names)
local APP_ALIASES = {
    birdy = "twitter",
    instapic = "instagram",
    trendy = "tiktok"
}

-- App display names for notifications
local APP_DISPLAY_NAMES = {
    twitter = "Twitter",
    instagram = "Instagram",
    tiktok = "TikTok"
}

-- Username field mapping for different apps
local USERNAME_FIELDS = {
    twitter = "username",
    instagram = "username",
    tiktok = "username",
    mail = "address",
    darkchat = "username"
}

-- Helper function to normalize app name
local function normalizeAppName(appName)
    assert(type(appName) == "string", "Invalid app")
    appName = appName:lower()
    
    -- Convert alias to actual app name if needed
    if not SUPPORTED_APPS[appName] then
        appName = tostring(APP_ALIASES[appName])
    end
    
    assert(SUPPORTED_APPS[appName], "Invalid app")
    return appName
end

-- Toggle verified status for a user account
function ToggleVerified(app, username, isVerified)
    app = normalizeAppName(app)
    assert(type(username) == "string", "Invalid username")
    
    -- Trigger event for other resources
    TriggerEvent("Danger_Phone:toggleVerified", app, username, isVerified)
    
    -- Update database
    local affected = MySQL.Sync.execute(
        string.format("UPDATE phone_%s_accounts SET verified=@verified WHERE username=@username", app),
        {
            ["@username"] = username,
            ["@verified"] = isVerified
        }
    )
    
    local success = affected > 0
    
    -- Send notification if verified
    if success and isVerified then
        local displayName = APP_DISPLAY_NAMES[app]
        if displayName then
            -- Get all active sessions for this user
            local activeSessions = MySQL.query.await(
                "SELECT phone_number FROM phone_logged_in_accounts WHERE app = ? AND username = ? AND `active` = 1",
                {app, username}
            )
            
            -- Send notification to each active session
            for i = 1, #activeSessions do
                local phoneNumber = activeSessions[i].phone_number
                SendNotification(phoneNumber, {
                    app = displayName,
                    title = L("BACKEND.MISC.VERIFIED")
                })
            end
        end
    end
    
    return success
end

exports("ToggleVerified", ToggleVerified)

-- Check if a user is verified
exports("IsVerified", function(app, username)
    app = normalizeAppName(app)
    assert(type(username) == "string", "Invalid username")
    
    local isVerified = MySQL.Sync.fetchScalar(
        string.format("SELECT verified FROM phone_%s_accounts WHERE username=@username", app),
        {["@username"] = username}
    )
    
    return isVerified or false
end)

-- Change password for an account
function ChangePassword(app, username, newPassword)
    assert(type(app) == "string", "Invalid app")
    app = app:lower()
    
    -- Convert alias if needed
    if not USERNAME_FIELDS[app] then
        app = tostring(APP_ALIASES[app])
    end
    
    assert(USERNAME_FIELDS[app], "Invalid app")
    assert(type(username) == "string", "Invalid username")
    assert(type(newPassword) == "string", "Invalid password")
    
    -- Update password in database
    local usernameField = USERNAME_FIELDS[app]
    local affected = MySQL.Sync.execute(
        string.format("UPDATE phone_%s_accounts SET password=@password WHERE %s=@username", app, usernameField),
        {
            ["@username"] = username,
            ["@password"] = GetPasswordHash(newPassword)
        }
    )
    
    if affected == 0 then
        return false
    end
    
    -- Log out all sessions for this account
    MySQL.update(
        "DELETE FROM phone_logged_in_accounts WHERE app = ? AND username = ?",
        {app, username}
    )
    
    return true
end

exports("ChangePassword", ChangePassword)

-- Get equipped phone number with multiple input support
exports("GetEquippedPhoneNumber", function(input)
    -- If input is a number (source), use the original function
    if type(input) == "number" then
        return GetEquippedPhoneNumber(input)
    end
    
    -- If input is an identifier, try to get source first
    local source = GetSourceFromIdentifier and GetSourceFromIdentifier(input)
    if source then
        return GetEquippedPhoneNumber(source)
    end
    
    -- Otherwise, look up directly in database
    local tableName = Config.Item.Unique and "phone_last_phone" or "phone_phones"
    local idField = "id"
    
    return MySQL.scalar.await(
        string.format("SELECT phone_number FROM %s WHERE %s = ?", tableName, idField),
        {input}
    )
end)