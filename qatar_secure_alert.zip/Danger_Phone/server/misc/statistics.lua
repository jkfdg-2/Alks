-- Analytics and Event Tracking System

-- Get resource version
local RESOURCE_VERSION = GetResourceMetadata(GetCurrentResourceName(), "version", 0) or "0.0.0"

-- Check if UI is modified
local isUIModified = GetResourceMetadata(GetCurrentResourceName(), "ui_page", 0) ~= "ui/dist/index.html"

-- Configuration
local MAX_EVENTS_BATCH = 25
local VIDEO_EXTENSIONS = {"webm", "mp4", "mov"}

-- State variables
local eventQueue = {}
local eventCount = 0
local serverId = nil

-- Validate version format
if not RESOURCE_VERSION:match("^%d+%.%d+%.%d+$") then
    RESOURCE_VERSION = "0.0.0"
end

-- Send analytics data to tracking server
local function sendAnalytics(forceSend)
    -- Only send if we have events or forced
    if eventCount == 0 and not forceSend then
        return
    end
    
    -- Skip if batch limit not reached (unless forced)
    if eventCount < MAX_EVENTS_BATCH and not forceSend then
        return
    end
    
    -- Get server ID from CFX configuration if not cached
    if not serverId then
        local webBaseUrl = GetConvar("web_baseUrl", "")
        if webBaseUrl == "" then
            return
        end
        
        -- Extract server ID from URL
        local urlLength = #webBaseUrl
        local lastDashPos = webBaseUrl:reverse():find("-") or (#webBaseUrl + 1)
        local startPos = urlLength - lastDashPos + 2
        local endPos = urlLength - #".users.cfx.re"
        
        serverId = string.sub(webBaseUrl, startPos, endPos)
    end
    
    -- Prepare data payload
    local payload = json.encode({
        serverId = serverId,
        version = RESOURCE_VERSION,
        events = eventQueue
    })
    
    -- Reset queue
    eventCount = 0
    eventQueue = {}
    
    -- Send to tracking server
   
end

-- Track simple events
function TrackSimpleEvent(eventName)
    if isUIModified then
        return
    end
    
    eventCount = eventCount + 1
    eventQueue[eventCount] = {
        event = eventName
    }
    
    sendAnalytics()
end

-- Track social media posts with attachments
function TrackSocialMediaPost(appName, attachments)
    if isUIModified then
        return
    end
    
    local photoCount = 0
    local videoCount = 0
    
    -- Count media types
    if attachments then
        for i = 1, #attachments do
            local attachment = attachments[i]
            local extension = attachment:match("%.([^.]+)$") or "webp"
            
            if table.contains(VIDEO_EXTENSIONS, extension) then
                videoCount = videoCount + 1
            else
                photoCount = photoCount + 1
            end
        end
    end
    
    -- Add to queue
    eventCount = eventCount + 1
    eventQueue[eventCount] = {
        event = "social_media_post",
        app = appName,
        amountVideos = videoCount,
        amountPhotos = photoCount
    }
    
    sendAnalytics()
end

-- Event handlers for sending analytics before shutdown

-- Send analytics 60 seconds before scheduled restart
AddEventHandler("txAdmin:events:scheduledRestart", function(eventData)
    if eventData.secondsRemaining == 60 then
        sendAnalytics(true)
    end
end)

-- Send analytics on server shutdown
AddEventHandler("txAdmin:events:serverShuttingDown", function()
    sendAnalytics(true)
end)

-- Send analytics when resource stops
AddEventHandler("onResourceStop", function(resourceName)
    if resourceName == GetCurrentResourceName() then
        sendAnalytics(true)
    end
end)