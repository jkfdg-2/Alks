-- Phone Battery System

-- Storage for battery levels
local batteryLevels = {}

-- Handle battery level updates from client
RegisterNetEvent("phone:battery:setBattery", function(batteryLevel)
    local source = source
    
    -- Validate battery system is enabled and level is valid
    if not Config.Battery.Enabled then
        return debugprint("setBattery: battery system disabled")
    end
    
    if type(batteryLevel) ~= "number" or batteryLevel < 0 or batteryLevel > 100 then
        return debugprint("setBattery: invalid battery level")
    end
    
    -- Get player's phone number
    local phoneNumber = GetEquippedPhoneNumber(source)
    if not phoneNumber then
        return
    end
    
    -- Store battery level
    batteryLevels[phoneNumber] = batteryLevel
end)

-- Check if a phone's battery is dead
function IsPhoneDead(phoneNumber)
    if not Config.Battery.Enabled then
        return false
    end
    
    return batteryLevels[phoneNumber] == 0
end

exports("IsPhoneDead", IsPhoneDead)

-- Save battery level to database
function SaveBattery(source)
    local phoneNumber = GetEquippedPhoneNumber(source)
    
    -- Skip if no phone or no battery data
    if not phoneNumber or not batteryLevels[phoneNumber] then
        return
    end
    
    debugprint(string.format("saving battery level (%s) for %s", batteryLevels[phoneNumber], phoneNumber))
    
    -- Update database
    MySQL.update(
        "UPDATE phone_phones SET battery = ? WHERE phone_number = ?",
        {batteryLevels[phoneNumber], phoneNumber},
        function()
            -- Clear from memory after saving
            batteryLevels[phoneNumber] = nil
        end
    )
end

exports("SaveBattery", SaveBattery)

-- Save all battery levels
function SaveAllBatteries()
    debugprint("saving all battery levels")
    
    local players = GetPlayers()
    for i = 1, #players do
        SaveBattery(players[i])
    end
end

exports("SaveAllBatteries", SaveAllBatteries)

-- Event handlers for automatic battery saving

-- Save when player disconnects
AddEventHandler("playerDropped", function()
    SaveBattery(source)
end)

-- Save before scheduled restart
AddEventHandler("txAdmin:events:scheduledRestart", function(eventData)
    if eventData.secondsRemaining == 60 then
        SaveAllBatteries()
    end
end)

-- Save on server shutdown
AddEventHandler("txAdmin:events:serverShuttingDown", SaveAllBatteries)

-- Save when resource stops
AddEventHandler("onResourceStop", function(resourceName)
    if resourceName == GetCurrentResourceName() then
        SaveAllBatteries()
    end
end)