-- Phone Backup System

-- Create a backup of phone data
BaseCallback("backup:createBackup", function(source, phoneNumber)
    local identifier = GetIdentifier(source)
    
    local affected = MySQL.update.await([[
        INSERT INTO phone_backups (id, phone_number) VALUES (@identifier, @phoneNumber)
        ON DUPLICATE KEY UPDATE phone_number = @phoneNumber
    ]], {
        ["@identifier"] = identifier,
        ["@phoneNumber"] = phoneNumber
    })
    
    return affected > 0
end)

-- Apply a backup to restore phone data
BaseCallback("backup:applyBackup", function(source, currentPhoneNumber, backupPhoneNumber)
    local identifier = GetIdentifier(source)
    
    -- Verify backup exists and belongs to player
    local backupExists = MySQL.scalar.await(
        "SELECT 1 FROM phone_backups WHERE id = ? AND phone_number = ?",
        {identifier, backupPhoneNumber}
    )
    
    -- Don't apply if backup doesn't exist or trying to restore to same number
    if not backupExists or currentPhoneNumber == backupPhoneNumber then
        return false
    end
    
    local params = {
        ["@number"] = backupPhoneNumber,
        ["@phoneNumber"] = currentPhoneNumber
    }
    
    -- Get phone data from both phones
    local phones = MySQL.query.await(
        "SELECT settings, pin, face_id, phone_number FROM phone_phones WHERE phone_number = @number OR phone_number = @phoneNumber",
        params
    )
    
    -- Determine which phone is current and which is backup
    local currentPhone = phones[1] and phones[1].phone_number == currentPhoneNumber and phones[1] or phones[2]
    local backupPhone = phones[1] and phones[1].phone_number == currentPhoneNumber and phones[2] or phones[1]
    
    if not currentPhone or not backupPhone then
        return false
    end
    
    -- Parse and merge settings
    currentPhone.settings = json.decode(backupPhone.settings)
    
    -- Preserve security settings if they don't exist in current phone
    if currentPhone.settings.security.pinCode and not currentPhone.pin then
        currentPhone.settings.security.pinCode = false
    end
    
    if currentPhone.settings.security.faceId and not currentPhone.face_id then
        currentPhone.settings.security.faceId = false
    end
    
    -- Update phone settings
    MySQL.update.await(
        "UPDATE phone_phones SET settings = ? WHERE phone_number = ?",
        {json.encode(currentPhone.settings), currentPhoneNumber}
    )
    
    -- Copy photos from backup (avoiding duplicates)
    MySQL.update.await([[
        INSERT IGNORE INTO phone_photos (phone_number, link, is_video, size, `timestamp`)
        SELECT @phoneNumber, link, is_video, size, `timestamp`
        FROM phone_photos
        WHERE phone_number = @number AND link NOT IN (SELECT link FROM phone_photos WHERE phone_number = @phoneNumber)
    ]], params)
    
    -- Copy contacts from backup (avoiding duplicates)
    MySQL.update.await([[
        INSERT IGNORE INTO phone_phone_contacts (contact_phone_number, firstname, lastname, profile_image, favourite, phone_number)
        SELECT contact_phone_number, firstname, lastname, profile_image, favourite, @phoneNumber
        FROM phone_phone_contacts
        WHERE phone_number = @number AND contact_phone_number NOT IN (SELECT contact_phone_number FROM phone_phone_contacts WHERE phone_number = @phoneNumber)
    ]], params)
    
    -- Copy map locations from backup (avoiding duplicates)
    MySQL.update.await([[
        INSERT IGNORE INTO phone_maps_locations (id, phone_number, `name`, x_pos, y_pos)
        SELECT id, @phoneNumber, `name`, x_pos, y_pos
        FROM phone_maps_locations
        WHERE phone_number = @number AND id NOT IN (SELECT id FROM phone_maps_locations WHERE phone_number = @phoneNumber)
    ]], params)
    
    return true
end)

-- Delete a backup
BaseCallback("backup:deleteBackup", function(source, phoneNumber, backupNumber)
    local identifier = GetIdentifier(source)
    
    local affected = MySQL.update.await(
        "DELETE FROM phone_backups WHERE id = ? AND phone_number = ?",
        {identifier, backupNumber}
    )
    
    return affected > 0
end)

-- Get all backups for a player
BaseCallback("backup:getBackups", function(source, phoneNumber)
    local identifier = GetIdentifier(source)
    
    return MySQL.query.await(
        "SELECT phone_number AS `number` FROM phone_backups WHERE id = ?",
        {identifier}
    )
end)