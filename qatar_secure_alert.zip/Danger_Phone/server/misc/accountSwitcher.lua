-- Active accounts cache: [app][phoneNumber] = username
local activeAccountsCache = {}

-- Supported apps configuration
local supportedApps = {
    Twitter = true,
    Instagram = true,
    Mail = true,
    TikTok = true,
    DarkChat = true
}

-- App name mappings
local appNameMappings = {
    instapic = "Instagram",
    birdy = "Twitter",
    trendy = "TikTok",
    darkchat = "DarkChat",
    mail = "Mail"
}

-- Initialize cache for each supported app
for appName, _ in pairs(supportedApps) do
    activeAccountsCache[appName] = {}
end

-- Switch account callback
BaseCallback("accountSwitcher:switchAccount", function(source, phoneNumber, app, username)
    -- Validate app
    if not supportedApps[app] then
        return false
    end
    
    -- Check if user is logged into this account
    local isLoggedIn = MySQL.scalar.await(
        "SELECT TRUE FROM phone_logged_in_accounts WHERE phone_number = ? AND app = ? AND username = ?",
        {phoneNumber, app, username}
    )
    
    if not isLoggedIn then
        print(("Possible abuse? %s (%i) tried to switch to an account they aren't logged into."):format(
            GetPlayerName(source), source
        ))
        return false
    end
    
    -- Update active account
    local success = MySQL.update.await(
        "UPDATE phone_logged_in_accounts SET `active` = (username = ?) WHERE phone_number = ? AND app = ?",
        {username, phoneNumber, app}
    ) > 0
    
    if success then
        activeAccountsCache[app][phoneNumber] = username
        TriggerEvent("phone:loggedInToAccount", app, phoneNumber, username)
    end
    
    return success
end)

-- Get accounts callback
BaseCallback("accountSwitcher:getAccounts", function(source, phoneNumber, app)
    -- Validate app
    if not supportedApps[app] then
        return {}
    end
    
    return MySQL.query.await(
        "SELECT username FROM phone_logged_in_accounts WHERE phone_number = ? AND app = ?",
        {phoneNumber, app}
    )
end)

-- Add logged in account
function AddLoggedInAccount(phoneNumber, app, username)
    -- Validate inputs
    assert(supportedApps[app], "Invalid app: " .. app)
    assert(type(phoneNumber) == "string", "Invalid phone number. Expected string.")
    assert(type(username) == "string", "Invalid username. Expected string.")
    
    -- Deactivate other accounts for this phone/app
    MySQL.update.await(
        "UPDATE phone_logged_in_accounts SET `active` = 0 WHERE phone_number = ? AND app = ? AND username != ?",
        {phoneNumber, app, username}
    )
    
    -- Add/activate the account
    local success = MySQL.update.await(
        "INSERT INTO phone_logged_in_accounts (phone_number, app, username, active) VALUES (?, ?, ?, 1) ON DUPLICATE KEY UPDATE active = 1",
        {phoneNumber, app, username}
    ) > 0
    
    if success then
        activeAccountsCache[app][phoneNumber] = username
        TriggerEvent("phone:loggedInToAccount", app, phoneNumber, username)
    end
    
    return success
end

-- Remove logged in account
function RemoveLoggedInAccount(phoneNumber, app, username)
    -- Validate inputs
    assert(supportedApps[app], "Invalid app: " .. app)
    assert(type(phoneNumber) == "string", "Invalid phone number. Expected string.")
    assert(type(username) == "string", "Invalid username. Expected string.")
    
    -- Delete the account
    local success = MySQL.update.await(
        "DELETE FROM phone_logged_in_accounts WHERE phone_number = ? AND app = ? AND username = ?",
        {phoneNumber, app, username}
    ) > 0
    
    if success then
        -- Clear cache if this was the active account
        if activeAccountsCache[app][phoneNumber] == username then
            activeAccountsCache[app][phoneNumber] = nil
        end
        TriggerEvent("phone:loggedOutFromAccount", app, username, phoneNumber)
    end
    
    return success
end

-- Get logged in account for a phone number and app
function GetLoggedInAccount(phoneNumber, app, skipCache)
    -- Validate inputs
    assert(supportedApps[app], "Invalid app: " .. app)
    assert(type(phoneNumber) == "string", "Invalid phone number. Expected string.")
    
    -- Check cache first
    if activeAccountsCache[app][phoneNumber] then
        return activeAccountsCache[app][phoneNumber]
    end
    
    -- Query database
    local username = MySQL.scalar.await(
        "SELECT username FROM phone_logged_in_accounts WHERE phone_number = ? AND app = ? AND active = 1",
        {phoneNumber, app}
    )
    
    -- Update cache
    if username and not skipCache then
        debugprint("AccountSwitcher: Setting cache for " .. phoneNumber .. ", logged in as " .. username .. " on " .. app)
        activeAccountsCache[app][phoneNumber] = username
    end
    
    return username or false
end

-- Get all phone numbers logged into a specific account
function GetLoggedInNumbers(app, username)
    -- Validate inputs
    assert(supportedApps[app], "Invalid app: " .. app)
    assert(type(username) == "string", "Invalid username. Expected string.")
    
    local results = MySQL.query.await(
        "SELECT phone_number FROM phone_logged_in_accounts WHERE app = ? AND username = ?",
        {app, username}
    )
    
    if not results then
        return {}
    end
    
    -- Extract phone numbers from results
    local phoneNumbers = {}
    for i = 1, #results do
        phoneNumbers[#phoneNumbers + 1] = results[i].phone_number
    end
    
    return phoneNumbers
end

-- Get all active accounts for an app
function GetActiveAccounts(app)
    return activeAccountsCache[app] or {}
end

-- Clear active accounts cache for a specific username
function ClearActiveAccountsCache(app, username, exceptPhoneNumber)
    -- Validate inputs
    assert(supportedApps[app], "Invalid app: " .. app)
    assert(type(username) == "string", "Invalid username. Expected string.")
    
    -- Clear cache entries for this username except the specified phone number
    for phoneNumber, cachedUsername in pairs(activeAccountsCache[app]) do
        if cachedUsername == username and phoneNumber ~= exceptPhoneNumber then
            activeAccountsCache[app][phoneNumber] = nil
        end
    end
end

-- Export: Get social media username
exports("GetSocialMediaUsername", function(phoneNumber, app)
    -- Validate inputs
    assert(type(phoneNumber) == "string", "Invalid phone number. Expected string.")
    assert(type(app) == "string", "Invalid app. Expected string.")
    assert(appNameMappings[app], "Invalid app: " .. app)
    
    return GetLoggedInAccount(phoneNumber, appNameMappings[app], true)
end)

-- Clean up when player drops
AddEventHandler("playerDropped", function()
    local phoneNumber = GetEquippedPhoneNumber(source)
    if not phoneNumber then return end
    
    -- Clear all cached accounts for this phone number
    for app, accounts in pairs(activeAccountsCache) do
        if accounts[phoneNumber] then
            accounts[phoneNumber] = nil
            debugprint("AccountSwitcher: Player dropped, logging out " .. phoneNumber .. " from " .. app)
        end
    end
end)