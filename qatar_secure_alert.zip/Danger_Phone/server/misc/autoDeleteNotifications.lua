-- Auto-delete old notifications system

-- Check if auto-delete is enabled
if not Config.AutoDeleteNotifications then
    return
end

-- Validate and set default value if needed
if type(Config.AutoDeleteNotifications) ~= "number" then
    Config.AutoDeleteNotifications = 168 -- Default to 7 days (168 hours)
end

-- Wait for system initialization
Wait(5000)

-- Main cleanup loop
while true do
    debugprint("Deleting all old notifications..")
    
    local startTime = os.nanotime()
    
    -- Delete notifications older than configured hours
    MySQL.update(
        "DELETE FROM phone_notifications WHERE `timestamp` < DATE_SUB(NOW(), INTERVAL ? HOUR)",
        {Config.AutoDeleteNotifications},
        function(deletedCount)
            -- Calculate execution time
            local executionTime = (os.nanotime() - startTime) / 1000000.0
            
            -- Log result
            local pluralSuffix = deletedCount == 1 and "" or "s"
            debugprint(string.format(
                "Deleted %d notification%s in %.2f ms", 
                deletedCount, 
                pluralSuffix, 
                executionTime
            ))
        end
    )
    
    -- Wait 1 hour before next cleanup
    Wait(3600000)
end