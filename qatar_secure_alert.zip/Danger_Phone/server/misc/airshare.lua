-- Pending album shares: [targetSource][senderSource] = albumId
local pendingAlbumShares = {}

-- AirShare callback handler
BaseCallback("airShare:share", function(senderSource, phoneNumber, targetSource, targetDevice, shareData)
    -- Get sender's phone name
    local senderName = Player(senderSource).state.phoneName
    if not senderName then
        debugprint("No sender name")
        return false
    end
    
    -- Add sender information to share data
    shareData.sender = {
        name = senderName,
        source = senderSource,
        device = "phone"
    }
    
    -- Handle tablet sharing
    if targetDevice == "tablet" then
        -- Check if tablet resource is running and target has tablet open
        if GetResourceState("lb-tablet") ~= "started" or not Player(targetSource).state.lbTabletOpen then
            return false
        end
        
        TriggerClientEvent("tablet:airShare:received", targetSource, shareData)
        
    -- Handle phone sharing
    elseif targetDevice == "phone" then
        -- Check if target has phone open
        if not Player(targetSource).state.phoneOpen then
            debugprint("sendToSource's phone is not open")
            return false
        end
        
        TriggerClientEvent("phone:airShare:received", targetSource, shareData)
    end
    
    -- Track album shares for acceptance/rejection
    if shareData.type == "album" then
        if not pendingAlbumShares[targetSource] then
            pendingAlbumShares[targetSource] = {}
        end
        pendingAlbumShares[targetSource][senderSource] = shareData.album.id
    end
    
    return true
end, false)

-- Handle AirShare interaction response
RegisterNetEvent("phone:airShare:interacted", function(senderSource, senderDevice, accepted)
    local targetSource = source
    
    -- Validate parameters
    if type(senderSource) ~= "number" or type(senderDevice) ~= "string" then
        debugprint("AirShare:interacted: Invalid senderSource or senderDevice", senderSource, senderDevice)
        return
    end
    
    -- Notify sender of interaction
    if senderDevice == "tablet" then
        TriggerClientEvent("tablet:airShare:interacted", senderSource, targetSource, accepted)
    elseif senderDevice == "phone" then
        TriggerClientEvent("phone:airShare:interacted", senderSource, targetSource, accepted)
    end
    
    -- Handle pending album shares
    if pendingAlbumShares[targetSource] and pendingAlbumShares[targetSource][senderSource] then
        local albumId = pendingAlbumShares[targetSource][senderSource]
        
        -- Clean up pending share
        pendingAlbumShares[targetSource][senderSource] = nil
        if not next(pendingAlbumShares[targetSource]) then
            pendingAlbumShares[targetSource] = nil
        end
        
        -- Process album share
        if not accepted then
            debugprint("AirShare: denied album share", albumId)
            return
        end
        
        debugprint("AirShare: accepted album share", albumId)
        HandleAcceptAirShareAlbum(targetSource, senderSource, albumId)
    end
end)

-- Valid share types
local validShareTypes = {
    image = true,
    contact = true,
    location = true,
    note = true,
    voicememo = true
}

-- Export for external resources to use AirShare
exports("AirShare", function(senderSource, targetSource, shareType, data)
    -- Validate parameters
    assert(type(senderSource) == "number", "Invalid sender")
    assert(type(targetSource) == "number", "Invalid target")
    assert(validShareTypes[shareType], "Invalid shareType")
    assert(type(data) == "table", "Invalid data")
    
    -- Check if sender has a phone equipped
    local senderPhoneNumber = GetEquippedPhoneNumber(senderSource)
    if not senderPhoneNumber then
        return false
    end
    
    -- Build share data structure
    local shareData = {
        type = shareType,
        sender = {
            name = Player(senderSource)?.state.phoneName or senderPhoneNumber,
            source = senderSource,
            device = "phone"
        }
    }
    
    -- Process different share types
    if shareType == "image" then
        shareData.attachment = data
        assert(data.src, "Invalid image data (missing src)")
        
        -- Add timestamp if not provided
        if not shareData.attachment.timestamp then
            shareData.attachment.timestamp = os.time() * 1000
        end
        
    elseif shareType == "contact" then
        shareData.contact = data
        assert(type(shareData.contact.number) == "string", "Invalid/missing contact data (contact.number)")
        assert(type(shareData.contact.firstname) == "string", "Invalid/missing contact data (contact.firstname)")
        
    elseif shareType == "location" then
        assert(data.location, "Invalid location data (missing location)")
        assert(type(data.name) == "string", "Invalid/missing location data (location.name)")
        shareData.location = data.location
        shareData.name = data.name
        
    elseif shareType == "note" then
        shareData.note = data
        assert(type(shareData.note.title) == "string", "Invalid/missing note data (note.title)")
        assert(type(shareData.note.content) == "string", "Invalid/missing note data (note.content)")
        
    elseif shareType == "voicememo" then
        shareData.voicememo = data
        assert(type(shareData.voicememo.title) == "string", "Invalid/missing voicememo data (voicememo.title)")
        assert(type(shareData.voicememo.src) == "string", "Invalid/missing voicememo data (voicememo.src)")
        assert(type(shareData.voicememo.duration) == "number", "Invalid/missing voicememo data (voicememo.duration)")
    end
    
    -- Send to target device (phone)
    TriggerClientEvent("phone:airShare:received", targetSource, shareData)
end)

-- Clean up when player drops
AddEventHandler("playerDropped", function()
    local source = source
    pendingAlbumShares[source] = nil
end)