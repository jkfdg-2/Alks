-- Register callback for purchasing apps from the app store
RegisterLegacyCallback("appstore:buyApp", function(source, callback, price)
    -- Get the player's equipped phone number
    local phoneNumber = GetEquippedPhoneNumber(source)
    
    -- Check if player has a phone equipped
    if not phoneNumber then
        callback(false)
        return
    end
    
    -- Attempt to remove money from player and return result
    callback(RemoveMoney(source, price))
end)