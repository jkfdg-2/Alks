-- Table to track players who have disabled company calls
local disabledCompanyCalls = {}

-- Get contact information for a phone number
function GetContact(ownerNumber, contactNumber, callback)
    local params = {contactNumber, ownerNumber, contactNumber}
    local query = [[
        SELECT
            CONCAT(firstname, ' ', lastname) AS `name`, profile_image AS avatar, firstname, lastname, email, address, contact_phone_number AS `number`, favourite,
            (IF((SELECT TRUE FROM phone_phone_blocked_numbers b WHERE b.phone_number=? AND b.blocked_number=`number`), TRUE, FALSE)) AS blocked
        FROM
            phone_phone_contacts
        WHERE
            contact_phone_number=? AND phone_number=?
    ]]
    
    if callback then
        return MySQL.single(query, params, callback)
    else
        return MySQL.single.await(query, params)
    end
end

-- Create a new contact
function CreateContact(phoneNumber, contactData)
    local affected = MySQL.Sync.execute([[
        INSERT INTO phone_phone_contacts (contact_phone_number, firstname, lastname, profile_image, email, address, phone_number)
        VALUES (@contactNumber, @firstname, @lastname, @avatar, @email, @address, @phoneNumber)
        ON DUPLICATE KEY UPDATE firstname=@firstname, lastname=@lastname, profile_image=@avatar, email=@email, address=@address
    ]], {
        ["@contactNumber"] = contactData.number,
        ["@firstname"] = contactData.firstname,
        ["@lastname"] = contactData.lastname or "",
        ["@avatar"] = contactData.avatar,
        ["@email"] = contactData.email,
        ["@address"] = contactData.address,
        ["@phoneNumber"] = phoneNumber
    })
    
    return affected > 0
end

-- Save contact
BaseCallback("saveContact", function(source, phoneNumber, contactData)
    return CreateContact(phoneNumber, contactData)
end, false)

-- Get all contacts
BaseCallback("getContacts", function(source, phoneNumber)
    return MySQL.query.await([[
        SELECT contact_phone_number AS number, firstname, lastname, profile_image AS avatar, favourite,
            (IF((SELECT TRUE FROM phone_phone_blocked_numbers b WHERE b.phone_number=@phoneNumber AND b.blocked_number=`number`), TRUE, FALSE)) AS blocked
        FROM phone_phone_contacts c
        WHERE c.phone_number=@phoneNumber
    ]], {
        ["@phoneNumber"] = phoneNumber
    })
end, {})

-- Toggle block status
BaseCallback("toggleBlock", function(source, phoneNumber, targetNumber, shouldBlock)
    local query = shouldBlock and 
        "INSERT INTO phone_phone_blocked_numbers (phone_number, blocked_number) VALUES (@phoneNumber, @number) ON DUPLICATE KEY UPDATE phone_number=@phoneNumber" or
        "DELETE FROM phone_phone_blocked_numbers WHERE phone_number=@phoneNumber AND blocked_number=@number"
    
    MySQL.update.await(query, {
        ["@phoneNumber"] = phoneNumber,
        ["@number"] = targetNumber
    })
    
    return shouldBlock
end, false)

-- Toggle favourite status
BaseCallback("toggleFavourite", function(source, phoneNumber, contactNumber, isFavourite)
    MySQL.update.await(
        "UPDATE phone_phone_contacts SET favourite=@favourite WHERE contact_phone_number=@number AND phone_number=@phoneNumber",
        {
            ["@phoneNumber"] = phoneNumber,
            ["@number"] = contactNumber,
            ["@favourite"] = isFavourite == true
        }
    )
    return true
end, false)

-- Remove contact
BaseCallback("removeContact", function(source, phoneNumber, contactNumber)
    MySQL.update.await(
        "DELETE FROM phone_phone_contacts WHERE contact_phone_number=? AND phone_number=?",
        {contactNumber, phoneNumber}
    )
    return true
end, false)

-- Update contact
BaseCallback("updateContact", function(source, phoneNumber, contactData)
    MySQL.update.await(
        "UPDATE phone_phone_contacts SET firstname=@firstname, lastname=@lastname, profile_image=@avatar, email=@email, address=@address, contact_phone_number=@newNumber WHERE contact_phone_number=@number AND phone_number=@phoneNumber",
        {
            ["@phoneNumber"] = phoneNumber,
            ["@number"] = contactData.oldNumber,
            ["@newNumber"] = contactData.number,
            ["@firstname"] = contactData.firstname,
            ["@lastname"] = contactData.lastname or "",
            ["@avatar"] = contactData.avatar,
            ["@email"] = contactData.email,
            ["@address"] = contactData.address
        }
    )
    return true
end, false)

-- Get recent calls
BaseCallback("getRecentCalls", function(source, phoneNumber, missedOnly, page)
    missedOnly = missedOnly == true
    
    local query = [[
        SELECT
            duration, answered, `timestamp`, IF(caller=@phoneNumber, callee, caller) AS `number`, IF(caller=@phoneNumber, true, false) AS called,
            IF(callee=@phoneNumber, hide_caller_id, FALSE) AS hideCallerId,
            (IF((SELECT TRUE FROM phone_phone_blocked_numbers b WHERE b.phone_number=@phoneNumber AND b.blocked_number=`number`), TRUE, FALSE)) AS blocked
        FROM phone_phone_calls
        WHERE callee=@phoneNumber ]] .. (missedOnly and "AND answered=0" or "OR caller=@phoneNumber") .. [[
        ORDER BY `timestamp` DESC
        LIMIT @page, @perPage
    ]]
    
    local calls = MySQL.query.await(query, {
        ["@phoneNumber"] = phoneNumber,
        ["@page"] = (page or 0) * 25,
        ["@perPage"] = 25
    })
    
    -- Process results
    for i = 1, #calls do
        local call = calls[i]
        call.hideCallerId = call.hideCallerId == true
        call.blocked = call.blocked == true
        call.called = call.called == true
        
        if call.hideCallerId then
            call.number = L("BACKEND.CALLS.NO_CALLER_ID")
        end
    end
    
    return calls
end, {})

-- Get blocked numbers
BaseCallback("getBlockedNumbers", function(source, phoneNumber)
    return MySQL.query.await(
        "SELECT blocked_number AS `number` FROM phone_phone_blocked_numbers WHERE phone_number=?",
        {phoneNumber}
    )
end, {})

-- Active calls tracking
local activeCalls = {}

-- Generate unique call ID
local function generateCallId()
    local id = math.random(999999999)
    while activeCalls[id] do
        id = math.random(999999999)
    end
    return id
end

-- Check if player is in call
local function isPlayerInCall(playerId)
    for callId, callData in pairs(activeCalls) do
        if (callData.caller and callData.caller.source == playerId) or 
           (callData.callee and callData.callee.source == playerId) then
            return true, callId
        end
    end
    return false
end

-- Log call to database
local function logCall(callerNumber, calleeNumber, duration, answered, hideCallerId, initiator)
    MySQL.insert(
        "INSERT INTO phone_phone_calls (caller, callee, duration, answered, hide_caller_id) VALUES (@caller, @callee, @duration, @answered, @hideCallerId)",
        {
            ["@caller"] = callerNumber,
            ["@callee"] = calleeNumber,
            ["@duration"] = duration,
            ["@answered"] = answered,
            ["@hideCallerId"] = hideCallerId
        }
    )
    
    -- Send missed call notification
    if not answered and initiator ~= calleeNumber then
        local phoneExists = MySQL.scalar.await(
            "SELECT TRUE FROM phone_phones WHERE phone_number = ?",
            {calleeNumber}
        )
        
        if not phoneExists then return end
        
        if hideCallerId then
            SendNotification(calleeNumber, {
                app = "Phone",
                title = L("BACKEND.CALLS.NO_CALLER_ID"),
                content = L("BACKEND.CALLS.MISSED_CALL"),
                showAvatar = false
            })
        else
            GetContact(callerNumber, calleeNumber, function(contact)
                SendNotification(calleeNumber, {
                    app = "Phone",
                    title = contact and contact.name or callerNumber,
                    content = L("BACKEND.CALLS.MISSED_CALL"),
                    avatar = contact and contact.avatar,
                    showAvatar = true
                })
            end)
            
            -- Send message about missed call
            SendMessage(callerNumber, calleeNumber, "<!CALL-NO-ANSWER!>")
        end
    end
end

-- Handle player disconnect
AddEventHandler("playerDropped", function()
    local src = source
    disabledCompanyCalls[src] = nil
    EndCall(src)
end)

-- Toggle company calls
RegisterNetEvent("phone:phone:disableCompanyCalls", function(disabled)
    local src = source
    if disabled then
        disabledCompanyCalls[src] = true
    else
        disabledCompanyCalls[src] = nil
    end
end)

-- Log call from client
RegisterNetEvent("phone:logCall", function(calleeNumber, duration, answered)
    local src = source
    local callerNumber = GetEquippedPhoneNumber(src)
    
    if not (callerNumber and calleeNumber) or not duration then
        return
    end
    
    logCall(callerNumber, calleeNumber, duration, answered, false, callerNumber)
end)

-- Make a call
local Tunnel = module("vrp", "lib/Tunnel")
local Proxy = module("vrp", "lib/Proxy")
local vRP = Proxy.getInterface("vRP")

BaseCallback("call", function(source, phoneNumber, callData)
    local user_id = vRP.getUserId({source})
    if not user_id or not vRP.hasPermission({user_id, "phone.call"}) then
        SendNotification(phoneNumber, {
            app = "Phone",
            title = "المكالمات",
            content = "صلاحية اجراء المكالمات فقط لاصحاب الباقات"
        })
        TriggerClientEvent("phone:phone:callPermissionDenied", source)
        return false
    end
    
    if isPlayerInCall(source) then
        return false
    end
    
    local callId = generateCallId()
    local call = {
        started = os.time(),
        answered = false,
        videoCall = callData.videoCall == true,
        hideCallerId = callData.hideCallerId == true,
        callId = callId,
        caller = {
            source = source,
            number = phoneNumber,
            nearby = {}
        }
    }
    
    if callData.company then
        if not Config.Companies.Enabled or callData.videoCall then
            TriggerClientEvent("phone:phone:userBusy", source)
            return false
        end
        
        local isValid = false
        if Config.Companies.Contacts[callData.company] then
            isValid = true
        else
            for i = 1, #Config.Companies.Services do
                if Config.Companies.Services[i].job == callData.company then
                    isValid = true
                    break
                end
            end
        end
        
        if not isValid then
            return false
        end
        
        if not Config.Companies.AllowAnonymous then
            call.hideCallerId = false
        end
        call.videoCall = false
        call.company = callData.company
        call.callee = {nearby = {}}
        
        local employees = GetEmployees(callData.company)
        
        for i = 1, #employees do
            local employee = employees[i]
            if not isPlayerInCall(employee) and employee ~= source and not disabledCompanyCalls[employee] then
                TriggerClientEvent("phone:phone:setCall", employee, {
                    callId = callId,
                    number = phoneNumber,
                    company = callData.company,
                    companylabel = callData.companylabel,
                    hideCallerId = call.hideCallerId
                })
            end
        end
    else
        local isBlocked = MySQL.Sync.fetchScalar([[
            SELECT TRUE FROM phone_phone_blocked_numbers WHERE
                (phone_number = @number1 AND blocked_number = @number2)
                OR (phone_number = @number2 AND blocked_number = @number1)
        ]], {
            ["@number1"] = phoneNumber,
            ["@number2"] = callData.number
        })
        
        if isBlocked then
            TriggerClientEvent("phone:phone:userBusy", source)
            return false
        end
        
        if callData.number == phoneNumber then
            TriggerClientEvent("phone:phone:userBusy", source)
            return false
        end
        
        local calleeSource = GetSourceFromNumber(callData.number)
        local calleeInCall = calleeSource and isPlayerInCall(calleeSource)
        
        if not calleeSource or calleeInCall or IsPhoneDead(callData.number) or HasAirplaneMode(callData.number) then
            logCall(phoneNumber, callData.number, 0, false, callData.hideCallerId)
            
            if calleeInCall then
                TriggerClientEvent("phone:phone:userBusy", source)
            else
                TriggerClientEvent("phone:phone:userUnavailable", source)
            end
            return false
        end
        
        call.callee = {
            source = calleeSource,
            number = callData.number,
            nearby = {}
        }
        
        TriggerClientEvent("phone:phone:setCall", calleeSource, {
            callId = callId,
            number = phoneNumber,
            videoCall = callData.videoCall,
            webRTC = callData.webRTC,
            hideCallerId = callData.hideCallerId
        })
    end
    
    activeCalls[callId] = call
    TriggerEvent("Danger_Phone:newCall", call)
    
    return callId
end)

-- Answer call
RegisterLegacyCallback("answerCall", function(source, cb, callId)
    debugprint("phone:phone:answerCall", source, callId)
    
    local call = activeCalls[callId]
    if not call then
        debugprint("phone:phone:answerCall: invalid call id")
        return cb(false)
    end
    
    -- Handle company call answer
    if call.company then
        if call.callee.source then
            return cb(false)
        end
        
        -- Notify other employees
        local employees = GetEmployees(call.company)
        for i = 1, #employees do
            local employee = employees[i]
            if not isPlayerInCall(employee) and employee ~= source and not disabledCompanyCalls[employee] then
                TriggerClientEvent("phone:phone:endCall", employee, callId)
            end
        end
        
        call.callee.source = source
    else
        -- Verify answerer
        if call.callee.source ~= source then
            debugprint("phone:phone:answerCall: invalid source")
            return cb(false)
        end
    end
    
    -- Set up voice states
    local callerState = Player(call.caller.source).state
    local calleeState = Player(call.callee.source).state
    
    callerState.speakerphone = false
    calleeState.speakerphone = false
    callerState.mutedCall = false
    calleeState.mutedCall = false
    callerState.otherMutedCall = false
    calleeState.otherMutedCall = false
    callerState.onCallWith = call.callee.source
    calleeState.onCallWith = call.caller.source
    callerState.callAnswered = true
    calleeState.callAnswered = true
    
    call.answered = true
    
    -- Connect the call
    TriggerClientEvent("phone:phone:connectCall", source, callId)
    TriggerClientEvent("phone:phone:connectCall", call.caller.source, callId, call.exportCall == true)
    
    -- Set up voice effects
    TriggerClientEvent("phone:phone:setCallEffect", source, call.caller.source, true)
    TriggerClientEvent("phone:phone:setCallEffect", call.caller.source, source, true)
    
    TriggerEvent("Danger_Phone:callAnswered", call)
    debugprint("phone:phone:answerCall: answered call", callId)
    
    cb(true)
end)

-- Request video call
BaseCallback("requestVideoCall", function(source, phoneNumber, callId, enable)
    if not callId or not activeCalls[callId] then
        debugprint("requestVideoCall: invalid call id", callId, json.encode(activeCalls, {indent = true}))
        return false
    end
    
    debugprint("requestVideoCall", source, callId, enable)
    
    local call = activeCalls[callId]
    if call.videoCall or not call.answered then
        return false
    end
    
    local otherParty = call.caller.source == source and call.callee.source or call.caller.source
    call.videoRequested = true
    
    TriggerClientEvent("phone:phone:videoRequested", otherParty, enable)
end)

-- Answer video request
BaseCallback("answerVideoRequest", function(source, phoneNumber, callId, accept)
    if not callId or not activeCalls[callId] then
        debugprint("answerVideoRequest: invalid call id")
        return false
    end
    
    debugprint("answerVideoRequest", source, callId, accept)
    
    local call = activeCalls[callId]
    local otherParty = call.caller.source == source and call.callee.source or call.caller.source
    
    if call.videoCall or not call.answered or not call.videoRequested then
        return false
    end
    
    call.videoRequested = false
    call.videoCall = accept == true
    
    TriggerClientEvent("phone:phone:videoRequestAnswered", otherParty, accept)
    return true
end)

-- Stop video call
BaseCallback("stopVideoCall", function(source, phoneNumber, callId)
    if not callId or not activeCalls[callId] then
        debugprint("stopVideoCall: invalid call id")
        return false
    end
    
    local call = activeCalls[callId]
    local otherParty = call.caller.source == source and call.callee.source or call.caller.source
    
    if not call.videoCall or not call.answered then
        return false
    end
    
    call.videoCall = false
    
    TriggerClientEvent("phone:phone:stopVideoCall", source)
    TriggerClientEvent("phone:phone:stopVideoCall", otherParty)
    
    return true
end)

-- End call function
function EndCall(playerId, callback)
    local inCall, callId = isPlayerInCall(playerId)
    
    debugprint("^5EndCall^7:", playerId, inCall, callId)
    
    if not inCall or not callId or not activeCalls[callId] then
        if callback then
            callback(false)
        end
        debugprint("^5EndCall^7: not in call/invalid callId")
        return false
    end
    
    local call = activeCalls[callId]
    local callerSource = call.caller.source
    local calleeSource = call.callee.source
    
    -- End call for callee
    if calleeSource then
        debugprint("^5EndCall^7: ending call for callee", callId, calleeSource)
        TriggerClientEvent("phone:phone:endCall", calleeSource)
        TriggerClientEvent("phone:phone:removeVoiceTarget", -1, calleeSource, true)
        TriggerClientEvent("phone:phone:removeVoiceTarget", -1, callerSource, true)
        TriggerClientEvent("phone:phone:setCallEffect", calleeSource, callerSource, false)
        TriggerClientEvent("phone:phone:setCallEffect", callerSource, calleeSource, false)
    elseif call.company then
        -- End company call
        local employees = GetEmployees(call.company)
        for i = 1, #employees do
            if not isPlayerInCall(employees[i]) and not disabledCompanyCalls[employees[i]] then
                TriggerClientEvent("phone:phone:endCall", employees[i], callId)
            end
        end
    end
    
    -- End call for caller
    if callerSource then
        debugprint("^5EndCall^7: ending call for caller", callId, callerSource)
        TriggerClientEvent("phone:phone:endCall", callerSource)
    end
    
    -- Clear states
    if callerSource and Player(callerSource) then
        local state = Player(callerSource).state
        state.onCallWith = nil
        state.speakerphone = false
        state.mutedCall = false
        state.otherMutedCall = false
        state.callAnswered = false
    end
    
    if calleeSource and Player(calleeSource) then
        local state = Player(calleeSource).state
        state.onCallWith = nil
        state.speakerphone = false
        state.mutedCall = false
        state.otherMutedCall = false
        state.callAnswered = false
    end
    
    -- Clean up nearby voice targets
    local callerNearby = call.caller.nearby
    local calleeNearby = call.callee.nearby
    
    if callerNearby and calleeSource then
        for i = 1, #callerNearby do
            TriggerClientEvent("phone:phone:removeVoiceTarget", calleeSource, callerNearby[i], true)
            TriggerClientEvent("phone:phone:removeVoiceTarget", callerNearby[i], calleeSource, true)
        end
    end
    
    if calleeNearby and callerSource then
        for i = 1, #calleeNearby do
            TriggerClientEvent("phone:phone:removeVoiceTarget", callerSource, calleeNearby[i], true)
            TriggerClientEvent("phone:phone:removeVoiceTarget", calleeNearby[i], callerSource, true)
        end
    end
    
    -- Log call
    if not call.company then
        logCall(
            call.caller.number,
            call.callee.number,
            os.time() - call.started,
            call.answered,
            call.hideCallerId,
            GetEquippedPhoneNumber(playerId)
        )
    end
    
    TriggerEvent("Danger_Phone:callEnded", call)
    
    -- Log the call
    Log("Calls", call.caller.source, "info",
        L("BACKEND.LOGS.CALL_ENDED"),
        L("BACKEND.LOGS.CALL_DESCRIPTION", {
            duration = os.time() - call.started,
            caller = FormatNumber(call.caller.number),
            callee = call.callee.number and FormatNumber(call.callee.number) or call.company,
            answered = call.answered
        })
    )
    
    activeCalls[callId] = nil
    
    if callback then
        callback(true)
    end
    
    return true
end

-- End call event
RegisterNetEvent("phone:endCall", function()
    EndCall(source)
end)

-- Get recent voicemails
BaseCallback("getRecentVoicemails", function(source, phoneNumber, page)
    return MySQL.query.await([[
        SELECT id, IF(hide_caller_id, null, caller) AS `number`, url, duration, hide_caller_id AS hideCallerId, `timestamp`
        FROM phone_phone_voicemail
        WHERE callee = ?
        ORDER BY `timestamp` DESC
        LIMIT ?, ?
    ]], {phoneNumber, (page or 0) * 25, 25})
end, {})

-- Delete voicemail
BaseCallback("deleteVoiceMail", function(source, phoneNumber, voicemailId)
    local deleted = MySQL.update.await(
        "DELETE FROM phone_phone_voicemail WHERE id = ? AND callee = ?",
        {voicemailId, phoneNumber}
    ) > 0
    return deleted
end)

-- Send voicemail
BaseCallback("sendVoicemail", function(source, phoneNumber, voicemailData)
    MySQL.insert.await(
        "INSERT INTO phone_phone_voicemail (caller, callee, url, duration, hide_caller_id) VALUES (@caller, @callee, @url, @duration, @hideCallerId)",
        {
            ["@caller"] = phoneNumber,
            ["@callee"] = voicemailData.number,
            ["@url"] = voicemailData.src,
            ["@duration"] = voicemailData.duration,
            ["@hideCallerId"] = voicemailData.hideCallerId == true
        }
    )
    
    SendNotification(voicemailData.number, {
        app = "Phone",
        title = L("BACKEND.CALLS.NEW_VOICEMAIL")
    })
    
    return true
end)

-- Check if phone has airplane mode
function HasAirplaneMode(phoneNumber)
    debugprint("checking if", phoneNumber, "has airplane mode enabled")
    local settings = GetSettings(phoneNumber)
    if not settings then
        debugprint("no settings found for", phoneNumber)
        return
    end
    return settings.airplaneMode
end

-- Voice chat proximity handlers
RegisterNetEvent("phone:phone:toggleMute", function(muted)
    local src = source
    Player(src).state.mutedCall = muted == true
    
    local inCall, callId = isPlayerInCall(src)
    if inCall then
        local call = activeCalls[callId]
        local otherParty = call.caller.source == src and call.callee.source or call.caller.source
        Player(otherParty).state.otherMutedCall = muted == true
    end
end)

RegisterNetEvent("phone:phone:toggleSpeaker", function(enabled)
    Player(source).state.speakerphone = enabled == true
end)

RegisterNetEvent("phone:phone:enteredCallProximity", function(playerInCall)
    local src = source
    local inCall, callId = isPlayerInCall(playerInCall)
    
    if not inCall then return end
    
    local call = activeCalls[callId]
    if not call.answered then return end
    
    local isCaller = call.caller.source == playerInCall
    local nearbyList = isCaller and call.caller.nearby or call.callee.nearby
    local otherParty = isCaller and call.callee.source or call.caller.source
    
    -- Add voice targets
    TriggerClientEvent("phone:phone:addVoiceTarget", otherParty, src, true, true)
    TriggerClientEvent("phone:phone:addVoiceTarget", src, otherParty, false, true)
    
    if not table.contains(nearbyList, src) then
        table.insert(nearbyList, src)
    end
end)

RegisterNetEvent("phone:phone:leftCallProximity", function(playerInCall)
    local src = source
    local inCall, callId = isPlayerInCall(playerInCall)
    
    if not inCall then return end
    
    local call = activeCalls[callId]
    if not call.answered then return end
    
    local isCaller = call.caller.source == playerInCall
    local nearbyList = isCaller and call.caller.nearby or call.callee.nearby
    local contains, index = table.contains(nearbyList, src)
    
    if contains then
        local otherParty = isCaller and call.callee.source or call.caller.source
        
        -- Remove voice targets
        TriggerClientEvent("phone:phone:removeVoiceTarget", otherParty, src, true)
        TriggerClientEvent("phone:phone:removeVoiceTarget", src, otherParty, true)
        
        table.remove(nearbyList, index)
    end
end)

RegisterNetEvent("phone:phone:listenToPlayer", function(targetPlayer)
    local src = source
    debugprint(src, "started listening to", targetPlayer)
    
    TriggerClientEvent("phone:phone:addVoiceTarget", src, targetPlayer, true, true)
    TriggerClientEvent("phone:phone:addVoiceTarget", targetPlayer, src, false, true)
end)

RegisterNetEvent("phone:phone:stopListeningToPlayer", function(targetPlayer)
    local src = source
    debugprint(src, "stopped listening to to", targetPlayer)
    
    TriggerClientEvent("phone:phone:removeVoiceTarget", src, targetPlayer)
    TriggerClientEvent("phone:phone:removeVoiceTarget", targetPlayer, src)
end)

-- Exports
exports("HasAirplaneMode", HasAirplaneMode)

exports("CreateCall", function(caller, calleeOrCompany, options)
    assert(type(caller) == "table", "caller must be a table")
    assert(type(caller.source) == "number", "caller.source must be a number")
    assert(type(caller.phoneNumber) == "string", "caller.phoneNumber must be a string")
    assert(type(calleeOrCompany) == "string", "callee/options.company must be a string")
    
    options = options or {}
    assert(type(options) == "table", "options must be a table or nil")
    
    local callerSrc = caller.source
    local callerNumber = caller.phoneNumber
    
    if not GetPlayerName(callerSrc) then
        return debugprint("CreateCall: callerSrc is not a valid player")
    end
    
    if options.requirePhone and (IsPhoneDead(callerNumber) or not HasPhoneItem(callerSrc, callerNumber)) then
        return debugprint("CreateCall: caller does not have a phone")
    end
    
    if isPlayerInCall(callerSrc) then
        return debugprint("CreateCall: caller is already in a call")
    end
    
    local callId = generateCallId()
    local call = {
        started = os.time(),
        answered = false,
        videoCall = false,
        hideCallerId = options.hideNumber == true,
        callId = callId,
        caller = {
            source = callerSrc,
            number = callerNumber
        },
        exportCall = true
    }
    
    if options.company then
        if not Config.Companies.Enabled then
            debugprint("company calls are disabled in config")
            return
        end
        
        -- Validate company
        local isValid = false
        local companyLabel = options.company
        
        if Config.Companies.Contacts[options.company] then
            companyLabel = Config.Companies.Contacts[options.company].name
            isValid = true
        else
            for i = 1, #Config.Companies.Services do
                local service = Config.Companies.Services[i]
                if service.job == options.company then
                    isValid = true
                    companyLabel = service.name
                    break
                end
            end
        end
        
        if not isValid then
            debugprint("invalid company")
            return
        end
        
        call.company = options.company
        call.callee = {}
        
        -- Notify employees
        local employees = GetEmployees(options.company)
        for i = 1, #employees do
            local employee = employees[i]
            if not isPlayerInCall(employee) and employee ~= callerSrc and not disabledCompanyCalls[employee] then
                TriggerClientEvent("phone:phone:setCall", employee, {
                    callId = callId,
                    number = callerNumber,
                    company = options.company,
                    companylabel = companyLabel
                })
            end
        end
    else
        -- Regular call
        local calleeSrc = GetSourceFromNumber(calleeOrCompany)
        if not calleeSrc then
            return debugprint("CreateCall: calleeSrc is not a valid player")
        end
        
        if isPlayerInCall(calleeSrc) then
            return debugprint("CreateCall: caller or callee is in call")
        end
        
        call.callee = {
            source = calleeSrc,
            number = calleeOrCompany
        }
        
        TriggerClientEvent("phone:phone:setCall", calleeSrc, {
            callId = callId,
            number = callerNumber,
            hideCallerId = options.hideNumber == true
        })
    end
    
    activeCalls[callId] = call
    TriggerEvent("Danger_Phone:newCall", call)
    TriggerClientEvent("phone:phone:enableExportCall", callerSrc)
    
    return callId
end)

exports("GetCall", function(callId)
    return activeCalls[callId]
end)

exports("AddContact", function(phoneNumber, contactData)
    assert(type(phoneNumber) == "string", "phoneNumber must be a string")
    assert(type(contactData) == "table", "data must be a table")
    
    local success = CreateContact(phoneNumber, contactData)
    debugprint("AddContact: success", success)
    
    local playerSource = GetSourceFromNumber(phoneNumber)
    if playerSource and success then
        TriggerClientEvent("phone:phone:contactAdded", playerSource, contactData)
    end
end)

exports("EndCall", EndCall)
exports("IsInCall", isPlayerInCall)