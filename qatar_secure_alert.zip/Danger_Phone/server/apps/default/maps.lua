-- Get all saved locations for a phone number
BaseCallback("maps:getSavedLocations", function(source, phoneNumber)
    local locations = MySQL.query.await(
        "SELECT id, `name`, x_pos, y_pos FROM phone_maps_locations WHERE phone_number = ? ORDER BY `name` ASC",
        {phoneNumber}
    )
    
    -- Transform the data to the expected format
    for i = 1, #locations do
        local location = locations[i]
        locations[i] = {
            id = location.id,
            name = location.name,
            position = {location.y_pos, location.x_pos}  -- Note: y comes before x in the position array
        }
    end
    
    return locations
end, {})

-- Add a new location
BaseCallback("maps:addLocation", function(source, phoneNumber, name, xPos, yPos)
    return MySQL.insert.await(
        "INSERT INTO phone_maps_locations (phone_number, `name`, x_pos, y_pos) VALUES (?, ?, ?, ?)",
        {phoneNumber, name, xPos, yPos}
    )
end)

-- Rename an existing location
BaseCallback("maps:renameLocation", function(source, phoneNumber, locationId, newName)
    local rowsAffected = MySQL.update.await(
        "UPDATE phone_maps_locations SET `name` = ? WHERE id = ? AND phone_number = ?",
        {newName, locationId, phoneNumber}
    )
    return rowsAffected > 0
end)

-- Remove a saved location
BaseCallback("maps:removeLocation", function(source, phoneNumber, locationId)
    local rowsAffected = MySQL.update.await(
        "DELETE FROM phone_maps_locations WHERE id = ? AND phone_number = ?",
        {locationId, phoneNumber}
    )
    return rowsAffected > 0
end)