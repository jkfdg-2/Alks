-- Cache for base URL
local baseUrlCache = nil

-- Register callback for getting base URL
RegisterCallback("camera:getBaseUrl", function()
    if not baseUrlCache then
        baseUrlCache = GetConvar("web_baseUrl", "")
    end
    return baseUrlCache
end)

-- Media types enum
local MediaTypes = {
    Audio = "audio",
    Image = "image",
    Video = "video"
}

-- Register callback for getting presigned URL
RegisterCallback("camera:getPresignedUrl", function(source, mediaType)
    local mediaTypeValue = MediaTypes[mediaType]
    if not mediaTypeValue then
        return
    end

    -- Check upload method
    if Config.UploadMethod[mediaType] ~= "Fivemanage" then
        if GetPresignedUrl then
            return GetPresignedUrl(source, mediaType)
        else
            infoprint("warning", "GetPresignedUrl has not been set up. Set it up in Danger_Phone/server/custom/functions/functions.lua, or change your upload method to Fivemanage.")
        end
        return
    end

    -- Handle Fivemanage upload
    local promise = promise.new()
    
    PerformHttpRequest(
        "https://fmapi.net/api/v2/presigned-url?fileType=" .. mediaTypeValue,
        function(statusCode, body, headers, errorData)
            if statusCode ~= 200 then
                infoprint("error", "Failed to get presigned URL from Fivemanage for " .. mediaTypeValue)
                print("Status:", statusCode)
                print("Body:", body)
                print("Headers:", json.encode(headers or {}, {indent = true}))
                if errorData then
                    print("Error:", errorData)
                end
                promise:resolve()
                return
            end

            local data = json.decode(body)
            promise:resolve(data and data.data and data.data.presignedUrl)
        end,
        "GET",
        "",
        {Authorization = API_KEYS[mediaType]}
    )

    return Citizen.Await(promise)
end)

-- Voice recording system
RegisterNetEvent("phone:setListeningPeerId", function(peerId)
    if not Config.Voice.RecordNearby then
        return
    end

    local playerId = source
    local playerState = Player(playerId).state
    local currentPeerId = playerState.listeningPeerId

    -- Stop listening to previous peer
    if currentPeerId then
        TriggerClientEvent("phone:stoppedListening", -1, currentPeerId)
    end

    -- Set new peer
    playerState.listeningPeerId = peerId
    debugprint(playerId, "set listeningPeerId to", peerId)

    -- Start listening to new peer
    if peerId then
        TriggerClientEvent("phone:startedListening", -1, playerId, peerId)
    end
end)

-- Handle player disconnect
AddEventHandler("playerDropped", function()
    local playerId = source
    local listeningPeerId = Player(playerId).state.listeningPeerId
    
    if listeningPeerId then
        debugprint(playerId, "dropped, listeningPeerId", listeningPeerId)
        TriggerClientEvent("phone:stoppedListening", -1, listeningPeerId)
    end
end)

-- Register callback for upload API key
RegisterCallback("camera:getUploadApiKey", function(source, mediaType)
    if not mediaType or not API_KEYS[mediaType] then
        return
    end

    -- Prevent abuse for Fivemanage
    if Config.UploadMethod[mediaType] == "Fivemanage" then
        DropPlayer(source, "Tried to abuse the upload system")
        return
    end

    return API_KEYS[mediaType]
end)

-- Notify album members of changes
local function notifyAlbumMembers(albumId, callback, excludeOwner)
    local members = MySQL.query.await(
        "SELECT phone_number FROM phone_photo_album_members WHERE album_id = ?",
        {albumId}
    )
    
    if not members then return end

    -- Include album owner unless excluded
    if not excludeOwner then
        local ownerNumber = MySQL.scalar.await(
            "SELECT phone_number FROM phone_photo_albums WHERE id = ?",
            {albumId}
        )
        table.insert(members, {phone_number = ownerNumber})
    end

    -- Notify each member
    for i = 1, #members do
        local phoneNumber = members[i].phone_number
        local source = GetSourceFromNumber(phoneNumber)
        callback(phoneNumber, source)
    end
end

-- Get album data with counts
local function getAlbumData(albumId)
    local albumData = MySQL.single.await([[
        SELECT
            pa.id,
            pa.title,
            pa.shared,
            (
                SELECT pp_cover.link
                FROM phone_photos pp_cover
                JOIN phone_photo_album_photos ap_cover ON ap_cover.photo_id = pp_cover.id
                WHERE ap_cover.album_id = pa.id
                ORDER BY ap_cover.photo_id DESC
                LIMIT 1
            ) AS cover,
            SUM(CASE WHEN pp.is_video = 1 THEN 1 ELSE 0 END) AS videoCount,
            SUM(CASE WHEN pp.is_video = 0 THEN 1 ELSE 0 END) AS photoCount
        FROM phone_photo_albums pa
        LEFT JOIN phone_photo_album_photos ap ON ap.album_id = pa.id
        LEFT JOIN phone_photos pp ON pp.id = ap.photo_id
        WHERE pa.id = ?
        GROUP BY pa.id, pa.title, pa.shared, pa.phone_number
    ]], {albumId})

    if not albumData then return end

    -- Convert counts to numbers
    albumData.photoCount = tonumber(albumData.photoCount or 0)
    albumData.videoCount = tonumber(albumData.videoCount or 0)
    albumData.count = albumData.photoCount + albumData.videoCount

    return albumData
end

-- Check if phone number has access to album
local function doesPhoneNumberHaveAccessToAlbum(phoneNumber, albumId)
    local album = MySQL.single.await(
        "SELECT phone_number, shared FROM phone_photo_albums WHERE id = ?",
        {albumId}
    )

    if not album then
        debugprint("DoesPhoneNumberHaveAccessToAlbum: Album not found", phoneNumber, albumId)
        return false
    end

    -- Check if owner
    if album.phone_number == phoneNumber then
        return album
    end

    -- Check if private album
    if not album.shared then
        debugprint("DoesPhoneNumberHaveAccessToAlbum: Private album, not the owner", phoneNumber, albumId)
        return false
    end

    -- Check if member of shared album
    local isMember = MySQL.scalar.await(
        "SELECT 1 FROM phone_photo_album_members WHERE album_id = ? AND phone_number = ?",
        {albumId, phoneNumber}
    )

    if not isMember then
        debugprint("DoesPhoneNumberHaveAccessToAlbum: Album is shared, but not a member", phoneNumber, albumId)
        return false
    end

    return album
end

-- Update album for all members
local function updateAlbumForMembers(albumId)
    local albumData = getAlbumData(albumId)
    if not albumData then return end

    notifyAlbumMembers(albumId, function(phoneNumber, source)
        if source then
            TriggerClientEvent("phone:photos:updateAlbum", source, albumData)
        end
    end)
end

-- Valid metadata types
local ValidMetadata = {
    selfie = true,
    import = true,
    screenshot = true
}

-- Save media to gallery
BaseCallback("camera:saveToGallery", function(source, phoneNumber, link, size, isVideo, metadata, shouldLog)
    -- Validate media link
    if not IsMediaLinkAllowed(link) then
        infoprint("error", string.format("%s %s tried to save an image with a link that is not allowed:", source, phoneNumber), link)
        return false
    end

    -- Validate metadata
    if metadata and not ValidMetadata[metadata] then
        debugprint("Invalid metadata", metadata)
        metadata = nil
    end

    -- Insert into database
    local photoId = MySQL.insert.await(
        "INSERT INTO phone_photos (phone_number, link, is_video, size, metadata) VALUES (?, ?, ?, ?, ?)",
        {phoneNumber, link, isVideo == true, size or 0, metadata}
    )

    -- Log if requested
    if shouldLog then
        local mediaTypeStr = isVideo and L("BACKEND.LOGS.VIDEO") or L("BACKEND.LOGS.PHOTO")
        Log("Uploads", source, "info",
            L("BACKEND.LOGS.UPLOADED_MEDIA"),
            L("BACKEND.LOGS.UPLOADED_MEDIA_DESCRIPTION", {
                type = mediaTypeStr,
                id = photoId,
                link = link
            }),
            link
        )
        TrackSimpleEvent(isVideo and "take_video" or "take_photo")
    end

    return photoId
end)

-- Delete from gallery
BaseCallback("camera:deleteFromGallery", function(source, phoneNumber, photoIds)
    MySQL.update.await(
        "DELETE FROM phone_photos WHERE phone_number = ? AND id IN (?)",
        {phoneNumber, photoIds}
    )
    return true
end)

-- Toggle favourites
BaseCallback("camera:toggleFavourites", function(source, phoneNumber, isFavourite, photoIds)
    MySQL.update.await(
        "UPDATE phone_photos SET is_favourite = ? WHERE phone_number = ? AND id IN (?)",
        {isFavourite == true, phoneNumber, photoIds}
    )
    return true
end)

-- Get images with filters
BaseCallback("camera:getImages", function(source, phoneNumber, filters, page)
    -- Check if any media type is enabled
    if not filters.showVideos and not filters.showPhotos then
        return {}
    end

    local params = {phoneNumber}
    local conditions = {"phone_number = ?"}
    local query = "SELECT id, link, is_video, size, metadata, is_favourite, `timestamp` FROM phone_photos {WHERE}"

    -- Filter by media type
    if filters.showPhotos ~= filters.showVideos then
        table.insert(conditions, "(is_video = ? OR is_video != ?)")
        table.insert(params, filters.showVideos == true)
        table.insert(params, filters.showPhotos == true)
    end

    -- Filter favourites
    if filters.favourites == true then
        table.insert(conditions, "is_favourite = 1")
    end

    -- Filter by metadata type
    if filters.type then
        table.insert(conditions, "metadata = ?")
        table.insert(params, filters.type)
    end

    -- Filter by album
    if filters.album then
        if not doesPhoneNumberHaveAccessToAlbum(phoneNumber, filters.album) then
            debugprint("getImages: No access to album", phoneNumber, filters.album)
            return {}
        end

        -- Remove phone_number condition for album query
        table.remove(conditions, 1)
        table.remove(params, 1)
        
        table.insert(conditions, "id IN (SELECT ap.photo_id FROM phone_photo_album_photos ap WHERE ap.album_id = ?)")
        table.insert(params, filters.album)
    end

    -- Filter duplicates
    if filters.duplicates then
        table.insert(conditions, [[
            link IN (
                SELECT link
                FROM phone_photos
                WHERE phone_number = ?
                GROUP BY link
                HAVING COUNT(1) > 1
            )
        ]])
        table.insert(params, phoneNumber)
    end

    -- Pagination
    local perPage = math.clamp(filters.perPage or 32, 1, 32)
    query = query .. " ORDER BY `timestamp` DESC LIMIT ?, ?"
    
    -- Build final query
    local whereClause = #conditions > 0 and ("WHERE " .. table.concat(conditions, " AND ")) or ""
    query = query:gsub("{WHERE}", whereClause)
    
    -- Add pagination params
    table.insert(params, (page or 0) * perPage)
    table.insert(params, perPage)

    return MySQL.query.await(query, params)
end)

-- Get last image
BaseCallback("camera:getLastImage", function(source, phoneNumber)
    return MySQL.scalar.await(
        "SELECT link FROM phone_photos WHERE phone_number = ? ORDER BY id DESC LIMIT 1",
        {phoneNumber}
    )
end)

-- Create album
BaseCallback("camera:createAlbum", function(source, phoneNumber, title)
    return MySQL.insert.await(
        "INSERT INTO phone_photo_albums (phone_number, title) VALUES (?, ?)",
        {phoneNumber, title}
    )
end)

-- Rename album
BaseCallback("camera:renameAlbum", function(source, phoneNumber, albumId, newTitle)
    local updated = MySQL.update.await(
        "UPDATE phone_photo_albums SET title = ? WHERE phone_number = ? AND id = ?",
        {newTitle, phoneNumber, albumId}
    ) > 0

    if updated then
        -- Check if shared album
        local isShared = MySQL.scalar.await(
            "SELECT shared FROM phone_photo_albums WHERE id = ?",
            {albumId}
        )
        
        if isShared then
            notifyAlbumMembers(albumId, function(phoneNumber, source)
                if source then
                    TriggerClientEvent("phone:photos:renameAlbum", source, albumId, newTitle)
                end
            end, true)
        end
    end

    return updated
end)

-- Add photos to album
BaseCallback("camera:addToAlbum", function(source, phoneNumber, albumId, photoIds)
    if not doesPhoneNumberHaveAccessToAlbum(phoneNumber, albumId) then
        debugprint("No access to album", phoneNumber, albumId)
        return false
    end

    MySQL.update.await(
        "INSERT IGNORE INTO phone_photo_album_photos (album_id, photo_id) SELECT ?, id FROM phone_photos WHERE phone_number = ? AND id IN (?)",
        {albumId, phoneNumber, photoIds}
    )

    debugprint("Added photos to album", phoneNumber, albumId, photoIds)

    -- Update album if shared
    local album = doesPhoneNumberHaveAccessToAlbum(phoneNumber, albumId)
    if album.shared then
        updateAlbumForMembers(albumId)
    end

    return true
end)

-- Remove photos from album
BaseCallback("camera:removeFromAlbum", function(source, phoneNumber, albumId, photoIds)
    if not doesPhoneNumberHaveAccessToAlbum(phoneNumber, albumId) then
        debugprint("No access to album", phoneNumber, albumId)
        return false
    end

    MySQL.update.await(
        "DELETE FROM phone_photo_album_photos WHERE album_id = ? AND photo_id IN (?)",
        {albumId, photoIds}
    )

    updateAlbumForMembers(albumId)
    return true
end)

-- Delete album
BaseCallback("camera:deleteAlbum", function(source, phoneNumber, albumId)
    local album = MySQL.single.await(
        "SELECT shared FROM phone_photo_albums WHERE phone_number = ? AND id = ?",
        {phoneNumber, albumId}
    )

    if not album then
        debugprint("deleteAlbum: Album not found", phoneNumber, albumId)
        return false
    end

    -- Notify members if shared
    if album.shared then
        notifyAlbumMembers(albumId, function(memberNumber, memberSource)
            if memberSource then
                TriggerClientEvent("phone:photos:removeMemberFromAlbum", memberSource, albumId, memberNumber)
            end
        end, true)
    end

    MySQL.update("DELETE FROM phone_photo_albums WHERE phone_number = ? AND id = ?", {phoneNumber, albumId})
    return true
end)

-- Media type counts list
local mediaTypeCounts = {
    "videos", "photos", "favouritesVideos", "favouritesPhotos",
    "selfiesVideos", "selfiesPhotos", "screenshotsVideos", "screenshotsPhotos",
    "importsVideos", "importsPhotos", "duplicatesPhotos", "duplicatesVideos"
}

-- Get home page data
BaseCallback("camera:getHomePageData", function(source, phoneNumber)
    -- Get media counts
    local counts = MySQL.single.await([[
        SELECT
            SUM(is_video = 1) AS videos,
            SUM(is_video = 0) AS photos,
            SUM(is_video = 1 AND is_favourite = 1) AS favouritesVideos,
            SUM(is_video = 0 AND is_favourite = 1) AS favouritesPhotos,
            SUM(metadata = 'selfie' AND is_video = 1) AS selfiesVideos,
            SUM(metadata = 'selfie' AND is_video = 0) AS selfiesPhotos,
            SUM(metadata = 'screenshot' AND is_video = 1) AS screenshotsVideos,
            SUM(metadata = 'screenshot' AND is_video = 0) AS screenshotsPhotos,
            SUM(metadata = 'import' AND is_video = 1) AS importsVideos,
            SUM(metadata = 'import' AND is_video = 0) AS importsPhotos,
            SUM(CASE WHEN is_video = 0 THEN 1 ELSE 0 END) - COUNT(DISTINCT CASE WHEN is_video = 0 THEN link END) AS duplicatesPhotos,
            SUM(CASE WHEN is_video = 1 THEN 1 ELSE 0 END) - COUNT(DISTINCT CASE WHEN is_video = 1 THEN link END) AS duplicatesVideos
        FROM phone_photos
        WHERE phone_number = ?
    ]], {phoneNumber})

    -- Convert counts to numbers
    for i = 1, #mediaTypeCounts do
        local key = mediaTypeCounts[i]
        counts[key] = tonumber(counts[key] or 0)
    end

    -- Adjust duplicate counts
    if counts.duplicatesPhotos > 0 then
        counts.duplicatesPhotos = counts.duplicatesPhotos + 1
    end
    if counts.duplicatesVideos > 0 then
        counts.duplicatesVideos = counts.duplicatesVideos + 1
    end

    -- Build albums list
    local albums = {
        {
            id = "recents",
            title = L("APPS.PHOTOS.RECENTS"),
            videoCount = counts.videos,
            photoCount = counts.photos,
            cover = MySQL.scalar.await(
                "SELECT link FROM phone_photos WHERE phone_number = ? ORDER BY id DESC LIMIT 1",
                {phoneNumber}
            ),
            removable = false
        },
        {
            id = "favourites",
            title = L("APPS.PHOTOS.FAVOURITES"),
            videoCount = counts.favouritesVideos,
            photoCount = counts.favouritesPhotos,
            cover = MySQL.scalar.await(
                "SELECT link FROM phone_photos WHERE phone_number = ? AND is_favourite = 1 ORDER BY id DESC LIMIT 1",
                {phoneNumber}
            ),
            removable = false
        }
    }

    -- Get user albums
    local userAlbums = MySQL.query.await([[
        SELECT
            pa.id,
            pa.title,
            pa.shared,
            pa.phone_number,
            (
                SELECT pp_cover.link
                FROM phone_photos pp_cover
                JOIN phone_photo_album_photos ap_cover ON ap_cover.photo_id = pp_cover.id
                WHERE ap_cover.album_id = pa.id
                ORDER BY ap_cover.photo_id DESC
                LIMIT 1
            ) AS cover,
            SUM(CASE WHEN pp.is_video = 1 THEN 1 ELSE 0 END) AS videoCount,
            SUM(CASE WHEN pp.is_video = 0 THEN 1 ELSE 0 END) AS photoCount
        FROM phone_photo_albums pa
        LEFT JOIN phone_photo_album_photos ap ON ap.album_id = pa.id
        LEFT JOIN phone_photos pp ON pp.id = ap.photo_id
        WHERE pa.phone_number = ?
            OR EXISTS (
                SELECT 1
                FROM phone_photo_album_members member
                WHERE member.album_id = pa.id AND member.phone_number = ?
            )
        GROUP BY pa.id, pa.title, pa.shared, pa.phone_number
        ORDER BY pa.id ASC
    ]], {phoneNumber, phoneNumber})

    -- Process user albums
    for i = 1, #userAlbums do
        local album = userAlbums[i]
        album.removable = true
        album.isOwner = album.phone_number == phoneNumber
        album.phone_number = nil
        table.insert(albums, album)
    end

    -- Convert counts for all albums
    for i = 1, #albums do
        local album = albums[i]
        album.photoCount = tonumber(album.photoCount or 0)
        album.videoCount = tonumber(album.videoCount or 0)
        album.count = album.photoCount + album.videoCount
    end

    return {
        albums = albums,
        mediaTypes = counts
    }
end, {albums = {}, mediaTypes = {}})

-- Get album members
BaseCallback("camera:getAlbumMembers", function(source, phoneNumber, albumId)
    if not doesPhoneNumberHaveAccessToAlbum(phoneNumber, albumId) then
        debugprint("getAlbumMembers: No access to album", phoneNumber, albumId)
        return false
    end

    local members = {}
    
    -- Get owner
    local owner = MySQL.scalar.await(
        "SELECT phone_number FROM phone_photo_albums WHERE id = ?",
        {albumId}
    )
    
    -- Get members
    local memberRows = MySQL.query.await(
        "SELECT phone_number FROM phone_photo_album_members WHERE album_id = ?",
        {albumId}
    )
    
    -- Build members list
    for i = 1, #memberRows do
        members[i] = memberRows[i].phone_number
    end
    
    -- Add owner to list
    table.insert(members, owner)
    
    return members
end)

-- Remove member from album
local function removeMemberFromAlbum(phoneNumber, albumId)
    local removed = MySQL.update.await(
        "DELETE FROM phone_photo_album_members WHERE album_id = ? AND phone_number = ?",
        {albumId, phoneNumber}
    ) > 0

    if not removed then
        debugprint("removeMemberFromAlbum: failed to remove member from album", phoneNumber, albumId)
        return false
    end

    -- Check remaining members
    local memberCount = MySQL.scalar.await(
        "SELECT COUNT(1) FROM phone_photo_album_members WHERE album_id = ?",
        {albumId}
    )

    -- Notify all members
    notifyAlbumMembers(albumId, function(memberNumber, memberSource)
        if memberSource then
            TriggerClientEvent("phone:photos:removeMemberFromAlbum", memberSource, albumId, phoneNumber)
        end
    end)

    -- Make album private if no members left
    if memberCount == 0 then
        MySQL.update.await(
            "UPDATE phone_photo_albums SET shared = 0 WHERE id = ?",
            {albumId}
        )
    end

    -- Notify the removed member
    local removedSource = GetSourceFromNumber(phoneNumber)
    if removedSource then
        TriggerClientEvent("phone:photos:removeMemberFromAlbum", removedSource, albumId, phoneNumber)
    end

    return true
end

-- Remove member from album (owner action)
BaseCallback("camera:removeMemberFromAlbum", function(source, phoneNumber, memberNumber, albumId)
    -- Verify ownership
    local isOwner = MySQL.scalar.await(
        "SELECT 1 FROM phone_photo_albums WHERE id = ? AND phone_number = ?",
        {albumId, phoneNumber}
    )

    if not isOwner then
        debugprint("removeMemberFromAlbum: not the owner of the album", phoneNumber, albumId)
        return
    end

    return removeMemberFromAlbum(memberNumber, albumId)
end)

-- Leave shared album
BaseCallback("camera:leaveSharedAlbum", function(source, phoneNumber, albumId)
    removeMemberFromAlbum(phoneNumber, albumId)
    return true
end)

-- Handle accepting shared album via AirShare
function HandleAcceptAirShareAlbum(recipientSource, senderSource, albumId)
    local senderNumber = GetEquippedPhoneNumber(senderSource)
    local recipientNumber = GetEquippedPhoneNumber(recipientSource)

    if not senderNumber or not recipientNumber then
        debugprint("HandleAcceptAirShareAlbum: senderPhoneNumber/recipientPhoneNumber not found", senderNumber, recipientNumber)
        return
    end

    -- Check if already a member
    local isAlreadyMember = MySQL.scalar.await(
        "SELECT 1 FROM phone_photo_album_members WHERE album_id = ? AND phone_number = ?",
        {albumId, recipientNumber}
    )

    if isAlreadyMember then
        debugprint("HandleAcceptAirShareAlbum: recipient is already a member of the album", senderNumber, recipientNumber, albumId)
        return
    end

    -- Verify sender owns the album
    local senderOwnsAlbum = MySQL.scalar.await(
        "SELECT 1 FROM phone_photo_albums WHERE id = ? AND phone_number = ?",
        {albumId, senderNumber}
    )

    if not senderOwnsAlbum then
        debugprint("HandleAcceptAirShareAlbum: sender is not the owner of the album", senderNumber, recipientNumber, albumId)
        return
    end

    -- Make album shared
    MySQL.update.await(
        "UPDATE phone_photo_albums SET shared = 1 WHERE id = ?",
        {albumId}
    )

    -- Get album data
    local albumData = getAlbumData(albumId)
    if not albumData then
        debugprint("HandleAcceptAirShareAlbum: albumData not found", senderNumber, recipientNumber, albumId)
        return
    end

    -- Notify existing members about new member
    notifyAlbumMembers(albumId, function(memberNumber, memberSource)
        if memberSource and memberSource ~= recipientSource then
            TriggerClientEvent("phone:photos:addMemberToAlbum", memberSource, albumId, recipientNumber)
        end
    end)

    -- Add recipient as member
    MySQL.insert(
        "INSERT INTO phone_photo_album_members (album_id, phone_number) VALUES (?, ?) ON DUPLICATE KEY UPDATE phone_number = ?",
        {albumId, recipientNumber, recipientNumber}
    )

    -- Send album to recipient
    TriggerClientEvent("phone:photos:addSharedAlbum", recipientSource, albumData)
end