-- Export function to get email address for a source
exports("GetEmailAddress", function(source)
    return GetLoggedInAccount(source, "Mail")
end)

-- Helper function to create mail callbacks that require login
local function createMailCallback(name, handler, defaultReturn)
    BaseCallback("mail:" .. name, function(source, phoneNumber, ...)
        local emailAddress = GetLoggedInAccount(phoneNumber, "Mail")
        if not emailAddress then
            return defaultReturn
        end
        return handler(source, phoneNumber, emailAddress, ...)
    end, defaultReturn)
end

-- Notify all logged-in users of a specific email address
local function notifyMailUsers(emailAddress, notification, excludePhoneNumber)
    local loggedInUsers = MySQL.query.await(
        "SELECT phone_number FROM phone_logged_in_accounts WHERE username = ? AND app = 'Mail' AND `active` = 1",
        {emailAddress}
    )
    
    notification.app = "Mail"
    
    for i = 1, #loggedInUsers do
        local phoneNumber = loggedInUsers[i].phone_number
        if phoneNumber ~= excludePhoneNumber then
            SendNotification(phoneNumber, notification)
        end
    end
end

-- Check if user is logged in
createMailCallback("isLoggedIn", function(source, phoneNumber, emailAddress)
    return emailAddress
end, false)

-- Create a new mail account
local function createMailAccount(email, password, callback)
    -- Validate input
    if not email or not password or #email < 3 or #password < 3 then
        if callback then
            callback({success = false, reason = "Invalid email / password"})
        end
        return false, "Invalid email / password"
    end

    -- Hash the password
    password = GetPasswordHash(password)

    -- Check if email already exists
    local exists = MySQL.scalar.await(
        "SELECT 1 FROM phone_mail_accounts WHERE address=?",
        {email}
    )

    if exists then
        if callback then
            callback({success = false, error = "Address already exists"})
        end
        return false, "Address already exists"
    end

    -- Create the account
    local inserted = MySQL.update.await(
        "INSERT INTO phone_mail_accounts (address, `password`) VALUES (?, ?)",
        {email, password}
    ) == 1

    if not inserted then
        if callback then
            callback({success = false, error = "Server error"})
        end
        return false, "Server error"
    end

    if callback then
        callback({success = true})
    end
    return true
end

exports("CreateMailAccount", createMailAccount)

-- Create account endpoint
BaseCallback("mail:createAccount", function(source, phoneNumber, username, password)
    -- Validate input
    if #username < 3 or #password < 3 then
        return {success = false, error = "Invalid email / password"}
    end

    -- Add domain to username
    local email = username .. "@" .. Config.EmailDomain

    -- Create the account
    local success, error = createMailAccount(email, password)
    
    if success then
        AddLoggedInAccount(phoneNumber, "Mail", email)
    end

    return {success = success, error = error}
end)

-- Change password
createMailCallback("changePassword", function(source, phoneNumber, emailAddress, oldPassword, newPassword)
    -- Check if password changes are enabled
    if not Config.ChangePassword.Mail then
        infoprint("warning", string.format("%s tried to change password on Mail, but it's not enabled in the config.", source))
        return false
    end

    -- Validate new password
    if oldPassword == newPassword or #newPassword < 3 then
        debugprint("same password / too short")
        return false
    end

    -- Verify old password
    local currentPasswordHash = MySQL.scalar.await(
        "SELECT password FROM phone_mail_accounts WHERE address = ?",
        {emailAddress}
    )

    if not currentPasswordHash or not VerifyPasswordHash(oldPassword, currentPasswordHash) then
        return false
    end

    -- Update password
    local updated = MySQL.update.await(
        "UPDATE phone_mail_accounts SET password = ? WHERE address = ?",
        {GetPasswordHash(newPassword), emailAddress}
    ) > 0

    if not updated then
        return false
    end

    -- Notify user and log out other devices
    notifyMailUsers(emailAddress, {
        title = L("BACKEND.MISC.LOGGED_OUT_PASSWORD.TITLE"),
        content = L("BACKEND.MISC.LOGGED_OUT_PASSWORD.DESCRIPTION")
    }, phoneNumber)

    -- Remove other logged in sessions
    MySQL.update.await(
        "DELETE FROM phone_logged_in_accounts WHERE username = ? AND app = 'Mail' AND phone_number != ?",
        {emailAddress, phoneNumber}
    )

    ClearActiveAccountsCache("Mail", emailAddress, phoneNumber)

    -- Log the action
    Log("Mail", source, "info",
        L("BACKEND.LOGS.CHANGED_PASSWORD.TITLE"),
        L("BACKEND.LOGS.CHANGED_PASSWORD.DESCRIPTION", {
            number = phoneNumber,
            username = emailAddress,
            app = "Mail"
        })
    )

    -- Trigger logout event
    TriggerClientEvent("phone:logoutFromApp", -1, {
        username = emailAddress,
        app = "mail",
        reason = "password",
        number = phoneNumber
    })

    return true
end, false)

-- Delete account
createMailCallback("deleteAccount", function(source, phoneNumber, emailAddress, password)
    -- Check if account deletion is enabled
    if not Config.DeleteAccount.Mail then
        infoprint("warning", string.format("%s tried to delete their account on Mail, but it's not enabled in the config.", source))
        return false
    end

    -- Verify password
    local passwordHash = MySQL.scalar.await(
        "SELECT password FROM phone_mail_accounts WHERE address = ?",
        {emailAddress}
    )

    if not passwordHash or not VerifyPasswordHash(password, passwordHash) then
        return false
    end

    -- Delete account
    local deleted = MySQL.update.await(
        "DELETE FROM phone_mail_accounts WHERE address = ?",
        {emailAddress}
    ) > 0

    if not deleted then
        return false
    end

    -- Notify user
    notifyMailUsers(emailAddress, {
        title = L("BACKEND.MISC.DELETED_NOTIFICATION.TITLE"),
        content = L("BACKEND.MISC.DELETED_NOTIFICATION.DESCRIPTION")
    })

    -- Remove all logged in sessions
    MySQL.update.await(
        "DELETE FROM phone_logged_in_accounts WHERE username = ? AND app = 'Mail'",
        {emailAddress}
    )

    ClearActiveAccountsCache("Mail", emailAddress)

    -- Log the action
    Log("Mail", source, "info",
        L("BACKEND.LOGS.DELETED_ACCOUNT.TITLE"),
        L("BACKEND.LOGS.DELETED_ACCOUNT.DESCRIPTION", {
            number = phoneNumber,
            username = emailAddress,
            app = "Mail"
        })
    )

    -- Trigger logout event
    TriggerClientEvent("phone:logoutFromApp", -1, {
        username = emailAddress,
        app = "mail",
        reason = "deleted"
    })

    return true
end, false)

-- Login to mail account
BaseCallback("mail:login", function(source, phoneNumber, email, password)
    -- Get account password
    local passwordHash = MySQL.scalar.await(
        "SELECT `password` FROM phone_mail_accounts WHERE address=?",
        {email}
    )

    if not passwordHash then
        return {success = false, error = "Invalid address"}
    end

    -- Verify password
    if not VerifyPasswordHash(password, passwordHash) then
        return {success = false, error = "Invalid password"}
    end

    -- Log in
    AddLoggedInAccount(phoneNumber, "Mail", email)
    return {success = true}
end, {success = false, error = "No phone equipped"})

-- Logout from mail account
createMailCallback("logout", function(source, phoneNumber, emailAddress)
    RemoveLoggedInAccount(phoneNumber, "Mail", emailAddress)
    return {success = true}
end, {success = false, error = "Not logged in"})

-- Send mail notification to recipients
local function sendMailNotification(mail)
    -- Send to all users
    if mail.to == "all" then
        TriggerClientEvent("phone:mail:newMail", -1, mail)
        return
    end

    -- Get recipients
    local recipients = MySQL.query.await(
        "SELECT phone_number FROM phone_logged_in_accounts WHERE app = 'Mail' AND username = ? AND active = 1",
        {mail.to}
    )

    -- Send to each recipient
    for _, recipient in pairs(recipients) do
        local recipientSource = GetSourceFromNumber(recipient.phone_number)
        if recipientSource then
            TriggerClientEvent("phone:mail:newMail", recipientSource, mail)
        end

        -- Send notification
        SendNotification(recipient.phone_number, {
            app = "Mail",
            title = mail.sender,
            content = mail.subject,
            thumbnail = mail.attachments[1]
        })
    end
end

-- Send mail function
local function sendMail(mailData)
    -- Validate recipient
    if mailData.to and mailData.to ~= "all" then
        local recipientExists = MySQL.scalar.await(
            "SELECT 1 FROM phone_mail_accounts WHERE address = ?",
            {mailData.to}
        )
        if not recipientExists then
            return false, "Invalid address"
        end
    end

    -- Convert HTML to Markdown if configured
    if Config.ConvertMailToMarkdown and ConvertHTMLToMarkdown then
        mailData.message = ConvertHTMLToMarkdown(mailData.message)
    end

    -- Ensure attachments and actions are tables
    mailData.attachments = mailData.attachments or {}
    mailData.actions = mailData.actions or {}

    -- Insert mail into database
    local mailId = MySQL.insert.await(
        "INSERT INTO phone_mail_messages (recipient, sender, subject, content, attachments, actions) VALUES (@recipient, @sender, @subject, @content, @attachments, @actions)",
        {
            ["@recipient"] = mailData.to,
            ["@sender"] = mailData.sender or "system",
            ["@subject"] = mailData.subject or "System mail",
            ["@content"] = mailData.message or "",
            ["@attachments"] = #mailData.attachments > 0 and json.encode(mailData.attachments) or nil,
            ["@actions"] = #mailData.actions > 0 and json.encode(mailData.actions) or nil
        }
    )

    -- Create mail object
    local mail = {
        id = mailId,
        to = mailData.to,
        sender = mailData.sender or "System",
        subject = mailData.subject or "System mail",
        message = mailData.message or "",
        attachments = mailData.attachments,
        actions = mailData.actions,
        read = false,
        timestamp = os.time() * 1000
    }

    -- Trigger event
    TriggerEvent("Danger_Phone:mail:mailSent", mail)

    -- Send notifications
    sendMailNotification(mail)

    return true, mailId
end

exports("SendMail", sendMail)

-- Auto-create email account for new players
function GenerateEmailAccount(source, phoneNumber)
    if not Config.AutoCreateEmail or not phoneNumber then
        return
    end

    -- Get character name
    local firstName, lastName = GetCharacterName(source)
    
    -- Clean names (remove non-alphanumeric characters)
    firstName = firstName:gsub("[^%w]", "")
    lastName = lastName:gsub("[^%w]", "")

    -- Generate random strings if names are empty
    if #firstName == 0 then
        firstName = GenerateString(5)
    end
    if #lastName == 0 then
        lastName = GenerateString(5)
    end

    -- Create base username
    local baseUsername = firstName .. "." .. lastName
    
    -- Check for existing similar usernames
    local similarCount = MySQL.scalar.await(
        "SELECT COUNT(1) FROM phone_mail_accounts WHERE address LIKE ?",
        {baseUsername .. "%"}
    ) or 0

    -- Add number if similar exists
    if similarCount > 0 then
        baseUsername = baseUsername .. (similarCount + 1)
    end

    -- Create full email address
    local email = baseUsername .. "@" .. Config.EmailDomain

    -- Check if email exists
    local exists = MySQL.scalar.await(
        "SELECT 1 FROM phone_mail_accounts WHERE address=?",
        {email}
    )

    -- Try to generate unique email
    local attempts = 0
    while exists and attempts < 50 do
        email = firstName .. "." .. lastName .. math.random(1000, 9999) .. "@" .. Config.EmailDomain
        exists = MySQL.scalar.await(
            "SELECT 1 FROM phone_mail_accounts WHERE address=?",
            {email}
        )
        attempts = attempts + 1
        Wait(0)
    end

    if exists then
        debugprint("Failed to generate address for", source)
        return
    end

    -- Make email lowercase
    email = email:lower()

    -- Generate password
    local password = GenerateString(5)

    -- Create account
    if not createMailAccount(email, password) then
        return
    end

    -- Log in automatically
    AddLoggedInAccount(phoneNumber, "Mail", email)

    -- Send welcome email with credentials
    sendMail({
        to = email,
        sender = L("BACKEND.MAIL.AUTOMATIC_PASSWORD.SENDER"),
        subject = L("BACKEND.MAIL.AUTOMATIC_PASSWORD.SUBJECT"),
        message = L("BACKEND.MAIL.AUTOMATIC_PASSWORD.MESSAGE", {
            address = email,
            password = password
        })
    })
end

-- Delete mail (global)
exports("DeleteMail", function(mailId)
    local deleted = MySQL.Sync.execute(
        "DELETE FROM phone_mail_messages WHERE id=@id",
        {["@id"] = mailId}
    ) > 0

    if deleted then
        TriggerClientEvent("phone:mail:mailDeleted", -1, mailId)
    end

    return deleted
end)

-- Send mail (user action)
createMailCallback("sendMail", function(source, phoneNumber, emailAddress, mailData)
    -- Prevent sending to "all"
    if mailData.to == "all" then
        return false
    end

    -- Validate required fields
    local to = mailData.to
    local subject = mailData.subject
    local message = mailData.message
    local attachments = mailData.attachments

    if not to or not subject or not message or type(attachments) ~= "table" then
        return false
    end

    -- Check for blacklisted words
    if ContainsBlacklistedWord(source, "Mail", subject) or ContainsBlacklistedWord(source, "Mail", message) then
        return false
    end

    -- Send the mail
    local success, mailId = sendMail({
        to = to,
        sender = emailAddress,
        subject = subject,
        message = message,
        attachments = attachments
    })

    if not success then
        return false
    end

    -- Log the action
    Log("Mail", source, "info",
        L("BACKEND.LOGS.MAIL_TITLE"),
        L("BACKEND.LOGS.NEW_MAIL", {
            sender = emailAddress,
            recipient = to
        })
    )

    return mailId
end)

-- Get mails for user
createMailCallback("getMails", function(source, phoneNumber, emailAddress, page)
    local deleteCondition = Config.DeleteMail and 
        "AND IF((SELECT 1 FROM phone_mail_deleted d WHERE d.message_id=m.id AND d.address=@address), FALSE, TRUE)" or 
        ""

    return MySQL.query.await(string.format([[
        SELECT id, recipient AS `to`, sender, subject, LEFT(content, 70) AS message, `read`, `timestamp`
        FROM phone_mail_messages m
        WHERE (
            recipient=@address
            OR recipient="all"
            OR sender=@address
        ) %s
        ORDER BY `timestamp` DESC
        LIMIT @page, @perPage
    ]], deleteCondition), {
        ["@address"] = emailAddress,
        ["@page"] = (page or 0) * 10,
        ["@perPage"] = 10
    })
end, {})

-- Get single mail
createMailCallback("getMail", function(source, phoneNumber, emailAddress, mailId)
    local mail = MySQL.single.await([[
        SELECT
            id, recipient AS `to`, sender, subject, content as message, attachments, `read`, `timestamp`, actions
        FROM phone_mail_messages
        WHERE (
            recipient=@address
            OR recipient="all"
            OR sender=@address
        ) AND id=@id
    ]], {
        ["@address"] = emailAddress,
        ["@id"] = mailId
    })

    if not mail then
        return false
    end

    -- Mark as read if not sender
    if not mail.read then
        MySQL.update(
            "UPDATE phone_mail_messages SET `read`=1 WHERE id=? AND sender != ?",
            {mailId, emailAddress}
        )
    end

    return mail
end)

-- Delete mail (user action)
createMailCallback("deleteMail", function(source, phoneNumber, emailAddress, mailId)
    if not Config.DeleteMail then
        return
    end

    MySQL.update.await(
        "INSERT IGNORE INTO phone_mail_deleted (message_id, address) VALUES (?, ?)",
        {mailId, emailAddress}
    )

    return true
end)

-- Search mails
createMailCallback("search", function(source, phoneNumber, emailAddress, query, page)
    local deleteCondition = Config.DeleteMail and 
        "AND IF((SELECT 1 FROM phone_mail_deleted d WHERE d.message_id=m.id AND d.address=@address), FALSE, TRUE)" or 
        ""

    return MySQL.query.await(string.format([[
        SELECT id, recipient AS `to`, sender, subject, LEFT(content, 70) AS message, `read`, `timestamp`
        FROM phone_mail_messages m
        WHERE (
            recipient=@address
            OR recipient="all"
            OR sender=@address
        ) AND (
            recipient LIKE @query
            OR recipient="all"
            OR sender LIKE @query
            OR subject LIKE @query
            OR content LIKE @query
        ) %s
        ORDER BY `timestamp` DESC
        LIMIT @page, @perPage
    ]], deleteCondition), {
        ["@address"] = emailAddress,
        ["@query"] = "%" .. query .. "%",
        ["@page"] = (page or 0) * 10,
        ["@perPage"] = 10
    })
end, {})