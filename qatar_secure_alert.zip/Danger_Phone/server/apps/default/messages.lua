-- Helper function to find existing direct message channel between two phone numbers
local function findDirectMessageChannel(phoneNumber1, phoneNumber2)
    return MySQL.scalar.await([[
        SELECT c.id FROM phone_message_channels c
        WHERE c.is_group = 0
            AND EXISTS (SELECT TRUE FROM phone_message_members m WHERE m.channel_id = c.id AND m.phone_number = ?)
            AND EXISTS (SELECT TRUE FROM phone_message_members m WHERE m.channel_id = c.id AND m.phone_number = ?)
    ]], {phoneNumber1, phoneNumber2})
end

-- Core function to send a message
function SendMessage(senderNumber, recipientNumber, message, attachments, callback, channelId)
    -- Validate inputs
    if not (channelId or recipientNumber) or not senderNumber then
        return
    end

    -- Check if message or attachments exist
    if not message and (not attachments or #attachments == 0) then
        debugprint("No message or attachments provided")
        return
    end

    -- Clean up empty message/attachments
    if message and #message == 0 then
        message = nil
    end
    
    if attachments and #attachments == 0 then
        debugprint("No attachments provided")
        return
    end

    -- Find or create channel if not provided
    if not channelId then
        channelId = findDirectMessageChannel(senderNumber, recipientNumber)
    end

    local senderSource = GetSourceFromNumber(senderNumber)

    -- Create new direct message channel if needed
    if not channelId then
        channelId = MySQL.insert.await("INSERT INTO phone_message_channels (is_group) VALUES (0)")
        
        -- Add both members to the channel
        MySQL.update.await(
            "INSERT INTO phone_message_members (channel_id, phone_number) VALUES (?, ?), (?, ?)",
            {channelId, senderNumber, channelId, recipientNumber}
        )

        local recipientSource = GetSourceFromNumber(recipientNumber)
        
        -- Notify sender of new channel
        if senderSource then
            TriggerClientEvent("phone:messages:newChannel", senderSource, {
                id = channelId,
                lastMessage = message,
                timestamp = os.time() * 1000,
                number = recipientNumber,
                isGroup = false,
                unread = false
            })
        end

        -- Notify recipient of new channel
        if recipientSource then
            TriggerClientEvent("phone:messages:newChannel", recipientSource, {
                id = channelId,
                lastMessage = message,
                timestamp = os.time() * 1000,
                number = senderNumber,
                isGroup = false,
                unread = true
            })
        end
    end

    -- Log the message
    if senderSource then
        Log("Messages", senderSource, "info",
            L("BACKEND.LOGS.MESSAGE_TITLE"),
            L("BACKEND.LOGS.NEW_MESSAGE", {
                sender = FormatNumber(senderNumber),
                recipient = FormatNumber(recipientNumber),
                message = message or "Attachment"
            })
        )
    end

    -- Encode attachments if needed
    if type(attachments) == "table" then
        attachments = json.encode(attachments)
    end

    -- Insert the message
    local messageId = MySQL.insert.await(
        "INSERT INTO phone_message_messages (channel_id, sender, content, attachments) VALUES (@channelId, @sender, @content, @attachments)",
        {
            ["@channelId"] = channelId,
            ["@sender"] = senderNumber,
            ["@content"] = message,
            ["@attachments"] = attachments
        }
    )

    if not messageId then
        if callback then
            callback(false)
        end
        return
    end

    -- Update channel's last message
    MySQL.update(
        "UPDATE phone_message_channels SET last_message = ? WHERE id = ?",
        {string.sub(message or "Attachment", 1, 50), channelId}
    )

    -- Update unread count for recipients
    MySQL.update(
        "UPDATE phone_message_members SET unread = unread + 1 WHERE channel_id = ? AND phone_number != ?",
        {channelId, senderNumber}
    )

    -- Undelete channel for all members
    MySQL.update(
        "UPDATE phone_message_members SET deleted = 0 WHERE channel_id = ?",
        {channelId}
    )

    -- Get all channel members
    local members = MySQL.query.await(
        "SELECT phone_number FROM phone_message_members WHERE channel_id = ? AND phone_number != ?",
        {channelId, senderNumber}
    )

    -- Notify all members except sender
    for i = 1, #members do
        local memberNumber = members[i].phone_number
        
        if memberNumber ~= senderNumber then
            local memberSource = GetSourceFromNumber(memberNumber)
            
            if memberSource then
                TriggerClientEvent("phone:messages:newMessage", memberSource, channelId, messageId, senderNumber, message, attachments)
            end

            -- Send notification (skip for call no-answer messages)
            if message ~= "<!CALL-NO-ANSWER!>" then
                local contact = GetContact(senderNumber, memberNumber)
                
                SendNotification(memberNumber, {
                    app = "Messages",
                    title = contact and contact.name or senderNumber,
                    content = message,
                    thumbnail = attachments and json.decode(attachments)[1],
                    avatar = contact and contact.avatar,
                    showAvatar = true
                })
            end
        end
    end

    -- Execute callback if provided
    if callback then
        callback(channelId)
    end

    -- Trigger event for other resources
    TriggerEvent("Danger_Phone:messages:messageSent", {
        channelId = channelId,
        messageId = messageId,
        sender = senderNumber,
        recipient = recipientNumber,
        message = message,
        attachments = attachments
    })

    return {
        channelId = channelId,
        messageId = messageId
    }
end

-- Export for sending money messages
exports("SentMoney", function(senderNumber, recipientNumber, amount)
    assert(type(senderNumber) == "string", "Expected string for argument 1, got " .. type(senderNumber))
    assert(type(recipientNumber) == "string", "Expected string for argument 2, got " .. type(recipientNumber))
    assert(type(amount) == "number", "Expected number for argument 3, got " .. type(amount))
    
    SendMessage(senderNumber, recipientNumber, "<!SENT-PAYMENT-" .. math.floor(amount + 0.5) .. "!>")
end)

-- Export for sending location messages
exports("SendCoords", function(senderNumber, recipientNumber, coords)
    assert(type(senderNumber) == "string", "Expected string for argument 1, got " .. type(senderNumber))
    assert(type(recipientNumber) == "string", "Expected string for argument 2, got " .. type(recipientNumber))
    assert(type(coords) == "vector2", "Expected vector2 for argument 3, got " .. type(coords))
    
    SendMessage(senderNumber, recipientNumber, "<!SENT-LOCATION-X=" .. coords.x .. "Y=" .. coords.y .. "!>")
end)

-- Export for sending regular messages
exports("SendMessage", function(senderNumber, recipientNumber, message, attachments, callback, channelId)
    assert(type(senderNumber) == "string", "Expected string for argument 1, got " .. type(senderNumber))
    assert(type(recipientNumber) == "string", "Expected string or nil for argument 2, got " .. type(recipientNumber))
    assert(type(message) == "string", "Expected string or nil for argument 3, got " .. type(message))
    assert(type(attachments) == "table", "Expected table, string or nil for argument 4, got " .. type(attachments))
    assert(type(callback) == "function", "Expected function or nil for argument 5, got " .. type(callback))
    assert(type(channelId) == "string", "Expected string or nil for argument 6, got " .. type(channelId))
    
    return SendMessage(senderNumber, recipientNumber, message, attachments, callback, channelId)
end)

-- Send a message (player action)
BaseCallback("messages:sendMessage", function(source, phoneNumber, recipientNumber, message, attachments, channelId)
    -- Check for blacklisted words
    if ContainsBlacklistedWord(source, "Messages", message) then
        return false
    end
    
    return SendMessage(phoneNumber, recipientNumber, message, attachments, nil, channelId)
end)

-- Create a group chat
BaseCallback("messages:createGroup", function(source, phoneNumber, memberNumbers, initialMessage, attachments)
    -- Create the group channel
    local channelId = MySQL.insert.await("INSERT INTO phone_message_channels (is_group) VALUES (1)")
    
    if not channelId then
        return false
    end

    -- Prepare members list
    local members = {{number = phoneNumber, isOwner = true}}
    
    -- Add owner to the group
    MySQL.update.await(
        "INSERT INTO phone_message_members (channel_id, phone_number, is_owner) VALUES (?, ?, 1)",
        {channelId, phoneNumber}
    )

    -- Add other members
    for i = 1, #memberNumbers do
        local memberNumber = memberNumbers[i]
        MySQL.update.await(
            "INSERT INTO phone_message_members (channel_id, phone_number, is_owner) VALUES (?, ?, 0)",
            {channelId, memberNumber}
        )
        members[i + 1] = {number = memberNumber, isOwner = false}
    end

    -- Create channel data
    local channelData = {
        id = channelId,
        lastMessage = initialMessage,
        timestamp = os.time() * 1000,
        name = nil,
        isGroup = true,
        members = members,
        unread = false
    }

    -- Notify all members except creator
    for i = 1, #memberNumbers do
        local memberSource = GetSourceFromNumber(memberNumbers[i])
        if memberSource then
            TriggerClientEvent("phone:messages:newChannel", memberSource, channelData)
        end
    end

    -- Notify creator
    TriggerClientEvent("phone:messages:newChannel", source, channelData)

    -- Send initial message if provided
    return SendMessage(phoneNumber, nil, initialMessage, attachments, nil, channelId)
end)

-- Rename a group
BaseCallback("messages:renameGroup", function(source, phoneNumber, channelId, newName)
    local updated = MySQL.update.await(
        "UPDATE phone_message_channels SET `name` = ? WHERE id = ? AND is_group = 1",
        {newName, channelId}
    ) > 0

    if updated then
        TriggerClientEvent("phone:messages:renameGroup", -1, channelId, newName)
    end

    return updated
end)

-- Get recent messages/channels
BaseCallback("messages:getRecentMessages", function(source, phoneNumber)
    return MySQL.query.await([[
        SELECT
            c.id AS channel_id, c.is_group, c.`name`, c.last_message, c.last_message_timestamp,
            m.phone_number, m.is_owner, m.unread, m.deleted
        FROM
            phone_message_channels c
        INNER JOIN phone_message_members m
            ON m.channel_id = c.id
        WHERE
            EXISTS (SELECT TRUE FROM phone_message_members m WHERE m.channel_id = c.id AND m.phone_number = ?)
        ORDER BY c.last_message_timestamp DESC
    ]], {phoneNumber})
end)

-- Get messages from a channel
BaseCallback("messages:getMessages", function(source, phoneNumber, channelId, page)
    return MySQL.query.await([[
        SELECT id, sender, content, attachments, `timestamp`
        FROM phone_message_messages
        WHERE channel_id = ? AND EXISTS (SELECT TRUE FROM phone_message_members m WHERE m.channel_id = ? AND m.phone_number = ?)
        ORDER BY `timestamp` DESC
        LIMIT ?, ?
    ]], {channelId, channelId, phoneNumber, page * 25, 25})
end)

-- Delete a message
BaseCallback("messages:deleteMessage", function(source, phoneNumber, messageId, channelId)
    if not Config.DeleteMessages then
        return false
    end

    -- Check if this is the last message in the channel
    local isLastMessage = MySQL.scalar.await(
        "SELECT MAX(id) FROM phone_message_messages WHERE channel_id = ?",
        {channelId}
    ) == messageId

    -- Delete the message
    local deleted = MySQL.update.await(
        "DELETE FROM phone_message_messages WHERE id = ? AND sender = ? AND channel_id = ?",
        {messageId, phoneNumber, channelId}
    ) > 0

    -- Update channel's last message if needed
    if deleted and isLastMessage then
        MySQL.update.await(
            "UPDATE phone_message_channels SET last_message = ? WHERE id = ?",
            {L("APPS.MESSAGES.MESSAGE_DELETED"), channelId}
        )
    end

    if deleted then
        TriggerClientEvent("phone:messages:messageDeleted", -1, channelId, messageId, isLastMessage)
    end

    return deleted
end)

-- Add member to group
BaseCallback("messages:addMember", function(source, phoneNumber, channelId, newMemberNumber)
    local added = MySQL.update.await(
        "INSERT IGNORE INTO phone_message_members (channel_id, phone_number) VALUES (?, ?)",
        {channelId, newMemberNumber}
    ) > 0

    local newMemberSource = GetSourceFromNumber(newMemberNumber)
    
    if not added then
        return false
    end

    -- Notify all clients
    TriggerClientEvent("phone:messages:memberAdded", -1, channelId, newMemberNumber)

    if not newMemberSource then
        return true
    end

    -- Get channel data for new member
    local members = MySQL.Sync.fetchAll(
        "SELECT phone_number AS `number`, is_owner AS isOwner FROM phone_message_members WHERE channel_id = ?",
        {channelId}
    )

    local channelInfo = MySQL.single.await(
        "SELECT `name`, last_message, last_message_timestamp FROM phone_message_channels WHERE id = ?",
        {channelId}
    )

    -- Send channel to new member
    if #members > 0 and channelInfo then
        TriggerClientEvent("phone:messages:newChannel", newMemberSource, {
            id = channelId,
            lastMessage = channelInfo.last_message,
            timestamp = channelInfo.last_message_timestamp,
            name = channelInfo.name,
            isGroup = true,
            members = members,
            unread = false
        })
    end

    return true
end)

-- Remove member from group
BaseCallback("messages:removeMember", function(source, phoneNumber, channelId, memberToRemove)
    -- Check if requester is owner
    local isOwner = MySQL.scalar.await(
        "SELECT is_owner FROM phone_message_members WHERE channel_id = ? AND phone_number = ?",
        {channelId, phoneNumber}
    )

    if not isOwner then
        return false
    end

    -- Remove the member
    local removed = MySQL.update.await(
        "DELETE FROM phone_message_members WHERE channel_id = ? AND phone_number = ?",
        {channelId, memberToRemove}
    ) > 0

    if removed then
        TriggerClientEvent("phone:messages:memberRemoved", -1, channelId, memberToRemove)
    end

    return removed
end)

-- Leave a group
BaseCallback("messages:leaveGroup", function(source, phoneNumber, channelId)
    -- Check if leaving member is owner
    local isOwner = MySQL.scalar.await(
        "SELECT is_owner FROM phone_message_members WHERE channel_id = ? AND phone_number = ?",
        {channelId, phoneNumber}
    )

    -- Transfer ownership if leaving member is owner
    if isOwner then
        MySQL.update.await([[
            UPDATE phone_message_members m
            SET is_owner = TRUE
            WHERE m.channel_id = ?
            AND m.phone_number != ?
            LIMIT 1
        ]], {channelId, phoneNumber})

        -- Get new owner
        local newOwner = MySQL.scalar.await(
            "SELECT phone_number FROM phone_message_members WHERE channel_id = ? AND is_owner = TRUE",
            {channelId}
        )

        TriggerClientEvent("phone:messages:ownerChanged", -1, channelId, newOwner)
    end

    -- Remove member from group
    local left = MySQL.update.await(
        "DELETE FROM phone_message_members WHERE channel_id = ? AND phone_number = ?",
        {channelId, phoneNumber}
    ) > 0

    -- Check if group is empty
    local isEmpty = MySQL.scalar.await(
        "SELECT COUNT(1) FROM phone_message_members WHERE channel_id = ?",
        {channelId}
    ) == 0

    if left then
        TriggerClientEvent("phone:messages:memberRemoved", -1, channelId, phoneNumber)
    end

    -- Delete empty group
    if isEmpty then
        MySQL.update.await(
            "DELETE FROM phone_message_channels WHERE id = ?",
            {channelId}
        )
        debugprint("Deleted group " .. channelId .. " due to it being empty")
    end

    return left
end)

-- Mark channel as read
BaseCallback("messages:markRead", function(source, phoneNumber, channelId)
    MySQL.update.await(
        "UPDATE phone_message_members SET unread = 0 WHERE channel_id = ? AND phone_number = ?",
        {channelId, phoneNumber}
    )
    return true
end)

-- Delete conversations
BaseCallback("messages:deleteConversations", function(source, phoneNumber, channelIds)
    if type(channelIds) ~= "table" then
        debugprint("expected table, got " .. type(channelIds))
        return false
    end

    MySQL.update.await(
        "UPDATE phone_message_members SET deleted = 1 WHERE channel_id IN (?) AND phone_number = ?",
        {channelIds, phoneNumber}
    )
    
    return true
end)