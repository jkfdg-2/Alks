-- Configuration
local POSTS_PER_PAGE = 15

-- Get marketplace posts with pagination and filtering
local function getMarketplacePosts(page, filters)
    page = page or 0
    
    local params = {}
    local whereClauses = {}
    
    -- Handle search filter
    if filters and filters.search then
        table.insert(whereClauses, "(title LIKE ? OR description LIKE ?)")
        table.insert(params, "%" .. filters.search .. "%")
        table.insert(params, "%" .. filters.search .. "%")
        
        -- Also search by phone number if not filtering by specific seller
        if not filters.from then
            whereClauses[#whereClauses] = whereClauses[#whereClauses] .. " OR phone_number LIKE ?"
            table.insert(params, "%" .. filters.search .. "%")
        end
    end
    
    -- Handle seller filter
    if filters and filters.from then
        local prefix = #whereClauses > 0 and "AND " or ""
        table.insert(whereClauses, prefix .. "phone_number = ?")
        table.insert(params, filters.from)
    end
    
    -- Build query
    local query = [[
        SELECT
            id,
            phone_number AS `number`,
            title,
            description,
            attachments,
            price,
            `timestamp`
        FROM
            phone_marketplace_posts
        {WHERE}
        ORDER BY
            `timestamp` DESC
        LIMIT ?, ?
    ]]
    
    -- Replace WHERE placeholder
    local whereString = #whereClauses > 0 and "WHERE " .. table.concat(whereClauses, " ") or ""
    query = query:gsub("{WHERE}", whereString)
    
    -- Add pagination params
    table.insert(params, page * POSTS_PER_PAGE)
    table.insert(params, POSTS_PER_PAGE)
    
    return MySQL.query.await(query, params)
end

-- Get marketplace posts callback
BaseCallback("marketplace:getPosts", function(source, phoneNumber, data)
    return getMarketplacePosts(data.page, {
        from = data.from,
        search = data.query
    })
end)

-- Create marketplace post
BaseCallback("marketplace:createPost", function(source, phoneNumber, postData)
    local title = postData.title
    local description = postData.description
    local attachments = postData.attachments
    local price = postData.price
    
    -- Validate input
    if not (title and description and attachments and price) or price < 0 then
        return false
    end
    
    -- Check for blacklisted words
    if ContainsBlacklistedWord(source, "MarketPlace", title) or 
       ContainsBlacklistedWord(source, "MarketPlace", description) then
        return false
    end
    
    -- Insert post
    local postId = MySQL.insert.await(
        "INSERT INTO phone_marketplace_posts (phone_number, title, description, attachments, price) VALUES (?, ?, ?, ?, ?)",
        {phoneNumber, title, description, json.encode(attachments), price}
    )
    
    if not postId then
        return false
    end
    
    -- Prepare post data for events
    postData.number = phoneNumber
    postData.id = postId
    
    -- Notify all clients
    TriggerClientEvent("phone:marketplace:newPost", -1, postData)
    
    -- Trigger server event for other resources
    TriggerEvent("Danger_Phone:marketplace:newPost", postData)
    
    -- Log the action
    Log("Marketplace", source, "info",
        L("BACKEND.LOGS.MARKETPLACE_NEW_TITLE"),
        L("BACKEND.LOGS.MARKETPLACE_NEW_DESCRIPTION", {
            seller = FormatNumber(phoneNumber),
            title = title,
            price = price,
            description = description,
            attachments = json.encode(attachments),
            id = postId
        })
    )
    
    return postId
end)

-- Delete marketplace post
BaseCallback("marketplace:deletePost", function(source, phoneNumber, postId)
    local isAdmin = IsAdmin(source)
    
    -- Build query based on permissions
    local params = {postId}
    local query = "DELETE FROM phone_marketplace_posts WHERE id = ?"
    
    -- Non-admins can only delete their own posts
    if not isAdmin then
        query = query .. " AND phone_number = ?"
        table.insert(params, phoneNumber)
    end
    
    -- Execute deletion
    local deleted = MySQL.update.await(query, params)
    
    if deleted > 0 then
        -- Log the deletion
        Log("Marketplace", source, "error",
            L("BACKEND.LOGS.MARKETPLACE_DELETED"),
            string.format("**ID**: %s", postId)
        )
        return true
    end
    
    return false
end)