-- Create a new playlist
BaseCallback("music:createPlaylist", function(source, phoneNumber, playlistName)
    -- Insert new playlist
    local playlistId = MySQL.insert.await(
        "INSERT INTO phone_music_playlists (`name`, phone_number) VALUES (?, ?)",
        {playlistName, phoneNumber}
    )
    
    if not playlistId then
        return false
    end
    
    -- Auto-save playlist to user's saved playlists
    MySQL.update.await(
        "INSERT INTO phone_music_saved_playlists (playlist_id, phone_number) VALUES (?, ?)",
        {playlistId, phoneNumber}
    )
    
    return playlistId
end)

-- Edit playlist details
BaseCallback("music:editPlaylist", function(source, phoneNumber, playlistId, newName, coverImage)
    local updated = MySQL.update.await(
        "UPDATE phone_music_playlists SET `name` = ?, cover = ? WHERE id = ? AND phone_number = ?",
        {newName, coverImage, playlistId, phoneNumber}
    ) > 0
    
    return updated
end)

-- Get all playlists for a user
BaseCallback("music:getPlaylists", function(source, phoneNumber)
    return MySQL.query.await([[
        SELECT s.song_id, p.id, p.`name`, p.cover, p.phone_number
        FROM phone_music_playlists p
        LEFT JOIN phone_music_saved_playlists p2 ON p2.playlist_id = p.id
        LEFT JOIN phone_music_songs s ON s.playlist_id = p.id
        WHERE p2.phone_number = ?
        ORDER BY p.`name` ASC
    ]], {phoneNumber})
end)

-- Delete a playlist
BaseCallback("music:deletePlaylist", function(source, phoneNumber, playlistId)
    local deleted = MySQL.update.await(
        "DELETE FROM phone_music_playlists WHERE id = ? AND phone_number = ?",
        {playlistId, phoneNumber}
    ) > 0
    
    return deleted
end)

-- Save a playlist to user's library
BaseCallback("music:savePlaylist", function(source, phoneNumber, playlistId)
    local saved = MySQL.update.await(
        "INSERT INTO phone_music_saved_playlists (playlist_id, phone_number) VALUES (?, ?) " ..
        "ON DUPLICATE KEY UPDATE phone_number = phone_number",
        {playlistId, phoneNumber}
    ) > 0
    
    return saved
end)

-- Add a song to playlist
BaseCallback("music:addSong", function(source, phoneNumber, playlistId, songId)
    -- Verify ownership
    local isOwner = MySQL.scalar.await(
        "SELECT 1 FROM phone_music_playlists WHERE id = ? AND phone_number = ?",
        {playlistId, phoneNumber}
    )
    
    if not isOwner then
        return false
    end
    
    -- Add song to playlist
    local added = MySQL.update.await(
        "INSERT INTO phone_music_songs (playlist_id, song_id) VALUES (?, ?) " ..
        "ON DUPLICATE KEY UPDATE song_id = song_id",
        {playlistId, songId}
    ) > 0
    
    return added
end)

-- Remove a song from playlist
BaseCallback("music:removeSong", function(source, phoneNumber, playlistId, songId)
    -- Verify ownership
    local isOwner = MySQL.scalar.await(
        "SELECT 1 FROM phone_music_playlists WHERE id = ? AND phone_number = ?",
        {playlistId, phoneNumber}
    )
    
    if not isOwner then
        return false
    end
    
    -- Remove song from playlist
    local removed = MySQL.update.await(
        "DELETE FROM phone_music_songs WHERE playlist_id = ? AND song_id = ?",
        {playlistId, songId}
    ) > 0
    
    return removed
end)