-- Configuration
local POSTS_PER_PAGE = 10

-- Get Yellow Pages posts with pagination and filtering
BaseCallback("yellowPages:getPosts", function(source, phoneNumber, page, filters)
    page = page or 0
    
    local params = {}
    local whereClauses = {}
    
    -- Handle search filter
    if filters and filters.search then
        table.insert(whereClauses, "(title LIKE ? OR description LIKE ?)")
        table.insert(params, "%" .. filters.search .. "%")
        table.insert(params, "%" .. filters.search .. "%")
        
        -- Also search by phone number if not filtering by specific poster
        if not filters.from then
            whereClauses[#whereClauses] = whereClauses[#whereClauses] .. " OR phone_number LIKE ?"
            table.insert(params, "%" .. filters.search .. "%")
        end
    end
    
    -- Handle poster filter
    if filters and filters.from then
        local prefix = #whereClauses > 0 and "AND " or ""
        table.insert(whereClauses, prefix .. "phone_number = ?")
        table.insert(params, filters.from)
    end
    
    -- Build query
    local query = [[
        SELECT
            id,
            phone_number AS `number`,
            title,
            description,
            attachment,
            price,
            `timestamp`
        FROM
            phone_yellow_pages_posts
        {WHERE}
        ORDER BY
            `timestamp` DESC
        LIMIT ?, ?
    ]]
    
    -- Replace WHERE placeholder
    local whereString = #whereClauses > 0 and "WHERE " .. table.concat(whereClauses, " ") or ""
    query = query:gsub("{WHERE}", whereString)
    
    -- Add pagination params
    table.insert(params, page * POSTS_PER_PAGE)
    table.insert(params, POSTS_PER_PAGE)
    
    return MySQL.query.await(query, params)
end)

-- Create Yellow Pages post
BaseCallback("yellowPages:createPost", function(source, phoneNumber, postData)
    -- Validate required fields
    if not postData or not postData.title or not postData.description then
        return false
    end
    
    -- Check for blacklisted words
    if ContainsBlacklistedWord(source, "Pages", postData.title) or 
       ContainsBlacklistedWord(source, "Pages", postData.description) then
        return false
    end
    
    -- Insert post
    local postId = MySQL.insert.await(
        "INSERT INTO phone_yellow_pages_posts (phone_number, title, description, attachment, price) VALUES (@number, @title, @description, @attachment, @price)",
        {
            ["@number"] = phoneNumber,
            ["@title"] = postData.title,
            ["@description"] = postData.description,
            ["@attachment"] = postData.attachment,
            ["@price"] = tonumber(postData.price)
        }
    )
    
    if not postId then
        return false
    end
    
    -- Add ID and phone number to post data
    postData.id = postId
    postData.number = phoneNumber
    
    -- Notify all clients
    TriggerClientEvent("phone:yellowPages:newPost", -1, postData)
    
    -- Trigger server event for other resources
    TriggerEvent("Danger_Phone:pages:newPost", postData)
    
    -- Log the action
    Log("YellowPages", source, "info",
        L("BACKEND.LOGS.YELLOWPAGES_NEW_TITLE"),
        L("BACKEND.LOGS.YELLOWPAGES_NEW_DESCRIPTION", {
            title = postData.title,
            description = postData.description,
            attachment = postData.attachment or "",
            id = postData.id
        })
    )
    
    return postId
end)

-- Delete Yellow Pages post
BaseCallback("yellowPages:deletePost", function(source, phoneNumber, postId)
    local isAdmin = IsAdmin(source)
    
    -- Build query based on permissions
    local query = "DELETE FROM phone_yellow_pages_posts WHERE id = @id"
    local params = {
        ["@id"] = postId,
        ["@number"] = phoneNumber
    }
    
    -- Non-admins can only delete their own posts
    if not isAdmin then
        query = query .. " AND phone_number = @number"
    end
    
    -- Execute deletion
    local deleted = MySQL.update.await(query, params) > 0
    
    if deleted then
        -- Log the deletion
        Log("YellowPages", source, "error",
            L("BACKEND.LOGS.YELLOWPAGES_DELETED"),
            string.format("**ID**: %s", postId)
        )
    end
    
    return true
end)