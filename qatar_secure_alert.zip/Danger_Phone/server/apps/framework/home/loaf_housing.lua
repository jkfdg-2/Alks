if Config.HouseScript ~= "Danger_housing" then
    return
end

RegisterCallback("home:toggleLocked", function(source, id, uniqueId)
    local keyName = ("housing_key_%i_%s"):format(id, uniqueId)
    local hasKey = exports.Danger_keysystem:HasKey(source, keyName)

    if not hasKey then
        return false
    end

    local locked = exports.Danger_housing:IsDoorLocked(id, uniqueId)

    exports.Danger_housing:SetDoorLocked(id, uniqueId, not locked)

    return not locked
end)

RegisterCallback("home:getLocked", function(source, id, uniqueId)
    return exports.Danger_housing:IsDoorLocked(id, uniqueId)
end)
