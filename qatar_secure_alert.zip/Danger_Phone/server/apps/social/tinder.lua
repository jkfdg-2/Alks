-- Tinder App Backend for FiveM Phone System

-- Create Account Handler
BaseCallback("tinder:createAccount", function(source, phoneNumber, accountData)
    -- Check if account already exists
    local accountExists = MySQL.scalar.await(
        "SELECT TRUE FROM phone_tinder_accounts WHERE phone_number = ?",
        {phoneNumber}
    )
    
    if accountExists then
        return false
    end
    
    -- Insert new account
    local rowsAffected = MySQL.update.await([[
        INSERT INTO phone_tinder_accounts
            (`name`, phone_number, photos, bio, dob, is_male, interested_men, interested_women)
        VALUES
            (@name, @phoneNumber, @photos, @bio, @dob, @isMale, @showMen, @showWomen)
    ]], {
        ["@name"] = accountData.name,
        ["@phoneNumber"] = phoneNumber,
        ["@photos"] = json.encode(accountData.photos),
        ["@bio"] = accountData.bio,
        ["@dob"] = accountData.dob,
        ["@isMale"] = accountData.isMale,
        ["@showMen"] = accountData.showMen,
        ["@showWomen"] = accountData.showWomen
    })
    
    return rowsAffected > 0
end, false)

-- Delete Account Handler
BaseCallback("tinder:deleteAccount", function(source, phoneNumber)
    -- Check if account deletion is enabled
    if not Config.DeleteAccount.Spark then
        infoprint("warning", "%s tried to delete their spark account, but it's not enabled in the config.", source)
        return false
    end
    
    -- Delete main account
    local accountDeleted = MySQL.update.await(
        "DELETE FROM phone_tinder_accounts WHERE phone_number = ?",
        {phoneNumber}
    )
    
    if accountDeleted == 0 then
        return false
    end
    
    -- Clean up related data
    MySQL.update("DELETE FROM phone_tinder_swipes WHERE swiper = ? OR swipee = ?", {phoneNumber, phoneNumber})
    MySQL.update("DELETE FROM phone_tinder_matches WHERE phone_number_1 = ? OR phone_number_2 = ?", {phoneNumber, phoneNumber})
    MySQL.update("DELETE FROM phone_tinder_messages WHERE sender = ? OR recipient = ?", {phoneNumber, phoneNumber})
    
    return true
end)

-- Update Account Handler
BaseCallback("tinder:updateAccount", function(source, phoneNumber, accountData)
    local rowsAffected = MySQL.update.await([[
        UPDATE phone_tinder_accounts
        SET
            `name` = @name,
            photos = @photos,
            bio = @bio,
            is_male = @isMale,
            interested_men = @showMen,
            interested_women = @showWomen,
            `active` = @active
        WHERE phone_number = @phoneNumber
    ]], {
        ["@name"] = accountData.name,
        ["@photos"] = json.encode(accountData.photos),
        ["@bio"] = accountData.bio,
        ["@isMale"] = accountData.isMale,
        ["@showMen"] = accountData.showMen,
        ["@showWomen"] = accountData.showWomen,
        ["@active"] = accountData.active,
        ["@phoneNumber"] = phoneNumber
    })
    
    return rowsAffected > 0
end, false)

-- Check Login Status Handler
BaseCallback("tinder:isLoggedIn", function(source, phoneNumber)
    local accountData = MySQL.single.await(
        "SELECT `name`, photos, bio, dob, is_male, interested_men, interested_women, `active` FROM phone_tinder_accounts WHERE phone_number = ?",
        {phoneNumber}
    )
    
    -- Update last seen timestamp if account exists
    if accountData then
        MySQL.update.await(
            "UPDATE phone_tinder_accounts SET last_seen = NOW() WHERE phone_number = ?",
            {phoneNumber}
        )
    end
    
    return accountData
end, false)

-- Get Feed Handler (Potential Matches)
BaseCallback("tinder:getFeed", function(source, phoneNumber, page)
    local RESULTS_PER_PAGE = 10
    
    return MySQL.query.await([[
        SELECT
            a.`name`, a.phone_number, a.photos, a.bio, a.dob
        FROM
            phone_tinder_accounts a
        JOIN
            phone_tinder_accounts b
        ON
            b.phone_number = @phoneNumber
        WHERE
            a.phone_number != @phoneNumber
            AND a.`active` = 1
            AND (a.is_male = b.interested_men OR a.is_male = (NOT b.interested_women))
            AND (a.interested_men = b.is_male OR a.interested_women = (NOT b.is_male))
            AND NOT EXISTS (
                SELECT TRUE FROM phone_tinder_swipes 
                WHERE swiper = @phoneNumber AND swipee = a.phone_number
            )
        ORDER BY a.phone_number
        LIMIT @offset, @limit
    ]], {
        ["@phoneNumber"] = phoneNumber,
        ["@offset"] = page * RESULTS_PER_PAGE,
        ["@limit"] = RESULTS_PER_PAGE
    })
end, {})

-- Swipe Handler
BaseCallback("tinder:swipe", function(source, swiperPhone, swipeePhone, isLike)
    -- Record the swipe
    local swipeResult = MySQL.query.await(
        "INSERT INTO phone_tinder_swipes (swiper, swipee, liked) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE liked = ?",
        {swiperPhone, swipeePhone, isLike, isLike}
    )
    
    -- If not a like or failed to insert, return false
    if swipeResult == 0 or not isLike then
        return false
    end
    
    -- Check if the other person also liked
    local mutualLike = MySQL.scalar.await(
        "SELECT liked FROM phone_tinder_swipes WHERE swiper = ? AND swipee = ?",
        {swipeePhone, swiperPhone}
    ) == true
    
    if not mutualLike then
        return false
    end
    
    -- Create match
    MySQL.update.await(
        "INSERT INTO phone_tinder_matches (phone_number_1, phone_number_2) VALUES (?, ?)",
        {swiperPhone, swipeePhone}
    )
    
    -- Get swiper info for notification
    local swiperInfo = MySQL.single.await(
        "SELECT `name`, photos FROM phone_tinder_accounts WHERE phone_number = ?",
        {swiperPhone}
    )
    
    if not swiperInfo then
        return
    end
    
    -- Send match notification
    local photos = json.decode(swiperInfo.photos)
    SendNotification(swipeePhone, {
        app = "Tinder",
        title = L("BACKEND.TINDER.NEW_MATCH"),
        content = L("BACKEND.TINDER.MATCHED_WITH", {name = swiperInfo.name}),
        thumbnail = photos[1]
    })
    
    return true
end)

-- Get Matches Handler
BaseCallback("tinder:getMatches", function(source, phoneNumber)
    return MySQL.query.await([[
        SELECT
            a.`name`, a.phone_number, a.photos, a.dob, a.bio, a.is_male, b.latest_message
        FROM
            phone_tinder_accounts a
        JOIN
            phone_tinder_matches b
        ON
            (b.phone_number_1 = @phoneNumber AND b.phone_number_2 = a.phone_number)
            OR
            (b.phone_number_2 = @phoneNumber AND b.phone_number_1 = a.phone_number)
        ORDER BY b.latest_message_timestamp DESC
    ]], {
        ["@phoneNumber"] = phoneNumber
    })
end)

-- Send Message Handler
BaseCallback("tinder:sendMessage", function(source, senderPhone, recipientPhone, content, attachments)
    -- Check for blacklisted words
    if ContainsBlacklistedWord(source, "Spark", content) then
        return false
    end
    
    -- Get sender info
    local senderInfo = MySQL.single.await(
        "SELECT `name`, photos FROM phone_tinder_accounts WHERE phone_number = ?",
        {senderPhone}
    )
    
    if not senderInfo then
        return true
    end
    
    -- Insert message
    local messageId = MySQL.insert.await(
        "INSERT INTO phone_tinder_messages (sender, recipient, content, attachments) VALUES (?, ?, ?, ?)",
        {senderPhone, recipientPhone, content, attachments}
    )
    
    if not messageId then
        return false
    end
    
    -- Update latest message in matches
    MySQL.update.await(
        "UPDATE phone_tinder_matches SET latest_message = ? WHERE (phone_number_1 = ? AND phone_number_2 = ?) OR (phone_number_2 = ? AND phone_number_1 = ?)",
        {content, senderPhone, recipientPhone, senderPhone, recipientPhone}
    )
    
    -- Send real-time message to recipient if online
    local recipientSource = GetSourceFromNumber(recipientPhone)
    if recipientSource then
        TriggerClientEvent("phone:tinder:receiveMessage", recipientSource, {
            sender = senderPhone,
            recipient = recipientPhone,
            content = content,
            attachments = attachments,
            timestamp = os.time() * 1000
        })
    end
    
    -- Send notification
    local senderPhotos = json.decode(senderInfo.photos)
    local notificationThumbnail = attachments and json.decode(attachments)[1] or nil
    
    SendNotification(recipientPhone, {
        app = "Tinder",
        title = senderInfo.name,
        content = content,
        thumbnail = notificationThumbnail,
        avatar = senderPhotos[1],
        showAvatar = true
    })
    
    return true
end)

-- Get Messages Handler
BaseCallback("tinder:getMessages", function(source, phoneNumber, otherNumber, page)
    local MESSAGES_PER_PAGE = 25
    
    return MySQL.query.await([[
        SELECT
            sender, recipient, content, attachments, timestamp
        FROM
            phone_tinder_messages
        WHERE
            (sender = @phoneNumber AND recipient = @otherNumber)
            OR
            (recipient = @phoneNumber AND sender = @otherNumber)
        ORDER BY timestamp DESC
        LIMIT @offset, @limit
    ]], {
        ["@phoneNumber"] = phoneNumber,
        ["@otherNumber"] = otherNumber,
        ["@offset"] = page * MESSAGES_PER_PAGE,
        ["@limit"] = MESSAGES_PER_PAGE
    })
end)

-- Auto-disable inactive accounts thread
CreateThread(function()
    if not Config.AutoDisableSparkAccounts then
        return
    end
    
    local CHECK_INTERVAL = 3600000 -- 1 hour in milliseconds
    local INACTIVE_DAYS = type(Config.AutoDisableSparkAccounts) == "number" 
        and math.max(Config.AutoDisableSparkAccounts, 1) 
        or 7
    
    while true do
        MySQL.update(
            "UPDATE phone_tinder_accounts SET active = 0 WHERE active = 1 AND last_seen < NOW() - INTERVAL ? DAY",
            {INACTIVE_DAYS},
            function(rowsAffected)
                debugprint("Disabled", rowsAffected, "inactive Spark accounts.")
            end
        )
        
        Wait(CHECK_INTERVAL)
    end
end)