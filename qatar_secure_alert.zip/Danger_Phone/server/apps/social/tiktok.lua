-- TikTok/Trendy App Backend for FiveM Phone System

-- Helper Functions
local function getLoggedInAccount(source)
    local phoneNumber = GetEquippedPhoneNumber(source)
    if not phoneNumber then
        return false
    end
    return GetLoggedInAccount(phoneNumber, "TikTok")
end

local function createAuthenticatedCallback(callbackName, handler, defaultReturn)
    BaseCallback("tiktok:" .. callbackName, function(source, phoneNumber, ...)
        local account = GetLoggedInAccount(phoneNumber, "TikTok")
        if not account then
            return defaultReturn
        end
        return handler(source, phoneNumber, account, ...)
    end, defaultReturn)
end

local function sendNotificationsToAccount(username, notification)
    local query = "SELECT phone_number FROM phone_logged_in_accounts WHERE username = ? AND app = 'TikTok' AND `active` = 1"
    local users = MySQL.query.await(query, {username})
    
    notification.app = "TikTok"
    for _, user in ipairs(users) do
        if user.phone_number ~= phoneNumber then
            SendNotification(user.phone_number, notification)
        end
    end
end

local function getAccountInfo(username, loggedInUser)
    local baseFields = "`name`, bio, avatar, username, verified, follower_count, following_count, like_count, twitter, instagram, show_likes"
    local query
    local params = {["@username"] = username}
    
    if loggedInUser then
        query = string.format([[
            SELECT %s,
                (SELECT TRUE FROM phone_tiktok_follows WHERE follower = @username AND followed = @loggedIn) AS isFollowingYou,
                (SELECT TRUE FROM phone_tiktok_follows WHERE follower = @loggedIn AND followed = @username) AS isFollowing
            FROM phone_tiktok_accounts WHERE username = @username
        ]], baseFields)
        params["@loggedIn"] = loggedInUser
    else
        query = string.format("SELECT %s FROM phone_tiktok_accounts WHERE username = @username", baseFields)
    end
    
    local result = MySQL.Sync.fetchAll(query, params)
    local account = result and result[1]
    
    if account then
        account.isFollowing = account.isFollowing == 1
        account.isFollowingYou = account.isFollowingYou == 1
    end
    
    return account
end

-- Notification Types
local NOTIFICATION_TYPES = {
    like = "BACKEND.TIKTOK.LIKE",
    save = "BACKEND.TIKTOK.SAVE",
    comment = "BACKEND.TIKTOK.COMMENT",
    follow = "BACKEND.TIKTOK.FOLLOW",
    like_comment = "BACKEND.TIKTOK.LIKED_COMMENT",
    reply = "BACKEND.TIKTOK.REPLIED_COMMENT",
    message = "BACKEND.TIKTOK.DM"
}

local function sendTikTokNotification(toUsername, fromUsername, notificationType, videoId, commentId, extra)
    local localeKey = NOTIFICATION_TYPES[notificationType]
    if not localeKey or toUsername == fromUsername then
        return
    end
    
    local fromAccount = getAccountInfo(fromUsername)
    if not fromAccount then
        return
    end
    
    -- Check if notification already exists (except for messages)
    if notificationType ~= "message" then
        local checkParams = {toUsername, fromUsername, notificationType}
        local checkQuery = "SELECT 1 FROM phone_tiktok_notifications WHERE username = ? AND `from` = ? AND `type` = ?"
        
        if videoId then
            checkQuery = checkQuery .. " AND video_id = ?"
            table.insert(checkParams, videoId)
        end
        
        if commentId then
            checkQuery = checkQuery .. " AND comment_id = ?"
            table.insert(checkParams, commentId)
        end
        
        if MySQL.scalar.await(checkQuery, checkParams) == 1 then
            return
        end
        
        -- Insert new notification
        MySQL.insert(
            "INSERT INTO phone_tiktok_notifications (username, `from`, `type`, video_id, comment_id) VALUES (?, ?, ?, ?, ?)",
            {toUsername, fromUsername, notificationType, videoId, commentId}
        )
    end
    
    -- Get video thumbnail if applicable
    local thumbnail
    if videoId then
        thumbnail = MySQL.Sync.fetchScalar("SELECT src FROM phone_tiktok_videos WHERE id = @id", {["@id"] = videoId})
    end
    
    -- Send notification
    local notification = {
        app = "TikTok",
        title = L(localeKey, {displayName = fromAccount.name}),
        thumbnail = thumbnail
    }
    
    if notificationType == "message" then
        notification.avatar = fromAccount.avatar
        notification.content = extra.content
        notification.showAvatar = true
    end
    
    -- Send to all logged in devices
    local users = MySQL.query.await(
        "SELECT phone_number FROM phone_logged_in_accounts WHERE username = ? AND app = 'TikTok' AND `active` = 1",
        {toUsername}
    )
    
    for _, user in ipairs(users) do
        SendNotification(user.phone_number, notification)
    end
end

-- Clean up old notifications periodically
CreateThread(function()
    while true do
        MySQL.Async.execute("DELETE FROM phone_tiktok_notifications WHERE `timestamp` < DATE_SUB(NOW(), INTERVAL 7 DAY)", {})
        Wait(3600000) -- 1 hour
    end
end)

-- Callbacks

-- Get Notifications
RegisterLegacyCallback("tiktok:getNotifications", function(source, cb, page)
    local account = getLoggedInAccount(source)
    if not account then
        return cb({success = false, error = "not_logged_in"})
    end
    
    MySQL.Async.fetchAll([[
        SELECT
            n.`type`, n.`timestamp`, n.video_id AS videoId,
            a.`name`, a.avatar, a.username, a.verified,
            CASE WHEN n.video_id IS NOT NULL THEN v.src ELSE NULL END AS videoSrc,
            n.comment_id,
            CASE WHEN n.comment_id IS NOT NULL THEN c.comment ELSE NULL END AS commentText,
            CASE WHEN n.`type` = 'follow' THEN 
                CASE WHEN f.follower IS NOT NULL THEN TRUE ELSE FALSE END
            ELSE NULL END AS isFollowing,
            CASE WHEN n.`type` = 'reply' THEN c_original.comment ELSE NULL END AS originalText
        FROM phone_tiktok_notifications n
        LEFT JOIN phone_tiktok_accounts a ON n.from = a.username
        LEFT JOIN phone_tiktok_videos v ON n.video_id = v.id
        LEFT JOIN phone_tiktok_comments c ON n.comment_id = c.id
        LEFT JOIN phone_tiktok_comments c_original ON c.reply_to = c_original.id
        LEFT JOIN phone_tiktok_follows f ON n.username = f.follower AND n.from = f.followed
        WHERE n.username = @username
        ORDER BY n.`timestamp` DESC
        LIMIT @page, @perPage
    ]], {
        ["@username"] = account,
        ["@page"] = (page or 0) * 15,
        ["@perPage"] = 15
    }, function(results)
        cb({success = true, data = results})
    end)
end)

-- Login
RegisterLegacyCallback("tiktok:login", function(source, cb, username, password)
    local phoneNumber = GetEquippedPhoneNumber(source)
    if not phoneNumber then
        return cb({success = false, error = "no_number"})
    end
    
    username = username:lower()
    
    MySQL.Async.fetchScalar("SELECT password FROM phone_tiktok_accounts WHERE username = @username", {
        ["@username"] = username
    }, function(storedPassword)
        if not storedPassword then
            return cb({success = false, error = "invalid_username"})
        end
        
        if not VerifyPasswordHash(password, storedPassword) then
            return cb({success = false, error = "incorrect_password"})
        end
        
        local accountInfo = getAccountInfo(username)
        if not accountInfo then
            return cb({success = false, error = "invalid_username"})
        end
        
        AddLoggedInAccount(phoneNumber, "TikTok", username)
        cb({success = true, data = accountInfo})
    end)
end)

-- Signup
RegisterLegacyCallback("tiktok:signup", function(source, cb, username, password, displayName)
    local phoneNumber = GetEquippedPhoneNumber(source)
    if not phoneNumber then
        return cb({success = false, error = "UNKNOWN"})
    end
    
    username = username:lower()
    
    if not IsUsernameValid(username) then
        return cb({success = false, error = "USERNAME_NOT_ALLOWED"})
    end
    
    -- Check if username already exists
    local exists = MySQL.Sync.fetchScalar("SELECT TRUE FROM phone_tiktok_accounts WHERE username = @username", {
        ["@username"] = username
    })
    
    if exists then
        return cb({success = false, error = "USERNAME_TAKEN"})
    end
    
    -- Create account
    MySQL.Sync.execute(
        "INSERT INTO phone_tiktok_accounts (`name`, username, password, phone_number) VALUES (@displayName, @username, @password, @phoneNumber)",
        {
            ["@displayName"] = displayName,
            ["@username"] = username,
            ["@password"] = GetPasswordHash(password),
            ["@phoneNumber"] = phoneNumber
        }
    )
    
    AddLoggedInAccount(phoneNumber, "TikTok", username)
    cb({success = true})
    
    -- Auto-follow feature
    if Config.AutoFollow.Enabled and Config.AutoFollow.Trendy.Enabled then
        for _, accountToFollow in ipairs(Config.AutoFollow.Trendy.Accounts) do
            MySQL.update.await(
                "INSERT INTO phone_tiktok_follows (followed, follower) VALUES (?, ?)",
                {accountToFollow, username}
            )
        end
    end
end)

-- Change Password
createAuthenticatedCallback("changePassword", function(source, phoneNumber, account, oldPassword, newPassword)
    if not Config.ChangePassword.Trendy then
        infoprint("warning", "%s tried to change password on Trendy, but it's not enabled in the config.", source)
        return false
    end
    
    if oldPassword == newPassword or #newPassword < 3 then
        debugprint("same password / too short")
        return false
    end
    
    -- Verify old password
    local storedPassword = MySQL.scalar.await(
        "SELECT password FROM phone_tiktok_accounts WHERE username = ?",
        {account}
    )
    
    if not storedPassword or not VerifyPasswordHash(oldPassword, storedPassword) then
        return false
    end
    
    -- Update password
    local updated = MySQL.update.await(
        "UPDATE phone_tiktok_accounts SET password = ? WHERE username = ?",
        {GetPasswordHash(newPassword), account}
    )
    
    if updated == 0 then
        return false
    end
    
    -- Send logout notification
    sendNotificationsToAccount(account, {
        title = L("BACKEND.MISC.LOGGED_OUT_PASSWORD.TITLE"),
        content = L("BACKEND.MISC.LOGGED_OUT_PASSWORD.DESCRIPTION")
    }, phoneNumber)
    
    -- Remove all logged in sessions except current
    MySQL.update.await(
        "DELETE FROM phone_logged_in_accounts WHERE username = ? AND app = 'TikTok' AND phone_number != ?",
        {account, phoneNumber}
    )
    
    ClearActiveAccountsCache("TikTok", account, phoneNumber)
    
    Log("Trendy", source, "info", L("BACKEND.LOGS.CHANGED_PASSWORD.TITLE"), 
        L("BACKEND.LOGS.CHANGED_PASSWORD.DESCRIPTION", {
            number = phoneNumber,
            username = account,
            app = "Trendy"
        })
    )
    
    -- Trigger logout on all clients
    TriggerClientEvent("phone:logoutFromApp", -1, {
        username = account,
        app = "tiktok",
        reason = "password",
        number = phoneNumber
    })
    
    return true
end, false)

-- Delete Account
createAuthenticatedCallback("deleteAccount", function(source, phoneNumber, account, password)
    if not Config.DeleteAccount.Trendy then
        infoprint("warning", "%s tried to delete their account on Trendy, but it's not enabled in the config.", source)
        return false
    end
    
    -- Verify password
    local storedPassword = MySQL.scalar.await(
        "SELECT password FROM phone_tiktok_accounts WHERE username = ?",
        {account}
    )
    
    if not storedPassword or not VerifyPasswordHash(password, storedPassword) then
        return false
    end
    
    -- Delete account
    local deleted = MySQL.update.await(
        "DELETE FROM phone_tiktok_accounts WHERE username = ?",
        {account}
    )
    
    if deleted == 0 then
        return false
    end
    
    -- Send deletion notification
    sendNotificationsToAccount(account, {
        title = L("BACKEND.MISC.DELETED_NOTIFICATION.TITLE"),
        content = L("BACKEND.MISC.DELETED_NOTIFICATION.DESCRIPTION")
    })
    
    -- Remove all logged in sessions
    MySQL.update.await(
        "DELETE FROM phone_logged_in_accounts WHERE username = ? AND app = 'TikTok'",
        {account}
    )
    
    ClearActiveAccountsCache("TikTok", account)
    
    Log("Trendy", source, "info", L("BACKEND.LOGS.DELETED_ACCOUNT.TITLE"), 
        L("BACKEND.LOGS.DELETED_ACCOUNT.DESCRIPTION", {
            number = phoneNumber,
            username = account,
            app = "Trendy"
        })
    )
    
    -- Trigger logout on all clients
    TriggerClientEvent("phone:logoutFromApp", -1, {
        username = account,
        app = "tiktok",
        reason = "deleted"
    })
    
    return true
end, false)

-- Logout
RegisterLegacyCallback("tiktok:logout", function(source, cb)
    local account = getLoggedInAccount(source)
    if not account then
        return cb(false)
    end
    
    local phoneNumber = GetEquippedPhoneNumber(source)
    if not phoneNumber then
        return cb(false)
    end
    
    RemoveLoggedInAccount(phoneNumber, "TikTok", account)
    cb(true)
end)

-- Check if logged in
RegisterLegacyCallback("tiktok:isLoggedIn", function(source, cb)
    local account = getLoggedInAccount(source)
    cb(account and getAccountInfo(account) or false)
end)

-- Get Profile
RegisterLegacyCallback("tiktok:getProfile", function(source, cb, username)
    cb(getAccountInfo(username, getLoggedInAccount(source)))
end)

-- Update Profile
RegisterLegacyCallback("tiktok:updateProfile", function(source, cb, data)
    local phoneNumber = GetEquippedPhoneNumber(source)
    if not phoneNumber then
        return cb({success = false, error = "no_number"})
    end
    
    local account = getLoggedInAccount(source)
    if not account then
        return cb({success = false, error = "not_logged_in"})
    end
    
    -- Validate data
    if #data.name > 30 then
        return cb({success = false, error = "display_name_too_long"})
    end
    
    if data.bio and #data.bio > 150 then
        return cb({success = false, error = "bio_too_long"})
    end
    
    -- Verify Twitter account if provided
    if data.twitter then
        local hasTwitter = MySQL.Sync.fetchScalar(
            "SELECT TRUE FROM phone_logged_in_accounts WHERE phone_number = @phoneNumber and app = @app and username = @username",
            {
                ["@phoneNumber"] = phoneNumber,
                ["@app"] = "Twitter",
                ["@username"] = data.twitter
            }
        )
        if not hasTwitter then
            return cb({success = false, error = "invalid_twitter"})
        end
    end
    
    -- Verify Instagram account if provided
    if data.instagram then
        local hasInstagram = MySQL.Sync.fetchScalar(
            "SELECT TRUE FROM phone_logged_in_accounts WHERE phone_number = @phoneNumber and app = @app and username = @username",
            {
                ["@phoneNumber"] = phoneNumber,
                ["@app"] = "Instagram",
                ["@username"] = data.instagram
            }
        )
        if not hasInstagram then
            return cb({success = false, error = "invalid_instagram"})
        end
    end
    
    -- Update profile
    MySQL.Async.execute(
        "UPDATE phone_tiktok_accounts SET `name` = @displayName, bio = @bio, avatar = @avatar, twitter = @twitter, instagram = @instagram, `show_likes` = @showLikes WHERE username = @username",
        {
            ["@displayName"] = data.name,
            ["@bio"] = data.bio,
            ["@avatar"] = data.avatar,
            ["@twitter"] = data.twitter,
            ["@instagram"] = data.instagram,
            ["@showLikes"] = data.show_likes == true,
            ["@username"] = account
        },
        function()
            cb({success = true})
        end
    )
end)

-- Search Accounts
RegisterLegacyCallback("tiktok:searchAccounts", function(source, cb, query, page)
    local account = getLoggedInAccount(source)
    if not account then
        return cb(false)
    end
    
    MySQL.Async.fetchAll([[
        SELECT `name`, username, avatar, verified, follower_count, video_count,
            (SELECT TRUE FROM phone_tiktok_follows WHERE follower = @username AND followed = a.username) AS isFollowing
        FROM phone_tiktok_accounts a
        WHERE username LIKE @query OR `name` LIKE @query
        ORDER BY username
        LIMIT @page, @perPage
    ]], {
        ["@query"] = "%" .. query .. "%",
        ["@username"] = account,
        ["@page"] = (page or 0) * 10,
        ["@perPage"] = 10
    }, cb)
end)

-- Toggle Follow
RegisterLegacyCallback("tiktok:toggleFollow", function(source, cb, targetUsername, shouldFollow)
    local account = getLoggedInAccount(source)
    if not account then
        return cb({success = false, error = "not_logged_in"})
    end
    
    if targetUsername == account then
        return cb({success = false, error = "cannot_follow_self"})
    end
    
    local targetAccount = getAccountInfo(targetUsername)
    if not targetAccount then
        return cb({success = false, error = "invalid_username"})
    end
    
    cb({success = true})
    
    local query = shouldFollow == true and 
        "INSERT IGNORE INTO phone_tiktok_follows (follower, followed) VALUES (@follower, @followed)" or
        "DELETE FROM phone_tiktok_follows WHERE follower = @follower AND followed = @followed"
    
    MySQL.Async.execute(query, {
        ["@follower"] = account,
        ["@followed"] = targetUsername
    }, function(affectedRows)
        if affectedRows == 0 then
            return
        end
        
        local action = shouldFollow == true and "add" or "remove"
        TriggerClientEvent("phone:tiktok:updateFollowers", -1, targetUsername, action)
        TriggerClientEvent("phone:tiktok:updateFollowing", -1, account, action)
        
        if shouldFollow == true then
            sendTikTokNotification(targetUsername, account, "follow")
        end
    end)
end)

-- Get Following
RegisterLegacyCallback("tiktok:getFollowing", function(source, cb, username, page)
    local account = getLoggedInAccount(source)
    if not account then
        return cb({})
    end
    
    MySQL.Async.fetchAll([[
        SELECT
            a.username, a.`name`, a.avatar, a.verified,
            (SELECT TRUE FROM phone_tiktok_follows WHERE follower = a.username AND followed = @loggedIn) AS isFollowingYou,
            (SELECT TRUE FROM phone_tiktok_follows WHERE follower = @loggedIn AND followed = a.username) AS isFollowing
        FROM phone_tiktok_follows f
        INNER JOIN phone_tiktok_accounts a ON a.username = f.followed
        WHERE f.follower = @username
        ORDER BY a.username
        LIMIT @page, @perPage
    ]], {
        ["@username"] = username,
        ["@loggedIn"] = account,
        ["@page"] = (page or 0) * 15,
        ["@perPage"] = 15
    }, cb)
end)

-- Get Followers
RegisterLegacyCallback("tiktok:getFollowers", function(source, cb, username, page)
    local account = getLoggedInAccount(source)
    if not account then
        return cb({})
    end
    
    MySQL.Async.fetchAll([[
        SELECT
            a.username, a.`name`, a.avatar, a.verified,
            (SELECT TRUE FROM phone_tiktok_follows WHERE follower = @username AND followed = @loggedIn) AS isFollowingYou,
            (SELECT TRUE FROM phone_tiktok_follows WHERE follower = @loggedIn AND followed = @username) AS isFollowing
        FROM phone_tiktok_follows f
        INNER JOIN phone_tiktok_accounts a ON a.username = f.follower
        WHERE f.followed = @username
        ORDER BY a.username
        LIMIT @page, @perPage
    ]], {
        ["@username"] = username,
        ["@loggedIn"] = account,
        ["@page"] = (page or 0) * 15,
        ["@perPage"] = 15
    }, cb)
end)

-- Upload Video
RegisterLegacyCallback("tiktok:uploadVideo", function(source, cb, videoData)
    local account = getLoggedInAccount(source)
    if not account then
        return cb({success = false, error = "not_logged_in"})
    end
    
    if ContainsBlacklistedWord(source, "Trendy", videoData.caption) then
        return cb(false)
    end
    
    -- Validate video data
    if not videoData.src or type(videoData.src) ~= "string" or #videoData.src == 0 then
        return cb({success = false, error = "invalid_src"})
    end
    
    if not videoData.caption or type(videoData.caption) ~= "string" or #videoData.caption == 0 then
        return cb({success = false, error = "invalid_caption"})
    end
    
    local videoId = GenerateId("phone_tiktok_videos", "id")
    
    MySQL.Async.execute(
        "INSERT INTO phone_tiktok_videos (id, username, src, caption, metadata, music) VALUES (@id, @username, @src, @caption, @metadata, @music)",
        {
            ["@id"] = videoId,
            ["@username"] = account,
            ["@src"] = videoData.src,
            ["@caption"] = videoData.caption,
            ["@metadata"] = videoData.metadata,
            ["@music"] = videoData.music
        },
        function()
            cb({success = true, id = videoId})
            
            -- Broadcast new video
            local newVideoData = {
                username = account,
                caption = videoData.caption,
                videoUrl = videoData.src,
                id = videoId
            }
            
            TriggerClientEvent("phone:tiktok:newVideo", -1, newVideoData)
            TriggerEvent("Danger_Phone:trendy:newPost", newVideoData)
            TrackSocialMediaPost("trendy", {videoData.src})
            
            Log("Trendy", source, "success", L("BACKEND.LOGS.TRENDY_UPLOAD_TITLE"), 
                L("BACKEND.LOGS.TRENDY_UPLOAD_DESCRIPTION", {
                    username = account,
                    caption = videoData.caption,
                    id = videoId
                })
            )
        end
    )
end)

-- Delete Video
RegisterLegacyCallback("tiktok:deleteVideo", function(source, cb, videoId)
    local account = getLoggedInAccount(source)
    if not account then
        return cb({success = false, error = "not_logged_in"})
    end
    
    local query = "DELETE FROM phone_tiktok_videos WHERE id = @id"
    if not IsAdmin(source) then
        query = query .. " AND username = @username"
    end
    
    MySQL.Async.execute(query, {
        ["@id"] = videoId,
        ["@username"] = account
    }, function(affectedRows)
        cb({success = affectedRows > 0})
        
        if affectedRows > 0 then
            Log("Trendy", source, "error", L("BACKEND.LOGS.TRENDY_DELETE_TITLE"), 
                L("BACKEND.LOGS.TRENDY_DELETE_DESCRIPTION", {
                    username = account,
                    id = videoId
                })
            )
        end
    end)
end)

-- Toggle Pinned Video
RegisterLegacyCallback("tiktok:togglePinnedVideo", function(source, cb, videoId, shouldPin)
    local account = getLoggedInAccount(source)
    if not account then
        return cb({success = false, error = "not_logged_in"})
    end
    
    -- Check pinned video limit
    if shouldPin then
        local pinnedCount = MySQL.Sync.fetchScalar(
            "SELECT COUNT(*) FROM phone_tiktok_pinned_videos WHERE username = @username",
            {["@username"] = account}
        )
        
        if pinnedCount >= 3 then
            return cb({success = false, error = "max_pinned"})
        end
    end
    
    local query = shouldPin and
        "INSERT INTO phone_tiktok_pinned_videos (username, video_id) VALUES (@username, @videoId)" or
        "DELETE FROM phone_tiktok_pinned_videos WHERE username = @username AND video_id = @videoId"
    
    MySQL.Async.execute(query, {
        ["@videoId"] = videoId,
        ["@username"] = account
    }, function(affectedRows)
        cb({success = affectedRows > 0})
    end)
end)

-- Base video query
local VIDEO_BASE_QUERY = [[
    SELECT
        v.id, v.src, v.caption, v.`timestamp`,
        p.video_id IS NOT NULL AS pinned,
        v.likes, v.comments, v.views, v.saves,
        (SELECT TRUE FROM phone_tiktok_likes WHERE username = @loggedIn AND video_id = v.id) AS liked,
        (SELECT TRUE FROM phone_tiktok_saves WHERE username = @loggedIn AND video_id = v.id) AS saved,
        w.video_id IS NOT NULL AS viewed,
        v.metadata, v.music,
        a.username, a.`name`, a.avatar, a.verified,
        (SELECT TRUE FROM phone_tiktok_follows WHERE follower = @username AND followed = a.username) AS following
    FROM phone_tiktok_videos v
    INNER JOIN phone_tiktok_accounts a ON a.username = v.username
    LEFT JOIN phone_tiktok_views w ON v.id = w.video_id AND w.username = @loggedIn
    LEFT JOIN phone_tiktok_pinned_videos p ON p.video_id = v.id AND p.username = @loggedIn
]]

-- Get Single Video
RegisterLegacyCallback("tiktok:getVideo", function(source, cb, videoId)
    local account = getLoggedInAccount(source)
    if not account then
        return cb({success = false, error = "not_logged_in"})
    end
    
    MySQL.Async.fetchAll(VIDEO_BASE_QUERY .. " WHERE v.id = @id", {
        ["@id"] = videoId,
        ["@loggedIn"] = account,
        ["@username"] = account
    }, function(results)
        if #results == 0 then
            return cb({success = false, error = "invalid_id"})
        end
        
        cb({success = true, video = results[1]})
    end)
end)

-- Get Videos (Feed)
RegisterLegacyCallback("tiktok:getVideos", function(source, cb, params, page)
    local account = getLoggedInAccount(source)
    if not account then
        return cb({})
    end
    
    local query, perPage
    
    if params.full then
        perPage = 5
        if params.type == "recent" then
            if params.id then
                if params.username then
                    query = VIDEO_BASE_QUERY .. string.format([[
                        WHERE v.username = @username AND v.`timestamp` %s (SELECT `timestamp` FROM phone_tiktok_videos WHERE id = @id)
                        ORDER BY (w.username IS NOT NULL), v.timestamp DESC
                        LIMIT @page, @perPage
                    ]], params.backwards and ">" or "<")
                else
                    query = VIDEO_BASE_QUERY .. string.format([[
                        WHERE v.username != @loggedIn AND v.`timestamp` %s (SELECT `timestamp` FROM phone_tiktok_videos WHERE id = @id)
                        ORDER BY (w.username IS NOT NULL), v.timestamp DESC
                        LIMIT @page, @perPage
                    ]], params.backwards and ">" or "<")
                end
            else
                query = VIDEO_BASE_QUERY .. [[
                    WHERE v.username != @loggedIn
                    ORDER BY (w.username IS NOT NULL), v.timestamp DESC
                    LIMIT @page, @perPage
                ]]
            end
        elseif params.type == "following" then
            query = VIDEO_BASE_QUERY .. [[
                INNER JOIN phone_tiktok_follows f ON f.followed = v.username
                WHERE f.follower = @loggedIn
                ORDER BY (w.username IS NOT NULL), v.timestamp DESC
                LIMIT @page, @perPage
            ]]
        end
    else
        perPage = 15
        if params.type == "recent" and params.username then
            if page == 0 then
                query = [[
                    SELECT
                        v.id, v.src, v.views,
                        p.video_id IS NOT NULL AS pinned
                    FROM phone_tiktok_videos v
                    LEFT JOIN phone_tiktok_pinned_videos p ON p.video_id = v.id AND p.username = @username
                    WHERE v.username = @username
                    ORDER BY (p.video_id IS NOT NULL) DESC, v.`timestamp` DESC
                    LIMIT @page, @perPage
                ]]
            else
                query = [[
                    SELECT id, src, views
                    FROM phone_tiktok_videos
                    WHERE username = @username
                    ORDER BY `timestamp` DESC
                    LIMIT @page, @perPage
                ]]
            end
        elseif params.type == "liked" then
            query = [[
                SELECT v.id, v.src, v.views
                FROM phone_tiktok_videos v
                INNER JOIN phone_tiktok_likes l ON l.video_id = v.id
                WHERE l.username = @username
                ORDER BY v.`timestamp` DESC
                LIMIT @page, @perPage
            ]]
        elseif params.type == "saved" then
            if params.username ~= account then
                debugprint("wrong account", account, #account, params.username, #params.username)
                return cb({})
            end
            query = [[
                SELECT v.id, v.src, v.views
                FROM phone_tiktok_videos v
                INNER JOIN phone_tiktok_saves s ON s.video_id = v.id
                WHERE s.username = @username
                ORDER BY v.`timestamp` DESC
                LIMIT @page, @perPage
            ]]
        end
    end
    
    if not query then
        return cb({})
    end
    
    MySQL.Async.fetchAll(query, {
        ["@username"] = params.username,
        ["@loggedIn"] = account,
        ["@id"] = params.id,
        ["@page"] = (page or 0) * perPage,
        ["@perPage"] = perPage
    }, cb)
end)

-- Set Video as Viewed
RegisterNetEvent("phone:tiktok:setViewed", function(videoId)
    local account = getLoggedInAccount(source)
    if not account then
        return
    end
    
    MySQL.Async.execute(
        "INSERT IGNORE INTO phone_tiktok_views (username, video_id) VALUES (@username, @videoId)",
        {
            ["@username"] = account,
            ["@videoId"] = videoId
        }
    )
end)

-- Toggle Video Action (Like/Save)
RegisterLegacyCallback("tiktok:toggleVideoAction", function(source, cb, action, videoId, enable)
    if action ~= "like" and action ~= "save" then
        return cb({success = false, error = "invalid_action"})
    end
    
    local account = getLoggedInAccount(source)
    if not account then
        return cb({success = false, error = "not_logged_in"})
    end
    
    local videoOwner = MySQL.Sync.fetchScalar(
        "SELECT username FROM phone_tiktok_videos WHERE id = @id",
        {["@id"] = videoId}
    )
    
    if not videoOwner then
        return cb({success = false, error = "invalid_id"})
    end
    
    cb({success = true})
    
    local table = action == "like" and "likes" or "saves"
    local query = enable == true and
        string.format("INSERT IGNORE INTO phone_tiktok_%s (username, video_id) VALUES (@username, @videoId)", table) or
        string.format("DELETE FROM phone_tiktok_%s WHERE username = @username AND video_id = @videoId", table)
    
    MySQL.Async.execute(query, {
        ["@username"] = account,
        ["@videoId"] = videoId
    }, function(affectedRows)
        if affectedRows == 0 then
            return
        end
        
        TriggerClientEvent("phone:tiktok:updateVideoStats", -1, action, videoId, enable == true and "add" or "remove")
        
        if enable then
            sendTikTokNotification(videoOwner, account, action, videoId)
        end
    end)
end)

-- Post Comment
RegisterLegacyCallback("tiktok:postComment", function(source, cb, videoId, replyTo, comment)
    local account = getLoggedInAccount(source)
    if not account then
        return cb({success = false, error = "not_logged_in"})
    end
    
    if not comment or #comment == 0 or #comment > 500 then
        return cb({success = false, error = "invalid_comment"})
    end
    
    if ContainsBlacklistedWord(source, "Trendy", comment) then
        return cb(false)
    end
    
    -- Verify video exists
    local videoOwner = MySQL.Sync.fetchScalar(
        "SELECT username FROM phone_tiktok_videos WHERE id = @id",
        {["@id"] = videoId}
    )
    
    if not videoOwner then
        return cb({success = false, error = "invalid_id"})
    end
    
    -- Verify reply target exists if replying
    local replyOwner
    if replyTo then
        replyOwner = MySQL.Sync.fetchScalar(
            "SELECT username FROM phone_tiktok_comments WHERE id = @id",
            {["@id"] = replyTo}
        )
        
        if not replyOwner then
            return cb({success = false, error = "invalid_reply_to"})
        end
    end
    
    local commentId = GenerateId("phone_tiktok_comments", "id")
    
    MySQL.Async.execute(
        "INSERT INTO phone_tiktok_comments (id, reply_to, video_id, username, comment) VALUES (@id, @replyTo, @videoId, @loggedIn, @comment)",
        {
            ["@id"] = commentId,
            ["@replyTo"] = replyTo,
            ["@videoId"] = videoId,
            ["@loggedIn"] = account,
            ["@comment"] = comment
        },
        function(affectedRows)
            if affectedRows == 0 then
                return cb({success = false, error = "failed_insert"})
            end
            
            TriggerClientEvent("phone:tiktok:updateVideoStats", -1, "comment", videoId, "add")
            
            if replyTo then
                MySQL.Async.execute(
                    "UPDATE phone_tiktok_comments SET replies = replies + 1 WHERE id = @id",
                    {["@id"] = replyTo}
                )
                TriggerClientEvent("phone:tiktok:updateCommentStats", -1, "reply", replyTo, "add")
                sendTikTokNotification(replyOwner, account, "reply", videoId, commentId)
            end
            
            cb({success = true, id = commentId})
            sendTikTokNotification(videoOwner, account, "comment", videoId, commentId)
        end
    )
end)

-- Delete Comment
RegisterLegacyCallback("tiktok:deleteComment", function(source, cb, commentId, videoId)
    local account = getLoggedInAccount(source)
    if not account then
        return cb({success = false, error = "not_logged_in"})
    end
    
    local whereClause = ""
    if not IsAdmin(source) then
        whereClause = " AND username = @username"
    end
    
    -- Check if comment is a reply
    local replyTo = MySQL.Sync.fetchScalar(
        "SELECT reply_to FROM phone_tiktok_comments WHERE id = @id" .. whereClause,
        {
            ["@id"] = commentId,
            ["@username"] = account
        }
    )
    
    local replyCount = 0
    if replyTo then
        -- Update parent comment reply count
        MySQL.Async.execute(
            "UPDATE phone_tiktok_comments SET replies = replies - 1 WHERE id = @id",
            {["@id"] = replyTo}
        )
        TriggerClientEvent("phone:tiktok:updateCommentStats", -1, "reply", replyTo, "remove")
    else
        -- Count replies to this comment
        replyCount = MySQL.Sync.fetchScalar(
            "SELECT COUNT(*) FROM phone_tiktok_comments WHERE reply_to = @id",
            {["@id"] = commentId}
        )
    end
    
    -- Delete the comment
    MySQL.Async.execute(
        "DELETE FROM phone_tiktok_comments WHERE id = @id" .. whereClause,
        {
            ["@id"] = commentId,
            ["@username"] = account
        },
        function(affectedRows)
            if affectedRows > 0 then
                cb({success = true})
                TriggerClientEvent("phone:tiktok:updateVideoStats", -1, "comment", videoId, "remove", replyCount + 1)
            else
                cb({success = false, error = "failed_delete"})
            end
        end
    )
end)

-- Set Pinned Comment
RegisterLegacyCallback("tiktok:setPinnedComment", function(source, cb, commentId, videoId)
    local account = getLoggedInAccount(source)
    if not account then
        return cb({success = false, error = "not_logged_in"})
    end
    
    -- Verify video ownership
    local ownsVideo = MySQL.Sync.fetchScalar(
        "SELECT TRUE FROM phone_tiktok_videos WHERE id = @id AND username = @username",
        {
            ["@id"] = videoId,
            ["@username"] = account
        }
    )
    
    if not ownsVideo then
        return cb({success = false, error = "invalid_id"})
    end
    
    -- Verify comment exists and belongs to user
    if commentId ~= nil then
        local ownsComment = MySQL.Sync.fetchScalar(
            "SELECT TRUE FROM phone_tiktok_comments WHERE id = @id AND username = @username",
            {
                ["@id"] = commentId,
                ["@username"] = account
            }
        )
        
        if not ownsComment then
            return cb({success = false, error = "invalid_comment"})
        end
    end
    
    MySQL.Async.execute(
        "UPDATE phone_tiktok_videos SET pinned_comment = @commentId WHERE id = @id",
        {
            ["@commentId"] = commentId,
            ["@id"] = videoId
        },
        function(affectedRows)
            if affectedRows > 0 then
                cb({success = true})
            else
                cb({success = false, error = "failed_update"})
            end
        end
    )
end)

-- Get Comments
RegisterLegacyCallback("tiktok:getComments", function(source, cb, videoId, replyTo, creator, page)
    local account = getLoggedInAccount(source)
    if not account then
        return cb({success = false, error = "not_logged_in"})
    end
    
    local query = [[
        SELECT
            a.username, a.`name`, a.avatar, a.verified,
            c.id, c.comment, c.likes, c.replies AS reply_count, c.`timestamp`,
            (SELECT TRUE FROM phone_tiktok_comments_likes WHERE username = @loggedIn AND comment_id = c.id) AS liked,
            (SELECT TRUE FROM phone_tiktok_comments_likes WHERE username = @creator AND comment_id = c.id) AS creator_liked
        FROM phone_tiktok_comments c
        INNER JOIN phone_tiktok_accounts a ON a.username = c.username
        WHERE c.video_id = @videoId
    ]]
    
    if replyTo then
        query = query .. " AND c.reply_to = @replyTo"
    else
        query = query .. " AND c.reply_to IS NULL"
    end
    
    query = query .. " ORDER BY c.`timestamp` DESC LIMIT @page, @perPage"
    
    MySQL.Async.fetchAll(query, {
        ["@loggedIn"] = account,
        ["@creator"] = creator,
        ["@videoId"] = videoId,
        ["@replyTo"] = replyTo,
        ["@page"] = (page or 0) * 15,
        ["@perPage"] = 15
    }, function(comments)
        cb({success = true, comments = comments})
    end)
end)

-- Toggle Like Comment
RegisterLegacyCallback("tiktok:toggleLikeComment", function(source, cb, commentId, shouldLike)
    local account = getLoggedInAccount(source)
    if not account then
        return cb({success = false, error = "not_logged_in"})
    end
    
    if not commentId or shouldLike == nil then
        return cb({success = false, error = "invalid_data"})
    end
    
    -- Get comment info
    local commentInfo = MySQL.Sync.fetchAll(
        "SELECT username, video_id FROM phone_tiktok_comments WHERE id = @id",
        {["@id"] = commentId}
    )[1]
    
    if not commentInfo then
        return cb({success = false, error = "invalid_id"})
    end
    
    local query = shouldLike == true and
        "INSERT IGNORE INTO phone_tiktok_comments_likes (username, comment_id) VALUES (@username, @commentId)" or
        "DELETE FROM phone_tiktok_comments_likes WHERE username = @username AND comment_id = @commentId"
    
    MySQL.Async.execute(query, {
        ["@username"] = account,
        ["@commentId"] = commentId
    }, function(affectedRows)
        cb({success = true})
        
        if affectedRows == 0 then
            debugprint("Failed to toggle like comment, no rows changed")
            return
        end
        
        TriggerClientEvent("phone:tiktok:updateCommentStats", -1, "like", commentId, shouldLike == true and "add" or "remove")
        
        if shouldLike then
            sendTikTokNotification(commentInfo.username, account, "like_comment", commentInfo.video_id, commentId)
        end
    end)
end)

-- Get Recent Messages
RegisterLegacyCallback("tiktok:getRecentMessages", function(source, cb)
    local account = getLoggedInAccount(source)
    if not account then
        return cb({success = false, error = "not_logged_in"})
    end
    
    MySQL.Async.fetchAll([[
        SELECT
            id, last_message, `timestamp`,
            a.username, a.`name`, a.avatar, a.verified, a.follower_count, a.following_count,
            (SELECT COALESCE(amount, 0) FROM phone_tiktok_unread_messages WHERE channel_id = id AND username = @loggedIn) AS unread_messages
        FROM phone_tiktok_channels
        INNER JOIN phone_tiktok_accounts a ON a.username = IF(member_1 = @loggedIn, member_2, member_1)
        WHERE member_1 = @loggedIn OR member_2 = @loggedIn 
        ORDER BY `timestamp` DESC
    ]], {
        ["@loggedIn"] = account
    }, function(channels)
        cb({success = true, channels = channels})
    end)
end)

-- Get Messages
RegisterLegacyCallback("tiktok:getMessages", function(source, cb, channelId, page)
    local account = getLoggedInAccount(source)
    if not account then
        return cb({success = false, error = "not_logged_in"})
    end
    
    -- Verify user has access to channel
    local hasAccess = MySQL.Sync.fetchScalar(
        "SELECT TRUE FROM phone_tiktok_channels WHERE id = @id AND (member_1 = @loggedIn OR member_2 = @loggedIn)",
        {
            ["@id"] = channelId,
            ["@loggedIn"] = account
        }
    )
    
    if not hasAccess then
        return cb({success = false, error = "invalid_id"})
    end
    
    MySQL.Async.fetchAll(
        "SELECT id, sender, content, `timestamp` FROM phone_tiktok_messages WHERE channel_id = @channelId ORDER BY `timestamp` DESC LIMIT @page, @perPage",
        {
            ["@channelId"] = channelId,
            ["@page"] = (page or 0) * 25,
            ["@perPage"] = 25
        },
        function(messages)
            cb({success = true, messages = messages})
        end
    )
end)

-- Get Unread Messages
RegisterLegacyCallback("tiktok:getUnreadMessages", function(source, cb)
    local account = getLoggedInAccount(source)
    if not account then
        return cb({success = false, error = "not_logged_in"})
    end
    
    MySQL.Async.fetchScalar(
        "SELECT COUNT(*) FROM phone_tiktok_unread_messages WHERE username = @username AND amount > 0",
        {["@username"] = account},
        function(unreadCount)
            cb({success = true, unread = unreadCount})
        end
    )
end)

-- Clear Unread Messages
RegisterNetEvent("phone:tiktok:clearUnreadMessages", function(channelId)
    local account = getLoggedInAccount(source)
    if not account then
        return
    end
    
    MySQL.Async.execute(
        "UPDATE phone_tiktok_unread_messages SET amount = 0 WHERE username = @username AND channel_id = @channelId",
        {
            ["@username"] = account,
            ["@channelId"] = channelId
        }
    )
end)

-- Send Message
RegisterLegacyCallback("tiktok:sendMessage", function(source, cb, messageData)
    local account = getLoggedInAccount(source)
    if not account then
        return cb({success = false, error = "not_logged_in"})
    end
    
    if ContainsBlacklistedWord(source, "Trendy", messageData.content) then
        return cb(false)
    end
    
    local channelId = messageData.id
    local content = messageData.content
    local recipient = messageData.username
    
    -- Create or find channel
    if not channelId then
        if not recipient then
            return cb({success = false, error = "invalid_id"})
        end
        
        -- Check if channel already exists
        channelId = MySQL.Sync.fetchScalar(
            "SELECT id FROM phone_tiktok_channels WHERE (member_1 = @loggedIn AND member_2 = @username) OR (member_1 = @username AND member_2 = @loggedIn)",
            {
                ["@loggedIn"] = account,
                ["@username"] = recipient
            }
        )
        
        -- Create new channel if doesn't exist
        if not channelId then
            channelId = GenerateId("phone_tiktok_channels", "id")
            local created = MySQL.Sync.execute(
                "INSERT IGNORE INTO phone_tiktok_channels (id, last_message, member_1, member_2) VALUES (@id, @message, @member_1, @member_2)",
                {
                    ["@id"] = channelId,
                    ["@message"] = content,
                    ["@member_1"] = account,
                    ["@member_2"] = recipient
                }
            ) > 0
            
            if not created then
                return cb({success = false, error = "failed_create_channel"})
            end
        end
    end
    
    local messageId = GenerateId("phone_tiktok_messages", "id")
    
    MySQL.Async.execute(
        "INSERT INTO phone_tiktok_messages (id, channel_id, sender, content) VALUES (@messageId, @channelId, @sender, @content)",
        {
            ["@messageId"] = messageId,
            ["@channelId"] = channelId,
            ["@sender"] = account,
            ["@content"] = content
        },
        function(affectedRows)
            cb({
                success = affectedRows > 0,
                id = messageId,
                channelId = channelId,
                error = "failed_insert"
            })
            
            if affectedRows > 0 then
                -- Update unread messages
                MySQL.Async.execute([[
                    INSERT INTO phone_tiktok_unread_messages
                        (username, channel_id, amount)
                    VALUES
                        (@username, @channelId, 1)
                    ON DUPLICATE KEY UPDATE
                        amount = amount + 1
                ]], {
                    ["@username"] = recipient,
                    ["@channelId"] = channelId
                })
                
                -- Send real-time message to recipient
                local activeAccounts = GetActiveAccounts("TikTok")
                for phoneNumber, username in pairs(activeAccounts) do
                    if username == recipient then
                        local targetSource = GetSourceFromNumber(phoneNumber)
                        if targetSource then
                            TriggerClientEvent("phone:tiktok:receivedMessage", targetSource, {
                                id = messageId,
                                channelId = channelId,
                                sender = account,
                                content = content
                            })
                        end
                    end
                end
                
                sendTikTokNotification(recipient, account, "message", nil, nil, {content = content})
            end
        end
    )
end)

-- Get Channel ID
RegisterLegacyCallback("tiktok:getChannelId", function(source, cb, username)
    local account = getLoggedInAccount(source)
    if not account then
        return cb({success = false, error = "not_logged_in"})
    end
    
    local channelId = MySQL.Sync.fetchScalar(
        "SELECT id FROM phone_tiktok_channels WHERE (member_1 = @loggedIn AND member_2 = @username) OR (member_1 = @username AND member_2 = @loggedIn)",
        {
            ["@loggedIn"] = account,
            ["@username"] = username
        }
    )
    
    if not channelId then
        return cb({success = false, error = "no_channel"})
    end
    
    cb({success = true, id = channelId})
end)