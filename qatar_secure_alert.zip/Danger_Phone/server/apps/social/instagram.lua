-- Live streams storage
local activeLiveStreams = {}

-- Call ID storage for live streams
local liveStreamCallIds = {}

-- Helper function to get logged in Instagram account
local function GetLoggedInInstagramAccount(source)
    local phoneNumber = GetEquippedPhoneNumber(source)
    if not phoneNumber then
        return false
    end
    
    return GetLoggedInAccount(phoneNumber, "Instagram")
end

-- Get all phone numbers logged into a specific Instagram account
local function GetPhoneNumbersForInstagramAccount(username)
    local phoneNumbers = {}
    local results = MySQL.query.await(
        "SELECT phone_number FROM phone_logged_in_accounts WHERE app = 'Instagram' AND `active` = 1 AND username = ?",
        {username}
    )
    
    for i = 1, #results do
        phoneNumbers[i] = results[i].phone_number
    end
    
    return phoneNumbers
end

-- Create Instagram callback wrapper
local function CreateInstagramCallback(callbackName, handler, defaultReturn)
    BaseCallback("instagram:" .. callbackName, function(source, phoneNumber, ...)
        local username = GetLoggedInAccount(phoneNumber, "Instagram")
        if not username then
            return defaultReturn
        end
        
        return handler(source, phoneNumber, username, ...)
    end, defaultReturn)
end

-- Send notification to all devices logged into an Instagram account
local function NotifyAllDevices(instagramUsername, notificationData, excludePhoneNumber)
    local phoneNumbers = GetPhoneNumbersForInstagramAccount(instagramUsername)
    notificationData.app = "Instagram"
    
    for i = 1, #phoneNumbers do
        local phoneNumber = phoneNumbers[i]
        if phoneNumber ~= excludePhoneNumber then
            SendNotification(phoneNumber, notificationData)
        end
    end
end

-- Get live streams callback
RegisterLegacyCallback("instagram:getLives", function(source, cb)
    local username = GetLoggedInInstagramAccount(source)
    if not username then
        return cb({})
    end
    
    local visibleLives = {}
    
    for liveUsername, liveData in pairs(activeLiveStreams) do
        if liveData.private then
            -- Check if user follows private account
            local follows = MySQL.Sync.fetchScalar(
                "SELECT TRUE FROM phone_instagram_follows WHERE follower=@follower AND followed=@followed",
                {["@follower"] = username, ["@followed"] = liveUsername}
            )
            if follows then
                visibleLives[liveUsername] = liveData
            end
        else
            visibleLives[liveUsername] = liveData
        end
    end
    
    cb(visibleLives)
end)

-- Get live stream viewers
RegisterLegacyCallback("instagram:getLiveViewers", function(source, cb, liveUsername)
    local liveData = activeLiveStreams[liveUsername]
    if not liveData then
        return cb({})
    end
    
    local viewers = liveData.viewers
    local viewerDetails = {}
    
    for i = 1, #viewers do
        local viewerSource = viewers[i]
        local phoneNumber = GetEquippedPhoneNumber(viewerSource)
        
        if phoneNumber then
            local accountData = MySQL.Sync.fetchAll([[
                SELECT
                    a.profile_image AS avatar, a.verified, a.display_name AS `name`, a.username
                FROM phone_logged_in_accounts l
                INNER JOIN phone_instagram_accounts a ON l.username = a.username
                WHERE l.phone_number = ? AND l.active = 1 AND l.app = 'Instagram'
            ]], {phoneNumber})
            
            if accountData and accountData[1] then
                viewerDetails[#viewerDetails + 1] = accountData[1]
            end
        end
    end
    
    cb(viewerDetails)
end)

-- Check if user can go live
RegisterLegacyCallback("instagram:canGoLive", function(source, cb)
    local username = GetLoggedInInstagramAccount(source)
    if not username then
        return cb(false)
    end
    
    local canGoLive, reason = CanGoLive(source, username)
    if not canGoLive then
        local phoneNumber = GetEquippedPhoneNumber(source)
        if phoneNumber then
            SendNotification(phoneNumber, {
                app = "Instagram",
                title = reason or L("BACKEND.INSTAGRAM.NOT_ALLOWED_LIVE")
            })
        end
    end
    
    cb(canGoLive)
end)

-- Check if user can create story
RegisterLegacyCallback("instagram:canCreateStory", function(source, cb)
    local username = GetLoggedInInstagramAccount(source)
    if not username then
        return cb(false)
    end
    
    local canCreate, reason = CanCreateStory(source, username)
    if not canCreate then
        local phoneNumber = GetEquippedPhoneNumber(source)
        if phoneNumber then
            SendNotification(phoneNumber, {
                app = "Instagram",
                title = reason or L("BACKEND.INSTAGRAM.NOT_ALLOWED_STORY")
            })
        end
    end
    
    cb(canCreate)
end)

-- Start live stream
RegisterNetEvent("phone:instagram:startLive", function(liveId)
    local source = source
    local username = GetLoggedInInstagramAccount(source)
    
    if not username or activeLiveStreams[username] or not CanGoLive(source, username) then
        return
    end
    
    -- Get account data
    local accountData = MySQL.single.await(
        "SELECT profile_image, verified, display_name, private FROM phone_instagram_accounts WHERE username = ?",
        {username}
    )
    
    if not accountData then
        return
    end
    
    -- Create live stream data
    activeLiveStreams[username] = {
        id = liveId,
        avatar = accountData.profile_image,
        verified = accountData.verified,
        name = accountData.display_name,
        private = accountData.private,
        host = source,
        viewers = {},
        nearby = {},
        invites = {},
        participants = {}
    }
    
    -- Set player state
    Player(source).state.instapicIsLive = username
    
    -- Update all clients
    TriggerClientEvent("phone:instagram:updateLives", -1, activeLiveStreams)
    
    -- Log the event
    Log("InstaPic", source, "success", L("BACKEND.LOGS.LIVE_TITLE"), L("BACKEND.LOGS.STARTED_LIVE", {username = username}))
    TrackSimpleEvent("go_live")
    
    -- Send notifications
    local notificationData = {
        title = L("APPS.INSTAGRAM.TITLE"),
        content = L("BACKEND.INSTAGRAM.STARTED_LIVE", {username = username})
    }
    
    if Config.InstaPicLiveNotifications then
        local notifyMode = Config.InstaPicLiveNotifications == "all" and "all" or "online"
        NotifyEveryone(notifyMode, {
            app = "Instagram",
            title = notificationData.title,
            content = notificationData.content
        })
    else
        -- Notify followers
        local followers = MySQL.query.await(
            "SELECT follower FROM phone_instagram_follows WHERE followed = ?",
            {username}
        )
        
        for i = 1, #followers do
            NotifyAllDevices(followers[i].follower, notificationData)
        end
    end
end)

-- End live stream (internal function)
local function EndLiveStream(liveData)
    if not liveData.participants then
        return
    end
    
    local allViewers = table.clone(liveData.viewers)
    allViewers[#allViewers + 1] = liveData.host
    
    -- Handle participants
    for i = 1, #liveData.participants do
        local participant = liveData.participants[i]
        if participant and participant.username then
            local participantLive = activeLiveStreams[participant.username]
            if participantLive then
                TriggerClientEvent("phone:phone:removeVoiceTarget", participantLive.host, allViewers)
                Player(participantLive.host).state.instapicIsLive = nil
                activeLiveStreams[participant.username] = nil
                TriggerClientEvent("phone:instagram:endLive", -1, participant.username)
            end
        end
    end
    
    -- Handle nearby viewers
    for i = 1, #liveData.nearby do
        local nearbySource = liveData.nearby[i]
        if nearbySource then
            TriggerClientEvent("phone:phone:removeVoiceTarget", nearbySource, allViewers)
            TriggerClientEvent("phone:instagram:leftProximity", -1, nearbySource, liveData.host)
        end
    end
    
    -- Remove voice targets for host
    TriggerClientEvent("phone:phone:removeVoiceTarget", liveData.host, liveData.viewers)
end

-- Remove participant from live stream
local function RemoveParticipantFromLive(hostUsername, participantUsername)
    local liveData = activeLiveStreams[hostUsername]
    local participantSource = nil
    
    if not liveData.participants then
        return
    end
    
    local removed = false
    for i = 1, #liveData.participants do
        local participant = liveData.participants[i]
        if participant.username == participantUsername then
            participantSource = participant.source
            table.remove(liveData.participants, i)
            removed = true
            break
        end
    end
    
    if not removed then
        return
    end
    
    -- Notify all viewers and host
    local allViewers = table.clone(liveData.viewers)
    allViewers[#allViewers + 1] = liveData.host
    
    for i = 1, #allViewers do
        TriggerClientEvent("phone:instagram:leftLive", allViewers[i], hostUsername, participantUsername, participantSource)
    end
    
    -- Remove voice targets
    local remainingViewers = table.clone(liveData.viewers)
    for i = 1, #liveData.participants do
        for j = 1, #remainingViewers do
            if remainingViewers[j] == liveData.participants[i].source then
                table.remove(remainingViewers, j)
                break
            end
        end
    end
    
    TriggerClientEvent("phone:phone:removeVoiceTarget", participantSource, remainingViewers)
end

-- End live stream callback
RegisterLegacyCallback("instagram:endLive", function(source, cb)
    local username = GetLoggedInInstagramAccount(source)
    if not username then
        return cb(true)
    end
    
    local liveData = activeLiveStreams[username]
    if not liveData then
        return cb(true)
    end
    
    -- Handle participant vs host
    local participantUsername = liveData.participant
    if participantUsername then
        RemoveParticipantFromLive(participantUsername, username)
    else
        EndLiveStream(liveData)
    end
    
    activeLiveStreams[username] = nil
    Player(source).state.instapicIsLive = nil
    
    TriggerClientEvent("phone:instagram:updateLives", -1, activeLiveStreams)
    TriggerClientEvent("phone:instagram:endLive", -1, username, participantUsername)
    
    Log("InstaPic", source, "error", L("BACKEND.LOGS.LIVE_TITLE"), L("BACKEND.LOGS.ENDED_LIVE", {username = username}))
    
    cb(true)
end)

-- Handle player disconnect
AddEventHandler("playerDropped", function()
    local source = source
    
    -- Check all live streams
    for username, liveData in pairs(activeLiveStreams) do
        -- Remove from viewers
        for i, viewerSource in pairs(liveData.viewers) do
            if viewerSource == source then
                -- End call if in voice chat
                if liveStreamCallIds[source] then
                    TriggerClientEvent("phone:endCall", liveData.host, liveStreamCallIds[source])
                    liveStreamCallIds[source] = nil
                end
                
                table.remove(liveData.viewers, i)
                TriggerClientEvent("phone:instagram:updateViewers", -1, username, #liveData.viewers)
            end
        end
        
        -- Check if host disconnected
        if liveData.host == source then
            local participantUsername = liveData.participant
            if participantUsername then
                RemoveParticipantFromLive(participantUsername, username)
            else
                EndLiveStream(liveData)
            end
            
            activeLiveStreams[username] = nil
            TriggerClientEvent("phone:instagram:updateLives", -1, activeLiveStreams)
            TriggerClientEvent("phone:instagram:endLive", -1, username, participantUsername)
            
            if liveData.host == source then
                return
            end
        end
    end
end)

-- Add call to live stream
RegisterNetEvent("phone:instagram:addCall", function(callId)
    local source = source
    local isViewer = false
    
    -- Check if source is viewing any live
    for _, liveData in pairs(activeLiveStreams) do
        for _, viewerSource in pairs(liveData.viewers) do
            if viewerSource == source then
                isViewer = true
                break
            end
        end
    end
    
    if not liveStreamCallIds[source] and isViewer then
        liveStreamCallIds[source] = callId
    end
end)

-- View live stream
RegisterLegacyCallback("instagram:viewLive", function(source, cb, liveUsername)
    local liveData = activeLiveStreams[liveUsername]
    if not liveData then
        return cb(false)
    end
    
    -- Check if already viewing
    local alreadyViewing = false
    for i = 1, #liveData.viewers do
        if liveData.viewers[i] == source then
            alreadyViewing = true
            break
        end
    end
    
    if not alreadyViewing then
        -- Add to viewers
        liveData.viewers[#liveData.viewers + 1] = source
        
        -- Add voice target for host
        TriggerClientEvent("phone:phone:addVoiceTarget", liveData.host, source)
        
        -- Update viewer count
        TriggerClientEvent("phone:instagram:updateViewers", -1, liveUsername, #liveData.viewers)
        
        -- Add voice targets for participants
        local participants = liveData.participants
        for i = 1, #participants do
            TriggerClientEvent("phone:phone:addVoiceTarget", participants[i].source, source)
        end
        
        -- Handle nearby after delay
        SetTimeout(500, function()
            local nearby = liveData?.nearby or {}
            for i = 1, #nearby do
                TriggerClientEvent("phone:phone:addVoiceTarget", nearby[i], source)
                TriggerClientEvent("phone:instagram:enteredProximity", source, nearby[i], liveData.host)
            end
        end)
    end
    
    cb(liveData)
end)

-- Stop viewing live stream
RegisterLegacyCallback("instagram:stopViewing", function(source, cb, liveUsername)
    local liveData = activeLiveStreams[liveUsername]
    if not liveData then
        return cb()
    end
    
    local wasViewing = false
    for i, viewerSource in pairs(liveData.viewers) do
        if viewerSource == source then
            wasViewing = true
            
            -- End call if in voice chat
            if liveStreamCallIds[source] then
                TriggerClientEvent("phone:instagram:endCall", liveData.host, liveStreamCallIds[source])
                liveStreamCallIds[source] = nil
            end
            
            table.remove(liveData.viewers, i)
            break
        end
    end
    
    -- Remove voice targets for nearby
    for i = 1, #liveData.nearby do
        local nearbySource = liveData.nearby[i]
        if nearbySource then
            TriggerClientEvent("phone:phone:removeVoiceTarget", nearbySource, source)
            TriggerClientEvent("phone:instagram:leftProximity", source, nearbySource, liveData.host)
        end
    end
    
    if wasViewing then
        -- Remove voice target from host
        TriggerClientEvent("phone:phone:removeVoiceTarget", liveData.host, source)
        
        -- Update viewer count
        TriggerClientEvent("phone:instagram:updateViewers", -1, liveUsername, #liveData.viewers)
        
        -- Remove voice targets from participants
        local participants = liveData.participants
        for i = 1, #participants do
            TriggerClientEvent("phone:phone:removeVoiceTarget", participants[i].source, source)
        end
    end
    
    cb()
end)

-- Invite to live stream
RegisterNetEvent("phone:instagram:inviteLive", function(inviteeUsername)
    local hostUsername = GetLoggedInInstagramAccount(source)
    if not hostUsername then
        return
    end
    
    local liveData = activeLiveStreams[hostUsername]
    if not liveData or not liveData.participants then
        return
    end
    
    -- Check if already has participant
    if activeLiveStreams[inviteeUsername] then
        return
    end
    
    -- Max 3 participants
    if #liveData.participants >= 3 then
        return
    end
    
    -- Check if already participant
    for i = 1, #liveData.participants do
        local participant = liveData.participants[i]
        if participant?.username == inviteeUsername then
            return
        end
    end
    
    -- Add to invites
    if not liveData.invites[inviteeUsername] then
        liveData.invites[inviteeUsername] = true
    end
    
    -- Notify all devices logged into invitee account
    local activeAccounts = GetActiveAccounts("Instagram")
    for phoneNumber, username in pairs(activeAccounts) do
        if inviteeUsername == username then
            local inviteeSource = GetSourceFromNumber(phoneNumber)
            if inviteeSource then
                TriggerClientEvent("phone:instagram:invitedLive", inviteeSource, hostUsername)
            end
        end
    end
end)

-- Remove from live stream
RegisterNetEvent("phone:instagram:removeLive", function(participantUsername)
    local hostUsername = GetLoggedInInstagramAccount(source)
    if not hostUsername then
        return
    end
    
    local liveData = activeLiveStreams[hostUsername]
    if not liveData then
        return
    end
    
    local found = false
    local participantSource = nil
    
    -- Find participant
    for i = 1, #liveData.participants do
        local participant = liveData.participants[i]
        if participant.username == participantUsername then
            found = true
            participantSource = participant.source
            break
        end
    end
    
    if found and participantSource then
        RemoveParticipantFromLive(hostUsername, participantUsername)
        
        activeLiveStreams[participantUsername] = nil
        Player(participantSource).state.instapicIsLive = nil
        
        TriggerClientEvent("phone:instagram:updateLives", -1, activeLiveStreams)
        TriggerClientEvent("phone:instagram:endLive", -1, participantUsername, hostUsername)
        TriggerClientEvent("phone:instagram:removedLive", participantSource)
    end
    
    TriggerClientEvent("phone:instagram:updateLives", -1, activeLiveStreams)
end)

-- Join live stream as participant
RegisterLegacyCallback("instagram:joinLive", function(source, cb, hostUsername, participantId)
    local participantUsername = GetLoggedInInstagramAccount(source)
    if not participantUsername then
        return cb(false)
    end
    
    local hostLive = activeLiveStreams[hostUsername]
    if not hostLive or not hostLive.participants then
        return cb(false)
    end
    
    -- Check if already live
    if activeLiveStreams[participantUsername] then
        return cb(false)
    end
    
    -- Remove invite
    if hostLive.invites[participantUsername] then
        hostLive.invites[participantUsername] = nil
    end
    
    -- Check participant limit
    if #hostLive.participants >= 3 then
        return cb(false)
    end
    
    -- Check if already participant
    for i = 1, #hostLive.participants do
        local participant = hostLive.participants[i]
        if participant?.username == participantUsername then
            return cb(false)
        end
    end
    
    -- Get participant account data
    local accountData = MySQL.Sync.fetchAll(
        "SELECT profile_image, verified, display_name FROM phone_instagram_accounts WHERE username=@username",
        {["@username"] = participantUsername}
    )
    
    if not accountData or not accountData[1] then
        return cb(false)
    end
    
    -- Add participant
    hostLive.participants[#hostLive.participants + 1] = {
        username = participantUsername,
        name = accountData[1].display_name,
        avatar = accountData[1].profile_image,
        verified = accountData[1].verified,
        id = participantId,
        source = source
    }
    
    -- Create participant live data
    activeLiveStreams[participantUsername] = {
        id = participantId,
        avatar = accountData[1].profile_image,
        verified = accountData[1].verified,
        name = accountData[1].display_name,
        host = source,
        nearby = {},
        viewers = {},
        participant = hostUsername
    }
    
    Player(source).state.instapicIsLive = participantUsername
    
    TriggerClientEvent("phone:instagram:updateLives", -1, activeLiveStreams)
    
    -- Notify followers
    local followers = MySQL.Sync.fetchAll(
        "SELECT follower FROM phone_instagram_follows WHERE followed = @username",
        {["@username"] = participantUsername}
    )
    
    for i = 1, #followers do
        local followerPhoneNumbers = GetPhoneNumbersForInstagramAccount(followers[i].follower)
        for j = 1, #followerPhoneNumbers do
            SendNotification(followerPhoneNumbers[j], {
                app = "Instagram",
                title = L("APPS.INSTAGRAM.TITLE"),
                content = L("BACKEND.INSTAGRAM.JOINED_LIVE", {
                    invitee = participantUsername,
                    inviter = hostUsername
                })
            })
        end
    end
    
    -- Set up voice targets
    local allViewers = table.clone(activeLiveStreams[hostUsername].viewers)
    allViewers[#allViewers + 1] = activeLiveStreams[hostUsername].host
    
    TriggerClientEvent("phone:phone:addVoiceTarget", source, allViewers)
    
    -- Notify all viewers
    for i = 1, #allViewers do
        TriggerClientEvent("phone:instagram:joinedLive", allViewers[i], {
            username = participantUsername,
            name = accountData[1].name,
            avatar = accountData[1].profile_image,
            verified = accountData[1].verified,
            id = participantId,
            host = hostUsername,
            source = source
        })
    end
    
    cb(true)
end)

-- Send live message
RegisterNetEvent("phone:instagram:sendLiveMessage", function(messageData)
    if messageData?.live and activeLiveStreams[messageData.live] then
        TriggerClientEvent("phone:instagram:addLiveMessage", -1, messageData)
    end
end)

-- Handle proximity events for live streams
RegisterNetEvent("phone:instagram:enteredLiveProximity", function(liveUsername)
    local source = source
    local participantLive = activeLiveStreams[liveUsername]?.participant
    local participantData = {}
    
    if participantLive then
        participantData = activeLiveStreams[liveUsername]
        liveUsername = participantLive
    end
    
    local liveData = activeLiveStreams[liveUsername]
    if not liveData then
        return
    end
    
    -- Check if already in nearby list
    if table.contains(liveData.nearby, source) then
        return
    end
    
    -- Check if participant
    for i = 1, #liveData.participants do
        if liveData.participants[i].source == source then
            return
        end
    end
    
    -- Add to nearby
    liveData.nearby[#liveData.nearby + 1] = source
    
    -- Get viewers to hear
    local viewersToHear = table.clone(liveData.viewers)
    if participantLive then
        viewersToHear[#viewersToHear + 1] = liveData.host
    end
    
    debugprint("shouldHear (joined)", json.encode(viewersToHear, {indent = true}))
    
    TriggerClientEvent("phone:phone:addVoiceTarget", source, viewersToHear)
    TriggerClientEvent("phone:instagram:enteredProximity", -1, source, participantData?.host or liveData.host)
end)

RegisterNetEvent("phone:instagram:leftLiveProximity", function(liveUsername, includingHost)
    local source = source
    local participantLive = activeLiveStreams[liveUsername]?.participant
    local participantData = {}
    
    if participantLive then
        participantData = activeLiveStreams[liveUsername]
        liveUsername = participantLive
    end
    
    local liveData = activeLiveStreams[liveUsername]
    if not liveData then
        return
    end
    
    -- Remove from nearby
    for i = 1, #liveData.nearby do
        if liveData.nearby[i] == source then
            activeLiveStreams[liveUsername].nearby[i] = nil
            break
        end
    end
    
    -- Get viewers to stop hearing
    local viewersToRemove = table.clone(liveData.viewers)
    if participantLive or includingHost then
        viewersToRemove[#viewersToRemove + 1] = liveData.host
    end
    
    debugprint("shouldHear (left)", json.encode(viewersToRemove, {indent = true}))
    
    TriggerClientEvent("phone:phone:removeVoiceTarget", source, viewersToRemove)
    TriggerClientEvent("phone:instagram:leftProximity", -1, source, participantData?.host or liveData.host)
end)

-- Story management
RegisterLegacyCallback("instagram:addToStory", function(source, cb, image, metadata)
    local username = GetLoggedInInstagramAccount(source)
    if not username then
        return cb(false)
    end
    
    local storyId = GenerateId("phone_instagram_stories", "id")
    
    MySQL.Async.execute(
        "INSERT INTO phone_instagram_stories (id, username, image, metadata) VALUES (@id, @username, @image, @metadata)",
        {
            ["@id"] = storyId,
            ["@username"] = username,
            ["@image"] = image,
            ["@metadata"] = metadata and json.encode(metadata) or nil
        },
        function(affectedRows)
            cb(affectedRows > 0)
        end
    )
    
    -- Get account data and notify
    MySQL.Async.fetchAll(
        "SELECT profile_image, verified FROM phone_instagram_accounts WHERE username=@username",
        {["@username"] = username},
        function(result)
            TriggerClientEvent("phone:instagram:addStory", -1, {
                username = username,
                avatar = result[1].profile_image,
                verified = result[1].verified,
                seen = false
            })
            
            Log("InstaPic", source, "info", L("BACKEND.LOGS.ADDED_STORY", {username = username}), image)
        end
    )
end)

RegisterLegacyCallback("instagram:removeFromStory", function(source, cb, storyId)
    local username = GetLoggedInInstagramAccount(source)
    if not username then
        return cb(false)
    end
    
    MySQL.Async.execute(
        "DELETE FROM phone_instagram_stories WHERE id=@id AND username=@username",
        {["@id"] = storyId, ["@username"] = username},
        function(affectedRows)
            cb(affectedRows > 0)
        end
    )
end)

RegisterLegacyCallback("instagram:getStories", function(source, cb)
    local loggedInAs = GetLoggedInInstagramAccount(source)
    if not loggedInAs then
        return cb({})
    end
    
    MySQL.Async.fetchAll([[
        SELECT
            s.username, a.verified, a.profile_image AS avatar,

            (SELECT
                (SELECT COUNT(*) FROM phone_instagram_stories s2
                    WHERE s2.username = s.username AND NOT EXISTS (
                    SELECT TRUE FROM phone_instagram_stories_views v
                    WHERE v.viewer = @loggedInAs AND v.story_id = s2.id
                )
            ) = 0) AS seen

        FROM phone_instagram_stories s

        INNER JOIN phone_instagram_accounts a
        ON a.username = s.username

        WHERE a.private=FALSE OR EXISTS (
            SELECT TRUE FROM phone_instagram_follows f
            WHERE f.followed = s.username AND f.follower = @loggedInAs
        )

        GROUP BY s.username

        ORDER BY s.`timestamp` DESC
    ]], {["@loggedInAs"] = loggedInAs}, cb)
end)

RegisterLegacyCallback("instagram:getStory", function(source, cb, storyUsername)
    local loggedInAs = GetLoggedInInstagramAccount(source)
    if not loggedInAs then
        return cb(false)
    end
    
    MySQL.Async.fetchAll([[
        SELECT s.id, s.image, s.metadata, s.`timestamp`,
            (IF((
                SELECT TRUE FROM phone_instagram_stories_views v
                WHERE v.viewer = @loggedInAs AND v.story_id = s.id
            ), TRUE, FALSE)) AS seen

        FROM phone_instagram_stories s

        WHERE s.username = @username

        ORDER BY s.timestamp ASC
    ]], {
        ["@loggedInAs"] = loggedInAs,
        ["@username"] = storyUsername
    }, function(stories)
        if loggedInAs == storyUsername and stories and #stories > 0 then
            -- Add view counts and viewers for own stories
            for i = 1, #stories do
                local story = stories[i]
                
                -- Decode metadata
                story.metadata = story.metadata and json.decode(story.metadata) or nil
                
                -- Get view count
                story.views = MySQL.Sync.fetchScalar(
                    "SELECT COUNT(1) FROM phone_instagram_stories_views WHERE story_id = @id AND viewer != @loggedInAs",
                    {["@id"] = story.id, ["@loggedInAs"] = loggedInAs}
                )
                
                -- Get recent viewers
                story.viewers = MySQL.Sync.fetchAll([[
                    SELECT a.profile_image AS avatar, a.verified
                    FROM phone_instagram_stories_views v

                    INNER JOIN phone_instagram_accounts a
                    ON a.username = v.viewer

                    WHERE v.story_id = @id AND v.viewer != @loggedInAs

                    ORDER BY v.`timestamp` DESC

                    LIMIT 3
                ]], {["@id"] = story.id, ["@loggedInAs"] = loggedInAs})
            end
        end
        
        cb(stories)
    end)
end)

RegisterLegacyCallback("instagram:getViewers", function(source, cb, storyId, page)
    local loggedInAs = GetLoggedInInstagramAccount(source)
    if not loggedInAs then
        return cb(false)
    end
    
    -- Verify story ownership
    local isOwner = MySQL.Sync.fetchScalar(
        "SELECT TRUE FROM phone_instagram_stories WHERE id = @id AND username = @loggedInAs",
        {["@id"] = storyId, ["@loggedInAs"] = loggedInAs}
    )
    
    if not isOwner then
        return cb({})
    end
    
    MySQL.Async.fetchAll([[
        SELECT a.profile_image AS avatar, a.verified, a.display_name AS `name`, a.username
        FROM phone_instagram_stories_views v

        INNER JOIN phone_instagram_accounts a
        ON a.username = v.viewer

        WHERE v.story_id = @id AND v.viewer != @loggedInAs

        ORDER BY v.`timestamp` DESC

        LIMIT @page, @perPage
    ]], {
        ["@id"] = storyId,
        ["@loggedInAs"] = loggedInAs,
        ["@page"] = (page or 0) * 15,
        ["@perPage"] = 15
    }, cb)
end)

RegisterLegacyCallback("instagram:viewedStory", function(source, cb, storyId)
    local loggedInAs = GetLoggedInInstagramAccount(source)
    if not loggedInAs then
        return cb(false)
    end
    
    MySQL.Async.execute(
        "INSERT IGNORE INTO phone_instagram_stories_views (story_id, viewer) VALUES (@id, @loggedInAs)",
        {["@id"] = storyId, ["@loggedInAs"] = loggedInAs},
        function(affectedRows)
            cb(affectedRows > 0)
        end
    )
end)

-- Clean up old stories (24 hours)
CreateThread(function()
    while true do
        MySQL.Async.execute(
            "DELETE FROM phone_instagram_stories WHERE `timestamp` < DATE_SUB(NOW(), INTERVAL 24 HOUR)",
            {}
        )
        Wait(3600000) -- 1 hour
    end
end)

-- Notification types
local notificationTypes = {
    like_photo = "BACKEND.INSTAGRAM.LIKED_PHOTO",
    like_comment = "BACKEND.INSTAGRAM.LIKED_COMMENT",
    comment = "BACKEND.INSTAGRAM.COMMENTED",
    follow = "BACKEND.INSTAGRAM.NEW_FOLLOWER"
}

-- Send Instagram notification
local function SendInstagramNotification(targetUsername, fromUsername, notificationType, postId)
    if targetUsername == fromUsername then
        return
    end
    
    local localeKey = notificationTypes[notificationType]
    if not localeKey then
        return
    end
    
    local notificationText = L(localeKey, {username = fromUsername})
    
    -- Check if notification already exists for likes/follows
    if notificationType == "follow" or notificationType == "like_photo" or notificationType == "like_comment" then
        local exists = MySQL.Sync.fetchScalar(
            "SELECT TRUE FROM phone_instagram_notifications WHERE username=@username AND `from`=@from AND `type`=@type" ..
            (notificationType ~= "follow" and " AND post_id=@post_id" or ""),
            {
                ["@username"] = targetUsername,
                ["@from"] = fromUsername,
                ["@type"] = notificationType,
                ["@post_id"] = postId
            }
        )
        
        if exists then
            return
        end
    end
    
    -- Insert notification
    MySQL.Async.execute(
        "INSERT INTO phone_instagram_notifications (id, username, `from`, `type`, post_id) VALUES (@id, @username, @from, @type, @postId)",
        {
            ["@id"] = GenerateId("phone_instagram_notifications", "id"),
            ["@username"] = targetUsername,
            ["@from"] = fromUsername,
            ["@type"] = notificationType,
            ["@postId"] = postId
        }
    )
    
    -- Get thumbnail for photo notifications
    local thumbnail = nil
    if notificationType == "like_photo" or notificationType == "comment" then
        thumbnail = MySQL.Async.fetchScalar(
            "SELECT TRIM(BOTH '\"' FROM JSON_EXTRACT(media, '$[0]')) FROM phone_instagram_posts WHERE id=@id",
            {["@id"] = postId}
        )
    end
    
    -- Send notification to all logged in devices
    local phoneNumbers = GetPhoneNumbersForInstagramAccount(targetUsername)
    for i = 1, #phoneNumbers do
        SendNotification(phoneNumbers[i], {
            app = "Instagram",
            title = L("APPS.INSTAGRAM.TITLE"),
            content = notificationText,
            thumbnail = thumbnail
        })
    end
end

-- Get notifications
RegisterLegacyCallback("instagram:getNotifications", function(source, cb, page)
    local loggedInAs = GetLoggedInInstagramAccount(source)
    if not loggedInAs then
        return cb({
            notifications = {},
            requests = {
                recent = {},
                total = 0
            }
        })
    end
    
    local notifications = MySQL.Sync.fetchAll([[
        SELECT
            (
                SELECT CASE WHEN f.followed IS NULL THEN FALSE ELSE TRUE END
                    FROM phone_instagram_follows f
                    WHERE f.follower=@username AND f.followed=n.`from`
            ) AS isFollowing,
            -- notification data
            n.`from` AS username,
            n.`type`,
            n.`timestamp`,
            -- post photo
            TRIM(BOTH '"' FROM JSON_EXTRACT(p.media, '$[0]')) AS photo,
            p.id AS postId,
            -- comment text
            c.`comment`,
            c.id AS commentId,
            -- account data
            a.profile_image AS avatar,
            a.verified

        FROM phone_instagram_notifications n

        LEFT JOIN phone_instagram_comments c
            ON n.post_id = c.id

        LEFT JOIN phone_instagram_posts p
            ON p.id = (CASE
                WHEN n.`type`="like_photo"
                THEN n.post_id

                WHEN n.`type`="comment"
                THEN c.post_id

                WHEN n.`type`="like_comment"
                THEN c.post_id

                ELSE NULL
                END
            )

        LEFT JOIN phone_instagram_accounts a
            ON a.username=n.`from`

        WHERE n.username=@username

        ORDER BY n.`timestamp` DESC

        LIMIT @page, @perPage
    ]], {
        ["@username"] = loggedInAs,
        ["@page"] = page * 15,
        ["@perPage"] = 15
    })
    
    if page > 0 then
        return cb({notifications = notifications})
    end
    
    -- Get follow requests for first page
    local recentRequests = MySQL.Sync.fetchAll([[
        SELECT a.username, a.profile_image AS avatar

        FROM phone_instagram_follow_requests r

        INNER JOIN phone_instagram_accounts a
            ON a.username = r.requester

        WHERE r.requestee=@username

        ORDER BY r.`timestamp` DESC

        LIMIT 2
    ]], {["@username"] = loggedInAs})
    
    local totalRequests = MySQL.Sync.fetchScalar(
        "SELECT COUNT(1) FROM phone_instagram_follow_requests WHERE requestee=@username",
        {["@username"] = loggedInAs}
    )
    
    cb({
        notifications = notifications,
        requests = {
            recent = recentRequests,
            total = totalRequests
        }
    })
end)

-- Get follow requests
RegisterLegacyCallback("instagram:getFollowRequests", function(source, cb, page)
    local loggedInAs = GetLoggedInInstagramAccount(source)
    if not loggedInAs then
        return cb({})
    end
    
    MySQL.Async.fetchAll([[
        SELECT a.username, a.display_name AS `name`, a.profile_image AS avatar, a.verified
        FROM phone_instagram_follow_requests r

        INNER JOIN phone_instagram_accounts a
            ON a.username = r.requester

        WHERE r.requestee=@loggedInAs

        ORDER BY r.`timestamp` DESC

        LIMIT @page, @perPage
    ]], {
        ["@loggedInAs"] = loggedInAs,
        ["@page"] = (page or 0) * 15,
        ["@perPage"] = 15
    }, cb)
end)

-- Handle follow request
RegisterLegacyCallback("instagram:handleFollowRequest", function(source, cb, requesterUsername, accepted)
    local loggedInAs = GetLoggedInInstagramAccount(source)
    if not loggedInAs then
        return cb(false)
    end
    
    local params = {
        ["@loggedInAs"] = loggedInAs,
        ["@username"] = requesterUsername
    }
    
    -- Delete request
    local deleted = MySQL.Sync.execute(
        "DELETE FROM phone_instagram_follow_requests WHERE requestee=@loggedInAs AND requester=@username",
        params
    )
    
    if deleted == 0 then
        return cb(false)
    end
    
    if not accepted then
        return cb(true)
    end
    
    -- Add follow
    MySQL.Sync.execute(
        "INSERT IGNORE INTO phone_instagram_follows (follower, followed) VALUES (@username, @loggedInAs)",
        params
    )
    
    -- Update follower counts
    TriggerClientEvent("phone:instagram:updateProfileData", -1, loggedInAs, "followers", true)
    TriggerClientEvent("phone:instagram:updateProfileData", -1, requesterUsername, "following", true)
    
    -- Notify requester
    local displayName = MySQL.Sync.fetchScalar(
        "SELECT display_name FROM phone_instagram_accounts WHERE username=@loggedInAs",
        params
    )
    
    local requesterPhoneNumbers = GetPhoneNumbersForInstagramAccount(requesterUsername)
    for i = 1, #requesterPhoneNumbers do
        SendNotification(requesterPhoneNumbers[i], {
            app = "Instagram",
            title = L("BACKEND.INSTAGRAM.FOLLOW_REQUEST_ACCEPTED_TITLE"),
            content = L("BACKEND.INSTAGRAM.FOLLOW_REQUEST_ACCEPTED_DESCRIPTION", {
                displayName = displayName,
                username = loggedInAs
            })
        })
    end
    
    cb(true)
end)

-- Search accounts
RegisterLegacyCallback("instagram:search", function(source, cb, searchQuery)
    MySQL.Async.fetchAll([[
        SELECT username, display_name AS name, profile_image AS avatar, verified, private
        FROM phone_instagram_accounts
        WHERE
            username LIKE CONCAT(@search, "%")
            OR
            display_name LIKE CONCAT("%", @search, "%")
    ]], {["@search"] = searchQuery}, cb)
end)

-- Create account
RegisterLegacyCallback("instagram:createAccount", function(source, cb, displayName, username, password)
    username = username:lower()
    
    local phoneNumber = GetEquippedPhoneNumber(source)
    if not phoneNumber then
        return cb({success = false, error = "UNKNOWN"})
    end
    
    if not IsUsernameValid(username) then
        return cb({success = false, error = "USERNAME_NOT_ALLOWED"})
    end
    
    debugprint("INSTAGRAM", ("%s wants to create an account"):format(phoneNumber))
    
    -- Check if username exists
    local exists = MySQL.Sync.fetchScalar(
        "SELECT username FROM phone_instagram_accounts WHERE username=@username",
        {["@username"] = username}
    )
    
    if exists then
        debugprint("INSTAGRAM", ("%s tried to create an account with an existing username"):format(phoneNumber))
        return cb({success = false, error = "USERNAME_TAKEN"})
    end
    
    -- Create account
    MySQL.Sync.execute(
        "INSERT INTO phone_instagram_accounts (display_name, username, password, phone_number) VALUES (@displayName, @username, @password, @phonenumber)",
        {
            ["@displayName"] = displayName,
            ["@username"] = username,
            ["@password"] = GetPasswordHash(password),
            ["@phonenumber"] = phoneNumber
        }
    )
    
    debugprint("INSTAGRAM", ("%s created an account"):format(phoneNumber))
    
    AddLoggedInAccount(phoneNumber, "Instagram", username)
    
    cb({success = true})
    
    -- Auto follow configured accounts
    if Config.AutoFollow.Enabled and Config.AutoFollow.InstaPic.Enabled then
        local accountsToFollow = Config.AutoFollow.InstaPic.Accounts
        for i = 1, #accountsToFollow do
            MySQL.update.await(
                "INSERT INTO phone_instagram_follows (followed, follower) VALUES (?, ?)",
                {accountsToFollow[i], username}
            )
        end
    end
end)

-- Change password
CreateInstagramCallback("changePassword", function(source, phoneNumber, username, oldPassword, newPassword)
    if not Config.ChangePassword.InstaPic then
        infoprint("warning", ("%s tried to change password on InstaPic, but it's not enabled in the config."):format(source))
        return false
    end
    
    if oldPassword == newPassword or #newPassword < 3 then
        debugprint("same password / too short")
        return false
    end
    
    if activeLiveStreams[username] then
        debugprint("Can't change password when live")
        return false
    end
    
    -- Verify old password
    local hashedPassword = MySQL.scalar.await(
        "SELECT password FROM phone_instagram_accounts WHERE username = ?",
        {username}
    )
    
    if not hashedPassword or not VerifyPasswordHash(oldPassword, hashedPassword) then
        return false
    end
    
    -- Update password
    local updated = MySQL.update.await(
        "UPDATE phone_instagram_accounts SET password = ? WHERE username = ?",
        {GetPasswordHash(newPassword), username}
    ) > 0
    
    if not updated then
        return false
    end
    
    -- Notify and log out other devices
    NotifyAllDevices(username, {
        title = L("BACKEND.MISC.LOGGED_OUT_PASSWORD.TITLE"),
        content = L("BACKEND.MISC.LOGGED_OUT_PASSWORD.DESCRIPTION")
    }, phoneNumber)
    
    MySQL.update.await(
        "DELETE FROM phone_logged_in_accounts WHERE username = ? AND app = 'Instagram' AND phone_number != ?",
        {username, phoneNumber}
    )
    
    ClearActiveAccountsCache("Instagram", username, phoneNumber)
    
    Log("InstaPic", source, "info", L("BACKEND.LOGS.CHANGED_PASSWORD.TITLE"), 
        L("BACKEND.LOGS.CHANGED_PASSWORD.DESCRIPTION", {
            number = phoneNumber,
            username = username,
            app = "InstaPic"
        })
    )
    
    TriggerClientEvent("phone:logoutFromApp", -1, {
        username = username,
        app = "instagram",
        reason = "password",
        number = phoneNumber
    })
    
    return true
end, false)

-- Delete account
CreateInstagramCallback("deleteAccount", function(source, phoneNumber, username, password)
    if not Config.DeleteAccount.InstaPic then
        infoprint("warning", ("%s tried to delete their account on InstaPic, but it's not enabled in the config."):format(source))
        return false
    end
    
    if activeLiveStreams[username] then
        debugprint("Can't delete account when live")
        return false
    end
    
    -- Verify password
    local hashedPassword = MySQL.scalar.await(
        "SELECT password FROM phone_instagram_accounts WHERE username = ?",
        {username}
    )
    
    if not hashedPassword or not VerifyPasswordHash(password, hashedPassword) then
        return false
    end
    
    -- Delete account
    local deleted = MySQL.update.await(
        "DELETE FROM phone_instagram_accounts WHERE username = ?",
        {username}
    ) > 0
    
    if not deleted then
        return false
    end
    
    -- Notify all devices
    NotifyAllDevices(username, {
        title = L("BACKEND.MISC.DELETED_NOTIFICATION.TITLE"),
        content = L("BACKEND.MISC.DELETED_NOTIFICATION.DESCRIPTION")
    })
    
    -- Remove all logins
    MySQL.update.await(
        "DELETE FROM phone_logged_in_accounts WHERE username = ? AND app = 'Instagram'",
        {username}
    )
    
    ClearActiveAccountsCache("Instagram", username)
    
    Log("InstaPic", source, "info", L("BACKEND.LOGS.DELETED_ACCOUNT.TITLE"),
        L("BACKEND.LOGS.DELETED_ACCOUNT.DESCRIPTION", {
            number = phoneNumber,
            username = username,
            app = "InstaPic"
        })
    )
    
    TriggerClientEvent("phone:logoutFromApp", -1, {
        username = username,
        app = "instagram",
        reason = "deleted"
    })
    
    return true
end, false)

-- Log in
RegisterLegacyCallback("instagram:logIn", function(source, cb, username, password)
    local phoneNumber = GetEquippedPhoneNumber(source)
    if not phoneNumber then
        return cb({success = false, error = "UNKNOWN"})
    end
    
    debugprint("INSTAGRAM", ("%s wants to log in on account %s"):format(phoneNumber, username))
    debugprint("INSTAGRAM", ("%s is not logged in, checking if account exists"):format(phoneNumber))
    
    username = username:lower()
    
    MySQL.Async.fetchScalar(
        "SELECT password FROM phone_instagram_accounts WHERE username=@username",
        {["@username"] = username},
        function(hashedPassword)
            if not hashedPassword then
                debugprint("INSTAGRAM", ("%s tried to log in on non-existing account %s"):format(phoneNumber, username))
                return cb({success = false, error = "UNKNOWN_ACCOUNT"})
            elseif not VerifyPasswordHash(password, hashedPassword) then
                debugprint("INSTAGRAM", ("%s tried to log in on account %s with wrong password"):format(phoneNumber, username))
                return cb({success = false, error = "INCORRECT_PASSWORD"})
            end
            
            debugprint("INSTAGRAM", ("%s logged in on account %s"):format(phoneNumber, username))
            
            AddLoggedInAccount(phoneNumber, "Instagram", username)
            
            -- Get account data
            MySQL.Async.fetchAll([[
                SELECT
                    display_name AS name, username, profile_image AS avatar, verified
                FROM phone_instagram_accounts

                WHERE username = @username
            ]], {["@username"] = username}, function(accountData)
                debugprint("INSTAGRAM", ("%s got account data"):format(phoneNumber))
                cb({
                    success = true,
                    account = accountData?[1]
                })
            end)
        end
    )
end)

-- Check if logged in
RegisterLegacyCallback("instagram:isLoggedIn", function(source, cb)
    local phoneNumber = GetEquippedPhoneNumber(source)
    if not phoneNumber then
        return cb(false)
    end
    
    local username = GetLoggedInAccount(phoneNumber, "Instagram")
    if not username then
        return cb(false)
    end
    
    local accountData = MySQL.single.await([[
        SELECT display_name AS `name`, username, profile_image AS avatar, verified
        FROM phone_instagram_accounts
        WHERE username = ?
    ]], {username})
    
    cb(accountData or false)
end)

-- Sign out
RegisterLegacyCallback("instagram:signOut", function(source, cb)
    local phoneNumber = GetEquippedPhoneNumber(source)
    if not phoneNumber then
        return cb(false)
    end
    
    local username = GetLoggedInAccount(phoneNumber, "Instagram")
    if not username then
        return cb(false)
    end
    
    RemoveLoggedInAccount(phoneNumber, "Instagram", username)
    cb(true)
end)

-- Get profile
RegisterLegacyCallback("instagram:getProfile", function(source, cb, profileUsername)
    local loggedInAs = GetLoggedInInstagramAccount(source)
    if not loggedInAs then
        return cb(false)
    end
    
    MySQL.Async.fetchAll([[
        SELECT display_name AS name, username, profile_image AS avatar, bio, verified, private, follower_count as followers, following_count as following, post_count as posts,
            (
                IF((SELECT TRUE FROM phone_instagram_follows f WHERE f.followed=@username AND f.follower=@loggedInAs), TRUE, FALSE)
            ) AS isFollowing,
            (
                IF((SELECT TRUE FROM phone_instagram_follow_requests fr WHERE fr.requester=@loggedInAs AND fr.requestee=@username), TRUE, FALSE)
            ) AS requested,

            (SELECT a.story_count > 0) AS hasStory,
            (SELECT a.story_count = (
                SELECT COUNT(*) FROM phone_instagram_stories_views
                WHERE viewer=@loggedInAs
                    AND story_id IN (SELECT id FROM phone_instagram_stories WHERE username=@username)
            )) AS seenStory

        FROM phone_instagram_accounts a

        WHERE a.username=@username
    ]], {
        ["@username"] = profileUsername,
        ["@loggedInAs"] = loggedInAs
    }, function(result)
        if result[1] then
            result[1].isLive = activeLiveStreams[profileUsername] and true or false
        end
        
        cb(result?[1] or false)
    end)
end)

-- Create post
RegisterLegacyCallback("instagram:createPost", function(source, cb, media, caption, location)
    local username = GetLoggedInInstagramAccount(source)
    if not username then
        return cb(false)
    end
    
    if ContainsBlacklistedWord(source, "InstaPic", caption) then
        return cb(false)
    end
    
    local postId = GenerateId("phone_instagram_posts", "id")
    
    MySQL.Sync.execute(
        "INSERT INTO phone_instagram_posts (id, username, media, caption, location) VALUES (@id, @username, @media, @caption, @location)",
        {
            ["@id"] = postId,
            ["@username"] = username,
            ["@media"] = media,
            ["@caption"] = caption,
            ["@location"] = location
        }
    )
    
    cb(true)
    
    -- Notify about new post
    local postData = {
        username = username,
        media = media,
        caption = caption,
        location = location,
        id = postId
    }
    
    TriggerClientEvent("phone:instagram:newPost", -1, postData)
    TriggerEvent("Danger_Phone:instapic:newPost", postData)
    
    -- Format media for logging
    media = json.decode(media)
    local logMessage = "**Caption**: " .. (caption or "") .. "\n\n**Photos**:\n"
    for i = 1, #media do
        logMessage = logMessage .. ("[Photo %s](%s)\n"):format(i, media[i])
    end
    logMessage = logMessage .. "**ID:** " .. postId
    
    Log("InstaPic", source, "info", "New post", logMessage)
    TrackSocialMediaPost("instapic", media)
    
    -- Webhook posting
    if Config.Post.InstaPic and INSTAPIC_WEBHOOK and INSTAPIC_WEBHOOK:sub(-14) ~= "/api/webhooks/" then
        local profileImage = MySQL.Sync.fetchScalar(
            "SELECT profile_image FROM phone_instagram_accounts WHERE username=@username",
            {["@username"] = username}
        )
        
        PerformHttpRequest(INSTAPIC_WEBHOOK, function() end, "POST", json.encode({
            username = Config.Post.Accounts?.InstaPic?.Username or "InstaPic",
            avatar_url = Config.Post.Accounts?.InstaPic?.Avatar or "https://Danger-scripts.com/fivem/Danger_Phone/icons/InstaPic.png",
            embeds = {{
                title = L("APPS.INSTAGRAM.NEW_POST"),
                description = (#caption > 0 and caption) or nil,
                color = 9059001,
                timestamp = GetTimestampISO(),
                author = {
                    name = "@" .. username,
                    icon_url = profileImage or "https://cdn.discordapp.com/embed/avatars/5.png"
                },
                image = {
                    url = media[1]
                },
                footer = {
                    text = "Danger Phone",
                    icon_url = "https://r2.fivemanage.com/EX1FJXysrxR5lQr7eorEh/DangerStoreLogo.png"
                }
            }}
        }), {["Content-Type"] = "application/json"})
    end
end)

-- Delete post
RegisterLegacyCallback("instagram:deletePost", function(source, cb, postId)
    local loggedInAs = GetLoggedInInstagramAccount(source)
    if not loggedInAs then
        return cb(false)
    end
    
    -- Check ownership or admin
    local canDelete = IsAdmin(source) or MySQL.Sync.fetchScalar(
        "SELECT TRUE FROM phone_instagram_posts WHERE id=@id AND username=@username",
        {["@id"] = postId, ["@username"] = loggedInAs}
    )
    
    if not canDelete then
        return cb(false)
    end
    
    local params = {["@id"] = postId}
    
    -- Delete related data
    MySQL.Sync.execute("DELETE FROM phone_instagram_likes WHERE id=@id", params)
    MySQL.Sync.execute("DELETE FROM phone_instagram_notifications WHERE post_id=@id", params)
    MySQL.Sync.execute("DELETE FROM phone_instagram_comments WHERE post_id=@id", params)
    
    -- Delete post
    local deleted = MySQL.Sync.execute("DELETE FROM phone_instagram_posts WHERE id=@id", params) > 0
    
    if deleted then
        Log("InstaPic", source, "error", "Deleted post", "**ID**: " .. postId)
    end
    
    cb(deleted)
end)

-- Get single post
RegisterLegacyCallback("instagram:getPost", function(source, cb, postId)
    local loggedInAs = GetLoggedInInstagramAccount(source)
    if not loggedInAs then
        return cb(false)
    end
    
    MySQL.Async.fetchAll([[
        SELECT
            p.id, p.media, p.caption, p.username, p.timestamp, p.like_count, p.comment_count, p.location,

            a.verified, a.profile_image AS avatar,

            (IF((
                SELECT TRUE FROM phone_instagram_likes l
                WHERE l.id=p.id AND l.username=@loggedInAs AND l.is_comment=FALSE
            ), TRUE, FALSE)) AS liked

        FROM phone_instagram_posts p

        INNER JOIN phone_instagram_accounts a
            ON p.username = a.username

        WHERE p.id=@id
    ]], {
        ["@id"] = postId,
        ["@loggedInAs"] = loggedInAs
    }, function(result)
        cb(result?[1] or false)
    end)
end)

-- Get posts
RegisterLegacyCallback("instagram:getPosts", function(source, cb, filters, page)
    local loggedInAs = GetLoggedInInstagramAccount(source)
    if not loggedInAs then
        return cb({})
    end
    
    if not filters then
        filters = {}
    end
    
    local whereClause = ""
    local orderBy = "p.timestamp DESC"
    
    if filters.following then
        whereClause = [[
            JOIN phone_instagram_follows f

            WHERE f.follower=@loggedInAs
                AND f.followed=p.username
        ]]
    elseif filters.profile then
        whereClause = "WHERE p.username=@username"
    else
        whereClause = [[
            WHERE a.private=FALSE
        ]]
    end
    
    local query = ([[
        SELECT
            p.id, p.media, p.caption, p.username, p.timestamp, p.like_count, p.comment_count, p.location,

            a.verified, a.profile_image AS avatar,

            (IF((
                SELECT TRUE FROM phone_instagram_likes l
                WHERE l.id=p.id AND l.username=@loggedInAs AND l.is_comment=FALSE
            ), TRUE, FALSE)) AS liked

        FROM phone_instagram_posts p

        INNER JOIN phone_instagram_accounts a
            ON p.username = a.username

        %s

        ORDER BY %s

        LIMIT @page, @perPage
    ]]):format(whereClause, orderBy)
    
    MySQL.Async.fetchAll(query, {
        ["@page"] = page * 15,
        ["@perPage"] = 15,
        ["@loggedInAs"] = loggedInAs,
        ["@username"] = filters.username
    }, cb)
end)

-- Get comments
RegisterLegacyCallback("instagram:getComments", function(source, cb, postId, page)
    local loggedInAs = GetLoggedInInstagramAccount(source)
    if not loggedInAs then
        return cb({})
    end
    
    MySQL.Async.fetchAll([[
        SELECT
            c.id, c.comment, c.`timestamp`, c.like_count,
            a.username, a.profile_image, a.verified,

            (IF((
                SELECT TRUE FROM phone_instagram_likes l
                WHERE l.id=c.id AND l.username=@loggedInAs AND l.is_comment=TRUE
            ), TRUE, FALSE)) AS liked,

            (IF((
                SELECT TRUE FROM phone_instagram_follows f
                WHERE f.follower=@loggedInAs AND f.followed=a.username
            ), TRUE, FALSE)) AS following

        FROM phone_instagram_comments c

        INNER JOIN phone_instagram_accounts a
            ON c.username = a.username

        WHERE c.post_id=@postId

        ORDER BY following DESC, c.like_count DESC, c.`timestamp` DESC

        LIMIT @page, @perPage
    ]], {
        ["@page"] = page * 20,
        ["@perPage"] = 20,
        ["@postId"] = postId,
        ["@loggedInAs"] = loggedInAs
    }, cb)
end)

-- Post comment
RegisterLegacyCallback("instagram:postComment", function(source, cb, postId, comment)
    local username = GetLoggedInInstagramAccount(source)
    if not username then
        return cb(false)
    end
    
    if ContainsBlacklistedWord(source, "InstaPic", comment) then
        return cb(false)
    end
    
    local commentId = GenerateId("phone_instagram_comments", "id")
    
    MySQL.Async.execute(
     "INSERT INTO phone_instagram_comments (id, post_id, username, comment) VALUES (@id, @postId, @username, @comment)",
        {
            ["@id"] = commentId,
            ["@postId"] = postId,
            ["@username"] = username,
            ["@comment"] = comment
        },
        function()
            -- Get post owner and send notification
            MySQL.Async.fetchScalar(
                "SELECT username FROM phone_instagram_posts WHERE id=@id",
                {["@id"] = postId},
                function(postOwner)
                    SendInstagramNotification(postOwner, username, "comment", commentId)
                end
            )
            
            -- Update comment count
            TriggerClientEvent("phone:instagram:updatePostData", -1, postId, "comment_count", true)
            
            cb(commentId)
        end
    )
end)

-- Update profile
RegisterLegacyCallback("instagram:updateProfile", function(source, cb, profileData)
    local username = GetLoggedInInstagramAccount(source)
    if not username then
        return cb(false)
    end
    
    local updateFields = ""
    local name = profileData.name
    local bio = profileData.bio
    local avatar = profileData.avatar
    local private = profileData.private
    
    -- Build update query
    if name then
        updateFields = updateFields .. "display_name=@displayName,"
    end
    if bio then
        updateFields = updateFields .. "bio=@bio,"
    end
    if avatar then
        updateFields = updateFields .. "profile_image=@avatar,"
    end
    if type(private) == "boolean" then
        updateFields = updateFields .. "private=@private,"
    end
    
    -- Remove trailing comma
    updateFields = updateFields:sub(1, -2)
    
    MySQL.Async.execute(
        "UPDATE phone_instagram_accounts SET " .. updateFields .. " WHERE username=@username",
        {
            ["@displayName"] = name,
            ["@bio"] = bio,
            ["@avatar"] = avatar,
            ["@username"] = username,
            ["@private"] = private
        },
        function()
            cb(true)
        end
    )
end)

-- Toggle follow
RegisterLegacyCallback("instagram:toggleFollow", function(source, cb, targetUsername, shouldFollow)
    local followerUsername = GetLoggedInInstagramAccount(source)
    if not followerUsername or targetUsername == followerUsername then
        return cb(not shouldFollow)
    end
    
    local function updateFollowStatus(affectedRows)
        if affectedRows == 0 then
            return cb(shouldFollow)
        end
        
        -- Update follower counts
        TriggerClientEvent("phone:instagram:updateProfileData", -1, targetUsername, "followers", shouldFollow)
        TriggerClientEvent("phone:instagram:updateProfileData", -1, followerUsername, "following", shouldFollow)
        
        cb(shouldFollow)
        
        -- Send follow notification
        if shouldFollow then
            SendInstagramNotification(targetUsername, followerUsername, "follow")
        end
    end
    
    local params = {
        ["@username"] = targetUsername,
        ["@loggedInAs"] = followerUsername
    }
    
    -- Check if account is private
    local isPrivate = MySQL.Sync.fetchScalar(
        "SELECT private FROM phone_instagram_accounts WHERE username=@username",
        params
    )
    
    if isPrivate then
        if shouldFollow then
            -- Send follow request
            MySQL.Async.execute(
                "INSERT IGNORE INTO phone_instagram_follow_requests (requester, requestee) VALUES (@loggedInAs, @username)",
                params,
                function()
                    cb(shouldFollow)
                end
            )
            
            -- Notify about follow request
            local displayName = MySQL.Sync.fetchScalar(
                "SELECT display_name FROM phone_instagram_accounts WHERE username=@loggedInAs",
                params
            )
            
            local targetPhoneNumbers = GetPhoneNumbersForInstagramAccount(targetUsername)
            for i = 1, #targetPhoneNumbers do
                SendNotification(targetPhoneNumbers[i], {
                    app = "Instagram",
                    title = L("BACKEND.INSTAGRAM.NEW_FOLLOW_REQUEST_TITLE"),
                    content = L("BACKEND.INSTAGRAM.NEW_FOLLOW_REQUEST_DESCRIPTION", {
                        displayName = displayName,
                        username = followerUsername
                    })
                })
            end
            
            return
        end
        
        -- Cancel follow request
        MySQL.Async.execute(
            "DELETE FROM phone_instagram_follow_requests WHERE requester=@loggedInAs AND requestee=@username",
            params
        )
    end
    
    -- Handle follow/unfollow
    local query = shouldFollow and
        "INSERT IGNORE INTO phone_instagram_follows (followed, follower) VALUES (@username, @loggedInAs)" or
        "DELETE FROM phone_instagram_follows WHERE followed=@username AND follower=@loggedInAs"
    
    MySQL.Async.execute(query, params, updateFollowStatus)
end)

-- Toggle like
RegisterLegacyCallback("instagram:toggleLike", function(source, cb, contentId, shouldLike, isComment)
    if not contentId then
        return cb(false)
    end
    
    local username = GetLoggedInInstagramAccount(source)
    if not username then
        return cb(false)
    end
    
    local function updateLikeStatus(affectedRows)
        if affectedRows == 0 then
            return cb(shouldLike)
        end
        
        cb(shouldLike)
        
        -- Update like count
        if isComment then
            TriggerClientEvent("phone:instagram:updateCommentLikes", -1, contentId, shouldLike)
        else
            TriggerClientEvent("phone:instagram:updatePostData", -1, contentId, "like_count", shouldLike)
        end
        
        -- Send notification for new likes
        if shouldLike then
            MySQL.Async.fetchScalar(
                "SELECT username FROM " .. (isComment and "phone_instagram_comments" or "phone_instagram_posts") .. " WHERE id=@postId",
                {["@postId"] = contentId},
                function(contentOwner)
                    if contentOwner then
                        SendInstagramNotification(contentOwner, username, "like_" .. (isComment and "comment" or "photo"), contentId)
                    end
                end
            )
        end
    end
    
    local query = shouldLike and
        "INSERT IGNORE INTO phone_instagram_likes (id, username, is_comment) VALUES (@postId, @loggedInAs, @isComment)" or
        "DELETE FROM phone_instagram_likes WHERE id=@postId AND username=@loggedInAs AND is_comment=@isComment"
    
    MySQL.Async.execute(query, {
        ["@postId"] = contentId,
        ["@loggedInAs"] = username,
        ["@isComment"] = isComment
    }, updateLikeStatus)
end)

-- Get data (likes, followers, following)
RegisterLegacyCallback("instagram:getData", function(source, cb, dataType, options)
    local loggedInAs = GetLoggedInInstagramAccount(source)
    if not loggedInAs then
        return cb({})
    end
    
    local tableName = ""
    local columnName = ""
    local whereClause = ""
    local orderBy = ""
    
    if dataType == "likes" then
        tableName = "phone_instagram_likes"
        columnName = "username"
        whereClause = "id=@postId AND is_comment=@isComment"
        orderBy = "a.username"
    elseif dataType == "followers" then
        tableName = "phone_instagram_follows"
        columnName = "follower"
        whereClause = "q.followed=@username"
        orderBy = "q.follower"
    elseif dataType == "following" then
        tableName = "phone_instagram_follows"
        columnName = "followed"
        whereClause = "q.follower=@username"
        orderBy = "q.followed"
    end
    
    MySQL.Async.fetchAll(([[
        SELECT
            a.username, a.display_name AS name, a.profile_image AS avatar, a.verified,

            (IF((
                SELECT TRUE FROM phone_instagram_follows f
                WHERE f.followed=a.username AND f.follower=@loggedInAs
            ), TRUE, FALSE)) AS isFollowing

        FROM phone_instagram_accounts a

        INNER JOIN %s q ON q.%s=a.username

        WHERE %s

        ORDER BY %s DESC

        LIMIT @page, @perPage
    ]]):format(tableName, columnName, whereClause, orderBy), {
        ["@username"] = options.username,
        ["@postId"] = options.postId,
        ["@isComment"] = options.isComment == true,
        ["@loggedInAs"] = loggedInAs,
        ["@page"] = (options.page or 0) * 20,
        ["@perPage"] = 20
    }, cb)
end)

-- Get recent messages
RegisterLegacyCallback("instagram:getRecentMessages", function(source, cb, page)
    local loggedInAs = GetLoggedInInstagramAccount(source)
    if not loggedInAs then
        return cb({})
    end
    
    MySQL.Async.fetchAll([[
        SELECT
            m.content, m.attachments, m.sender, f_m.username, m.`timestamp`,

            a.display_name AS `name`, a.profile_image AS avatar, a.verified

        FROM phone_instagram_messages m

        JOIN ((
            SELECT (
                CASE WHEN recipient!=@loggedInAs THEN recipient ELSE sender END
            ) AS username, MAX(`timestamp`) AS `timestamp`

            FROM phone_instagram_messages

            WHERE sender=@loggedInAs OR recipient=@loggedInAs

            GROUP BY username
        ) f_m)
        ON m.`timestamp`=f_m.`timestamp`

        INNER JOIN phone_instagram_accounts a
            ON a.username=f_m.username

        WHERE m.sender=@loggedInAs OR m.recipient=@loggedInAs

        GROUP BY f_m.username

        ORDER BY m.`timestamp` DESC

        LIMIT @page, @perPage
    ]], {
        ["@loggedInAs"] = loggedInAs,
        ["@page"] = (page or 0) * 15,
        ["@perPage"] = 15
    }, cb)
end)

-- Get messages
RegisterLegacyCallback("instagram:getMessages", function(source, cb, otherUsername, page)
    local loggedInAs = GetLoggedInInstagramAccount(source)
    if not loggedInAs then
        return cb({})
    end
    
    MySQL.Async.fetchAll([[
        SELECT
            sender, recipient, content, attachments, `timestamp`

        FROM phone_instagram_messages

        WHERE (sender=@loggedInAs AND recipient=@username) OR (sender=@username AND recipient=@loggedInAs)

        ORDER BY `timestamp` DESC

        LIMIT @page, @perPage
    ]], {
        ["@loggedInAs"] = loggedInAs,
        ["@username"] = otherUsername,
        ["@page"] = (page or 0) * 25,
        ["@perPage"] = 25
    }, cb)
end)

-- Send message
RegisterLegacyCallback("instagram:sendMessage", function(source, cb, recipient, messageData)
    local sender = GetLoggedInInstagramAccount(source)
    if not sender then
        return cb(false)
    end
    
    if ContainsBlacklistedWord(source, "InstaPic", messageData) then
        return cb(false)
    end
    
    MySQL.Async.execute(
        "INSERT INTO phone_instagram_messages (id, sender, recipient, content, attachments) VALUES (@id, @sender, @recipient, @content, @attachments)",
        {
            ["@id"] = GenerateId("phone_instagram_messages", "id"),
            ["@sender"] = sender,
            ["@recipient"] = recipient,
            ["@content"] = messageData.content,
            ["@attachments"] = messageData.attachments and json.encode(messageData.attachments) or nil
        },
        function(affectedRows)
            if affectedRows == 0 then
                return cb(false)
            end
            
            cb(true)
            
            -- Get recipient phone numbers
            local recipientPhones = MySQL.query.await(
                "SELECT phone_number FROM phone_logged_in_accounts WHERE username = ? AND app = 'Instagram' AND `active` = 1",
                {recipient}
            )
            
            if not recipientPhones or #recipientPhones == 0 then
                return
            end
            
            -- Get sender data
            MySQL.single(
                "SELECT display_name, username, profile_image FROM phone_instagram_accounts WHERE username = ?",
                {sender},
                function(senderData)
                    if not senderData then
                        return
                    end
                    
                    -- Send to all recipient devices
                    for i = 1, #recipientPhones do
                        local phoneNumber = recipientPhones[i].phone_number
                        local recipientSource = GetSourceFromNumber(phoneNumber)
                        
                        if recipientSource then
                            TriggerClientEvent("phone:instagram:newMessage", recipientSource, {
                                sender = sender,
                                recipient = recipient,
                                content = messageData.content,
                                attachments = messageData.attachments,
                                timestamp = os.time() * 1000
                            })
                        end
                        
                        -- Check if story reply
                        local messageContent = messageData.content
                        if string.find(messageContent, "<!REPLIED_STORY-DATA=", nil, true) then
                            messageContent = L("APPS.INSTAGRAM.REPLIED_TO_YOUR_STORY")
                        end
                        
                        -- Send notification
                        SendNotification(phoneNumber, {
                            app = "Instagram",
                            title = senderData.display_name,
                            content = messageContent,
                            thumbnail = messageData.attachments and messageData.attachments[1],
                            avatar = senderData.profile_image,
                            showAvatar = true
                        })
                    end
                end
            )
        end
    )
end)