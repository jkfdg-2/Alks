-- Twitter/Birdy App Backend for FiveM Phone System

-- Helper Functions
local function getLoggedInAccount(source)
    local phoneNumber = GetEquippedPhoneNumber(source)
    if not phoneNumber then
        return false
    end
    return GetLoggedInAccount(phoneNumber, "Twitter")
end

local function createAuthenticatedCallback(callbackName, handler, defaultReturn)
    BaseCallback("birdy:" .. callbackName, function(source, phoneNumber, ...)
        local account = GetLoggedInAccount(phoneNumber, "Twitter")
        if not account then
            return defaultReturn
        end
        return handler(source, phoneNumber, account, ...)
    end, defaultReturn)
end

local function sendNotificationsToAccount(username, notification, excludePhoneNumber)
    local users = MySQL.query.await(
        "SELECT phone_number FROM phone_logged_in_accounts WHERE username = ? AND app = 'Twitter' AND `active` = 1",
        {username}
    )
    
    notification.app = "Twitter"
    for _, user in ipairs(users) do
        if user.phone_number ~= excludePhoneNumber then
            SendNotification(user.phone_number, notification)
        end
    end
end

local function getProfileInfo(username, requestingPhoneNumber)
    username = username:lower()
    
    local accountData = MySQL.single.await(
        "SELECT `display_name`, `bio`, `profile_image`, `profile_header`, `verified`, `follower_count`, `following_count`, `date_joined`, private FROM `phone_twitter_accounts` WHERE `username`=?",
        {username}
    )
    
    if not accountData then
        return false
    end
    
    local isFollowing = false
    local isFollowingYou = false
    local notificationsEnabled = false
    local hasRequested = false
    local pinnedTweet = nil
    
    local loggedInAccount = requestingPhoneNumber and GetLoggedInAccount(requestingPhoneNumber, "Twitter")
    
    if loggedInAccount then
        -- Check following status
        isFollowing = MySQL.scalar.await(
            "SELECT `followed` FROM `phone_twitter_follows` WHERE `follower` = ? AND `followed` = ?",
            {loggedInAccount, username}
        ) ~= nil
        
        -- Check if they follow you
        isFollowingYou = MySQL.scalar.await(
            "SELECT `followed` FROM `phone_twitter_follows` WHERE `follower` = ? AND `followed` = ?",
            {username, loggedInAccount}
        ) ~= nil
        
        -- Check notifications enabled
        notificationsEnabled = MySQL.scalar.await(
            "SELECT `notifications` FROM `phone_twitter_follows` WHERE `follower` = ? AND `followed` = ?",
            {loggedInAccount, username}
        ) == true
        
        -- Check follow request status
        hasRequested = MySQL.scalar.await(
            "SELECT TRUE FROM phone_twitter_follow_requests WHERE requester = ? AND requestee = ?",
            {loggedInAccount, username}
        ) ~= nil
        
        -- Get pinned tweet
        local pinnedTweetId = MySQL.scalar.await(
            "SELECT pinned_tweet FROM phone_twitter_accounts WHERE username = ?",
            {username}
        )
        
        if pinnedTweetId then
            pinnedTweet = GetTweet(pinnedTweetId, loggedInAccount)
        end
    end
    
    return {
        name = accountData.display_name,
        username = username,
        followers = accountData.follower_count,
        following = accountData.following_count,
        date_joined = accountData.date_joined,
        bio = accountData.bio,
        verified = accountData.verified,
        private = accountData.private,
        profile_picture = accountData.profile_image,
        header = accountData.profile_header,
        isFollowing = isFollowing,
        isFollowingYou = isFollowingYou,
        notificationsEnabled = notificationsEnabled,
        pinnedTweet = pinnedTweet,
        requested = hasRequested
    }
end

local function getActiveUsersForAccount(username)
    local result = {}
    local users = MySQL.Sync.fetchAll(
        "SELECT phone_number FROM phone_logged_in_accounts WHERE username = ? AND app = 'Twitter' AND `active` = 1",
        {username}
    )
    
    for _, user in ipairs(users) do
        local source = GetSourceFromNumber(user.phone_number)
        result[user.phone_number] = source
    end
    
    return result
end

-- Notification Types
local NOTIFICATION_TYPES = {
    like = "BACKEND.TWITTER.LIKE",
    retweet = "BACKEND.TWITTER.RETWEET",
    reply = "BACKEND.TWITTER.REPLY",
    follow = "BACKEND.TWITTER.FOLLOW",
    tweet = "BACKEND.TWITTER.TWEET"
}

local function sendTwitterNotification(toUsername, fromUsername, notificationType, tweetId)
    if toUsername == fromUsername then
        return
    end
    
    local localeKey = NOTIFICATION_TYPES[notificationType]
    if not localeKey then
        return
    end
    
    -- Check if notification already exists for certain types
    if notificationType == "like" or notificationType == "retweet" or notificationType == "follow" then
        local query = "SELECT TRUE FROM phone_twitter_notifications WHERE username=@username AND `from`=@from AND `type`=@type"
        if notificationType ~= "follow" then
            query = query .. " AND tweet_id=@tweet_id"
        end
        
        local exists = MySQL.Sync.fetchScalar(query, {
            ["@username"] = toUsername,
            ["@from"] = fromUsername,
            ["@type"] = notificationType,
            ["@tweet_id"] = tweetId
        })
        
        if exists then
            return
        end
    end
    
    -- Get sender info
    local senderInfo = MySQL.Sync.fetchAll(
        "SELECT display_name, private FROM phone_twitter_accounts WHERE username=@username",
        {["@username"] = fromUsername}
    )[1]
    
    if not senderInfo or (senderInfo.private and notificationType == "reply") then
        return
    end
    
    local notificationTitle = L(localeKey, {
        displayName = senderInfo.display_name,
        username = fromUsername
    })
    
    -- Insert notification
    MySQL.Async.execute(
        "INSERT INTO phone_twitter_notifications (id, username, `from`, `type`, tweet_id) VALUES (@id, @username, @from, @type, @tweetId)",
        {
            ["@id"] = GenerateId("phone_twitter_notifications", "id"),
            ["@username"] = toUsername,
            ["@from"] = fromUsername,
            ["@type"] = notificationType,
            ["@tweetId"] = tweetId
        }
    )
    
    -- Get tweet content for notification
    local tweetContent = nil
    local attachments = nil
    
    if notificationType ~= "follow" then
        local tweetData = MySQL.Sync.fetchAll(
            "SELECT content, attachments FROM phone_twitter_tweets WHERE id=@tweetId",
            {["@tweetId"] = tweetId}
        )
        
        if tweetData and tweetData[1] then
            tweetContent = tweetData[1].content
            attachments = tweetData[1].attachments and json.decode(tweetData[1].attachments)
        end
    end
    
    -- Send notification to all active sessions
    local activeUsers = getActiveUsersForAccount(toUsername)
    for phoneNumber, source in pairs(activeUsers) do
        SendNotification(phoneNumber, {
            app = "Twitter",
            title = notificationTitle,
            content = tweetContent,
            thumbnail = attachments and attachments[1]
        })
    end
end

-- Callbacks

-- Get Notifications
RegisterLegacyCallback("birdy:getNotifications", function(source, cb, page)
    local account = getLoggedInAccount(source)
    if not account then
        return cb({notifications = {}, requests = 0})
    end
    
    local notifications = MySQL.Sync.fetchAll([[
        SELECT
            n.`from`, n.`type`, n.tweet_id,
            t.username, t.content, t.attachments, t.reply_to, t.like_count,
            t.reply_count, t.retweet_count, t.`timestamp`,
            (SELECT TRUE FROM phone_twitter_likes l WHERE l.tweet_id=t.id AND l.username=@username) AS liked,
            (SELECT TRUE FROM phone_twitter_retweets r WHERE r.tweet_id=t.id AND r.username=@username) AS retweeted,
            a.display_name AS `name`, a.profile_image AS profile_picture, a.verified,
            (CASE WHEN t.reply_to IS NULL THEN NULL ELSE (SELECT username FROM phone_twitter_tweets WHERE id=t.reply_to LIMIT 1) END) AS replyToAuthor
        FROM phone_twitter_notifications n
        LEFT JOIN phone_twitter_tweets t ON n.tweet_id = t.id
        JOIN phone_twitter_accounts a ON a.username = n.from
        WHERE n.username=@username
        ORDER BY n.`timestamp` DESC
        LIMIT @page, @perPage
    ]], {
        ["@page"] = page * 15,
        ["@perPage"] = 15,
        ["@username"] = account
    })
    
    if page > 0 then
        return cb({notifications = notifications})
    end
    
    local requestCount = MySQL.Sync.fetchScalar(
        "SELECT COUNT(1) FROM phone_twitter_follow_requests WHERE requestee=@username",
        {["@username"] = account}
    )
    
    cb({
        notifications = notifications,
        requests = requestCount
    })
end)

-- Create Account
RegisterLegacyCallback("birdy:createAccount", function(source, cb, displayName, username, password)
    local phoneNumber = GetEquippedPhoneNumber(source)
    if not phoneNumber then
        return cb(false)
    end
    
    username = username:lower()
    
    if not IsUsernameValid(username) then
        return cb({success = false, error = "USERNAME_NOT_ALLOWED"})
    end
    
    -- Check if username exists
    local exists = MySQL.Sync.fetchScalar(
        "SELECT TRUE FROM phone_twitter_accounts WHERE username=@username",
        {["@username"] = username}
    )
    
    if exists then
        return cb({success = false, error = "USERNAME_TAKEN"})
    end
    
    -- Create account
    MySQL.Sync.execute(
        "INSERT INTO phone_twitter_accounts (display_name, username, `password`, phone_number) VALUES (@displayName, @username, @password, @phonenumber)",
        {
            ["@displayName"] = displayName,
            ["@username"] = username,
            ["@password"] = GetPasswordHash(password),
            ["@phonenumber"] = phoneNumber
        }
    )
    
    AddLoggedInAccount(phoneNumber, "Twitter", username)
    cb({success = true})
    
    -- Auto-follow feature
    if Config.AutoFollow.Enabled and Config.AutoFollow.Birdy.Enabled then
        for _, accountToFollow in ipairs(Config.AutoFollow.Birdy.Accounts) do
            MySQL.update.await(
                "INSERT INTO phone_twitter_follows (followed, follower) VALUES (?, ?)",
                {accountToFollow, username}
            )
        end
    end
end)

-- Change Password
createAuthenticatedCallback("changePassword", function(source, phoneNumber, account, oldPassword, newPassword)
    if not Config.ChangePassword.Birdy then
        infoprint("warning", "%s tried to change password on Birdy, but it's not enabled in the config.", source)
        return false
    end
    
    if oldPassword == newPassword or #newPassword < 3 then
        debugprint("same password / too short")
        return false
    end
    
    -- Verify old password
    local storedPassword = MySQL.scalar.await(
        "SELECT password FROM phone_twitter_accounts WHERE username = ?",
        {account}
    )
    
    if not storedPassword or not VerifyPasswordHash(oldPassword, storedPassword) then
        return false
    end
    
    -- Update password
    local updated = MySQL.update.await(
        "UPDATE phone_twitter_accounts SET password = ? WHERE username = ?",
        {GetPasswordHash(newPassword), account}
    )
    
    if updated == 0 then
        return false
    end
    
    -- Send logout notification
    sendNotificationsToAccount(account, {
        title = L("BACKEND.MISC.LOGGED_OUT_PASSWORD.TITLE"),
        content = L("BACKEND.MISC.LOGGED_OUT_PASSWORD.DESCRIPTION")
    }, phoneNumber)
    
    -- Remove all logged in sessions except current
    MySQL.update.await(
        "DELETE FROM phone_logged_in_accounts WHERE username = ? AND app = 'Twitter' AND phone_number != ?",
        {account, phoneNumber}
    )
    
    ClearActiveAccountsCache("Twitter", account, phoneNumber)
    
    Log("Birdy", source, "info", L("BACKEND.LOGS.CHANGED_PASSWORD.TITLE"), 
        L("BACKEND.LOGS.CHANGED_PASSWORD.DESCRIPTION", {
            number = phoneNumber,
            username = account,
            app = "Birdy"
        })
    )
    
    -- Trigger logout on all clients
    TriggerClientEvent("phone:logoutFromApp", -1, {
        username = account,
        app = "twitter",
        reason = "password",
        number = phoneNumber
    })
    
    return true
end, false)

-- Delete Account
createAuthenticatedCallback("deleteAccount", function(source, phoneNumber, account, password)
    if not Config.DeleteAccount.Birdy then
        infoprint("warning", "%s tried to delete their account on Birdy, but it's not enabled in the config.", source)
        return false
    end
    
    -- Verify password
    local storedPassword = MySQL.scalar.await(
        "SELECT password FROM phone_twitter_accounts WHERE username = ?",
        {account}
    )
    
    if not storedPassword or not VerifyPasswordHash(password, storedPassword) then
        return false
    end
    
    -- Delete account
    local deleted = MySQL.update.await(
        "DELETE FROM phone_twitter_accounts WHERE username = ?",
        {account}
    )
    
    if deleted == 0 then
        return false
    end
    
    -- Send deletion notification
    sendNotificationsToAccount(account, {
        title = L("BACKEND.MISC.DELETED_NOTIFICATION.TITLE"),
        content = L("BACKEND.MISC.DELETED_NOTIFICATION.DESCRIPTION")
    })
    
    -- Remove all logged in sessions
    MySQL.update.await(
        "DELETE FROM phone_logged_in_accounts WHERE username = ? AND app = 'Twitter'",
        {account}
    )
    
    ClearActiveAccountsCache("Twitter", account)
    
    Log("Birdy", source, "info", L("BACKEND.LOGS.DELETED_ACCOUNT.TITLE"), 
        L("BACKEND.LOGS.DELETED_ACCOUNT.DESCRIPTION", {
            number = phoneNumber,
            username = account,
            app = "Birdy"
        })
    )
    
    -- Trigger logout on all clients
    TriggerClientEvent("phone:logoutFromApp", -1, {
        username = account,
        app = "twitter",
        reason = "deleted"
    })
    
    return true
end, false)

-- Login
BaseCallback("birdy:login", function(source, phoneNumber, username, password)
    username = username:lower()
    
    local storedPassword = MySQL.scalar.await(
        "SELECT `password` FROM phone_twitter_accounts WHERE username = ?",
        {username}
    )
    
    if not storedPassword then
        return {success = false, error = "INVALID_ACCOUNT"}
    end
    
    if not VerifyPasswordHash(password, storedPassword) then
        return {success = false, error = "INVALID_PASSWORD"}
    end
    
    AddLoggedInAccount(phoneNumber, "Twitter", username)
    
    local profileData = getProfileInfo(username)
    if not profileData then
        return {success = false, error = "INVALID_ACCOUNT"}
    end
    
    return {success = true, data = profileData}
end)

-- Check if logged in
createAuthenticatedCallback("isLoggedIn", function(source, phoneNumber, account)
    return getProfileInfo(account)
end, false)

-- Get Profile
createAuthenticatedCallback("getProfile", function(source, phoneNumber, account, targetUsername)
    return getProfileInfo(targetUsername, phoneNumber)
end, false)

-- Pin Post
RegisterLegacyCallback("birdy:pinPost", function(source, cb, tweetId)
    local account = getLoggedInAccount(source)
    if not account then
        return cb(false)
    end
    
    -- Verify ownership if pinning
    if tweetId then
        local ownsTweet = MySQL.scalar.await(
            "SELECT TRUE FROM phone_twitter_tweets WHERE id = ? AND username = ?",
            {tweetId, account}
        )
        
        if not ownsTweet then
            infoprint("warning", "%s (%s) tried to pin a post on birdy that they didn't make.", account, source)
            return cb(false)
        end
    end
    
    MySQL.Async.execute(
        "UPDATE phone_twitter_accounts SET pinned_tweet=@tweetId WHERE username=@username",
        {
            ["@tweetId"] = tweetId or nil,
            ["@username"] = account
        },
        function()
            cb(true)
        end
    )
end)

-- Sign Out
RegisterLegacyCallback("birdy:signOut", function(source, cb)
    local phoneNumber = GetEquippedPhoneNumber(source)
    if not phoneNumber then
        return cb(false)
    end
    
    local account = GetLoggedInAccount(phoneNumber, "Twitter")
    if not account then
        return cb(false)
    end
    
    RemoveLoggedInAccount(phoneNumber, "Twitter", account)
    cb(true)
end)

-- Update Profile
RegisterLegacyCallback("birdy:updateProfile", function(source, cb, profileData)
    local account = getLoggedInAccount(source)
    if not account then
        return cb(false)
    end
    
    MySQL.Async.execute(
        "UPDATE phone_twitter_accounts SET display_name=@displayName, bio=@bio, profile_image=@profilePicture, profile_header=@header, private=@private WHERE username=@username",
        {
            ["@username"] = account,
            ["@displayName"] = profileData.name,
            ["@bio"] = profileData.bio,
            ["@profilePicture"] = profileData.profile_picture,
            ["@header"] = profileData.header,
            ["@private"] = profileData.private
        },
        function()
            cb(true)
        end
    )
end)

-- Helper function to log posts
local function logPost(tweetId, username, content, attachments, source)
    local attachmentCount = attachments and #attachments or 0
    local logContent = string.format(
        "**Username**: %s\n\n**Content**: %s",
        username,
        content or ""
    )
    
    if attachments then
        logContent = logContent .. "\n\n**Attachments**:"
        for i = 1, attachmentCount do
            logContent = logContent .. string.format("\n\n[Attachment %s](%s)", i, attachments[i])
        end
    end
    
    logContent = logContent .. "\n\n**ID**: " .. tweetId
    
    Log("Birdy", source, "info", "New post", logContent)
end

-- Helper function to send webhook
local function sendWebhook(username, content, attachments, replyTo)
    if not Config.Post.Birdy or replyTo then
        return
    end
    
    if not BIRDY_WEBHOOK or BIRDY_WEBHOOK:sub(-14) ~= "/api/webhooks/" then
        return
    end
    
    local profileImage = MySQL.scalar.await(
        "SELECT profile_image FROM phone_twitter_accounts WHERE username = ?",
        {username}
    )
    
    PerformHttpRequest(BIRDY_WEBHOOK, function() end, "POST", json.encode({
        username = Config.Post.Accounts and Config.Post.Accounts.Birdy and Config.Post.Accounts.Birdy.Username or "Birdy",
        avatar_url = Config.Post.Accounts and Config.Post.Accounts.Birdy and Config.Post.Accounts.Birdy.Avatar or "https://Danger-scripts.com/fivem/Danger_Phone/icons/Birdy.png",
        embeds = {{
            title = L("APPS.TWITTER.NEW_POST"),
            description = content and #content > 0 and content or nil,
            color = 1942002,
            timestamp = GetTimestampISO(),
            author = {
                name = "@" .. username,
                icon_url = profileImage or "https://cdn.discordapp.com/embed/avatars/5.png"
            },
            image = attachments and #attachments > 0 and {url = attachments[1]} or nil,
            footer = {
                text = "Danger Phone",
                icon_url = "https://r2.fivemanage.com/EX1FJXysrxR5lQr7eorEh/DangerStoreLogo.png"
            }
        }}
    }), {["Content-Type"] = "application/json"})
end

-- Post Birdy function
local function postBirdy(username, content, attachments, replyTo, hashtags, source)
    if not content then
        content = ""
    end
    
    assert(type(username) == "string", "PostBirdy: Expected string for argument 1 (username), got " .. type(username))
    assert(type(content) == "string", "PostBirdy: Expected string/nil for argument 2 (content), got " .. type(content))
    
    local tweetId = GenerateId("phone_twitter_tweets", "id")
    local params = {tweetId, username, content}
    local query = "INSERT INTO phone_twitter_tweets (id, username, content"
    
    -- Handle attachments
    if attachments then
        if type(attachments) == "table" and table.type(attachments) == "array" and #attachments > 0 then
            query = query .. ", attachments"
            table.insert(params, json.encode(attachments))
        else
            error("PostBirdy: Expected table/nil for argument 3 (attachments), got " .. type(attachments))
        end
    elseif content:gsub(" ", "") == "" then
        debugprint("PostBirdy: No content & no attachments")
        return false
    end
    
    -- Handle reply
    if replyTo then
        if type(replyTo) == "string" then
            query = query .. ", reply_to"
            table.insert(params, replyTo)
        else
            error("PostBirdy: Expected string/nil for argument 4 (replyTo), got " .. type(replyTo))
        end
    end
    
    query = query .. ") VALUES (" .. string.rep("?, ", #params):sub(1, -3) .. ")"
    
    local affected = MySQL.update.await(query, params)
    if affected == 0 then
        return false
    end
    
    -- Get account info
    local accountInfo = MySQL.single.await(
        "SELECT display_name, profile_image, verified, private FROM phone_twitter_accounts WHERE username = ?",
        {username}
    )
    
    if not accountInfo then
        accountInfo = {display_name = username}
    end
    
    -- Handle reply notifications
    if replyTo then
        MySQL.update("UPDATE phone_twitter_tweets SET reply_count = reply_count + 1 WHERE id = ?", {replyTo})
        TriggerClientEvent("phone:twitter:updateTweetData", -1, replyTo, "replies", true)
        
        MySQL.scalar("SELECT username FROM phone_twitter_tweets WHERE id = ?", {replyTo}, function(replyToUsername)
            if replyToUsername then
                sendTwitterNotification(replyToUsername, username, "reply", tweetId)
            end
        end)
    end
    
    -- Notify followers
    MySQL.query("SELECT follower FROM phone_twitter_follows WHERE followed = ? AND notifications=1", {username}, function(followers)
        for _, follower in ipairs(followers) do
            sendTwitterNotification(follower.follower, username, "tweet", tweetId)
        end
    end)
    
    TrackSocialMediaPost("birdy", attachments)
    
    if source then
        logPost(tweetId, username, content, attachments, source)
    end
    
    -- Public post actions
    if not accountInfo.private then
        sendWebhook(username, content, attachments, replyTo)
        
        -- Global notifications
        if Config.BirdyNotifications then
            local notifyMode = Config.BirdyNotifications == "all" and "all" or "online"
            NotifyEveryone(notifyMode, {
                app = "Twitter",
                title = L("BACKEND.TWITTER.TWEET", {username = username}),
                content = content,
                thumbnail = attachments and attachments[1]
            })
        end
        
        -- Handle hashtags
        if Config.BirdyTrending.Enabled and type(hashtags) == "table" and table.type(hashtags) == "array" and #hashtags > 0 then
            local hashtagQuery = "INSERT INTO phone_twitter_hashtags (hashtag, amount) VALUES " ..
                string.rep("(?, 1), ", #hashtags):sub(1, -3) ..
                " ON DUPLICATE KEY UPDATE amount = amount + 1"
            MySQL.update(hashtagQuery, hashtags)
        end
        
        -- Broadcast new tweet
        local tweetData = {
            id = tweetId,
            username = username,
            content = content,
            attachments = attachments,
            like_count = 0,
            reply_count = 0,
            retweet_count = 0,
            reply_to = replyTo,
            timestamp = os.time() * 1000,
            liked = false,
            retweeted = false,
            display_name = accountInfo.display_name,
            profile_image = accountInfo.profile_image,
            verified = accountInfo.verified
        }
        
        if replyTo then
            tweetData.replyToAuthor = MySQL.scalar.await(
                "SELECT username FROM phone_twitter_tweets WHERE id = ?",
                {replyTo}
            )
        end
        
        TriggerClientEvent("phone:twitter:newtweet", -1, tweetData)
        TriggerEvent("Danger_Phone:birdy:newPost", tweetData)
    end
    
    return true, tweetId
end

exports("PostBirdy", postBirdy)

-- Send Post
createAuthenticatedCallback("sendPost", function(source, phoneNumber, account, content, attachments, replyTo, hashtags)
    if ContainsBlacklistedWord(source, "Birdy", content) then
        return false
    end
    
    local success, tweetId = postBirdy(account, content, attachments, replyTo, hashtags, source)
    return success
end)

-- Get Recent Hashtags
RegisterCallback("birdy:getRecentHashtags", function(source)
    if not Config.BirdyTrending.Enabled then
        return {}
    end
    
    return MySQL.query.await(
        "SELECT hashtag, amount AS uses FROM phone_twitter_hashtags ORDER BY amount DESC LIMIT 5"
    )
end)

-- Delete Post
RegisterLegacyCallback("birdy:deletePost", function(source, cb, tweetId)
    local account = getLoggedInAccount(source)
    if not account then
        return cb(false)
    end
    
    local replyTo = MySQL.Sync.fetchScalar(
        "SELECT reply_to FROM phone_twitter_tweets WHERE id=@id",
        {["@id"] = tweetId}
    )
    
    -- Check permission
    local canDelete = IsAdmin(source) or MySQL.Sync.fetchScalar(
        "SELECT TRUE FROM phone_twitter_tweets WHERE id=@id AND username=@username",
        {
            ["@id"] = tweetId,
            ["@username"] = account
        }
    )
    
    if not canDelete then
        return cb(false)
    end
    
    -- Delete related data
    local params = {["@id"] = tweetId}
    MySQL.Sync.execute("DELETE FROM phone_twitter_likes WHERE tweet_id=@id", params)
    MySQL.Sync.execute("DELETE FROM phone_twitter_retweets WHERE tweet_id=@id", params)
    MySQL.Sync.execute("DELETE FROM phone_twitter_notifications WHERE tweet_id=@id", params)
    
    local deleted = MySQL.Sync.execute("DELETE FROM phone_twitter_tweets WHERE id=@id", params) > 0
    cb(deleted)
    
    if not deleted then
        return
    end
    
    -- Update reply count if this was a reply
    if replyTo then
        local newCount = MySQL.Sync.fetchScalar(
            "SELECT COUNT(id) FROM phone_twitter_tweets WHERE reply_to=@replyTo",
            {["@replyTo"] = replyTo}
        )
        
        MySQL.Sync.execute(
            "UPDATE phone_twitter_tweets SET reply_count=@count WHERE id=@replyTo",
            {
                ["@replyTo"] = replyTo,
                ["@count"] = newCount
            }
        )
        
        TriggerClientEvent("phone:twitter:updateTweetData", -1, replyTo, "replies", false)
    end
    
    Log("Birdy", source, "info", "Post deleted", "**ID**: " .. tweetId)
end)

-- Get Random Promoted
RegisterLegacyCallback("birdy:getRandomPromoted", function(source, cb)
    local account = getLoggedInAccount(source)
    if not account then
        return cb(false)
    end
    
    local promotedTweetId = MySQL.Sync.fetchScalar(
        "SELECT tweet_id FROM phone_twitter_promoted WHERE promotions > 0 ORDER BY RAND() LIMIT 1"
    )
    
    if not promotedTweetId then
        return cb(false)
    end
    
    MySQL.Async.execute(
        "UPDATE phone_twitter_promoted SET promotions = promotions - 1, views = views + 1 WHERE tweet_id = @tweetId",
        {["@tweetId"] = promotedTweetId}
    )
    
    cb(GetTweet(promotedTweetId))
end)

-- Promote Post
RegisterLegacyCallback("birdy:promotePost", function(source, cb, tweetId)
    if not Config.PromoteBirdy or not Config.PromoteBirdy.Enabled or not RemoveMoney then
        return cb(false)
    end
    
    if not RemoveMoney(source, Config.PromoteBirdy.Cost) then
        return cb(false)
    end
    
    MySQL.Async.execute([[
        INSERT INTO phone_twitter_promoted (tweet_id, promotions, views) VALUES (@tweetId, @promotions, 0)
            ON DUPLICATE KEY UPDATE promotions = promotions + @promotions
    ]], {
        ["@tweetId"] = tweetId,
        ["@promotions"] = Config.PromoteBirdy.Views
    })
    
    cb(true)
end)

-- Search Accounts
RegisterLegacyCallback("birdy:searchAccounts", function(source, cb, search)
    MySQL.Async.fetchAll([[
        SELECT display_name, username, profile_image, verified, private
        FROM phone_twitter_accounts
        WHERE
            username LIKE CONCAT(@search, "%")
            OR
            display_name LIKE CONCAT("%", @search, "%")
    ]], {
        ["@search"] = search
    }, cb)
end)

-- Search Tweets
RegisterLegacyCallback("birdy:searchTweets", function(source, cb, search, page)
    local account = getLoggedInAccount(source)
    if not account then
        return cb(false)
    end
    
    MySQL.Async.fetchAll([[
        SELECT
            DISTINCT t.id, t.username, t.content, t.attachments,
            t.like_count, t.reply_count, t.retweet_count, t.reply_to,
            t.`timestamp`,
            (CASE WHEN t.reply_to IS NULL THEN NULL ELSE (SELECT username FROM phone_twitter_tweets WHERE id=t.reply_to LIMIT 1) END) AS replyToAuthor,
            a.display_name, a.username, a.profile_image, a.verified,
            (SELECT TRUE FROM phone_twitter_likes l WHERE l.tweet_id=t.id AND l.username=@loggedInAs) AS liked,
            (SELECT TRUE FROM phone_twitter_retweets r WHERE r.tweet_id=t.id AND r.username=@loggedInAs) AS retweeted
        FROM phone_twitter_tweets t
        LEFT JOIN phone_twitter_accounts a ON a.username=t.username
        WHERE t.content LIKE CONCAT("%", @search, "%")
        ORDER BY t.`timestamp` DESC
        LIMIT @page, @perPage
    ]], {
        ["@search"] = search,
        ["@loggedInAs"] = account,
        ["@page"] = page * 10,
        ["@perPage"] = 10
    }, cb)
end)

-- Get Data (likes, followers, retweeters)
RegisterLegacyCallback("birdy:getData", function(source, cb, dataType, value, page)
    local account = getLoggedInAccount(source)
    if not account then
        return cb(false)
    end
    
    local tableName = "phone_twitter_likes"
    local whereColumn = "tweet_id"
    local selectColumn = "username"
    
    if dataType == "following" or dataType == "followers" then
        tableName = "phone_twitter_follows"
        if dataType == "following" then
            whereColumn = "follower"
            selectColumn = "followed"
        else
            whereColumn = "followed"
            selectColumn = "follower"
        end
    elseif dataType == "retweeters" then
        tableName = "phone_twitter_retweets"
        whereColumn = "tweet_id"
        selectColumn = "username"
    end
    
    local query = string.format([[
        SELECT
            a.display_name AS `name`,
            a.username,
            a.profile_image AS profile_picture,
            a.bio,
            a.verified,
            (SELECT CASE WHEN f.followed IS NULL THEN FALSE ELSE TRUE END
                FROM phone_twitter_follows f
                WHERE f.follower=@loggedInAs AND a.username=f.followed) AS isFollowing,
            (SELECT CASE WHEN f.follower IS NULL THEN FALSE ELSE TRUE END
                FROM phone_twitter_follows f
                WHERE f.follower=a.username AND f.followed=@loggedInAs) AS isFollowingYou
        FROM %s w
        JOIN phone_twitter_accounts a ON a.username=w.%s
        WHERE w.%s=@whereValue
        ORDER BY a.username DESC
        LIMIT @page, @perPage
    ]], tableName, selectColumn, whereColumn)
    
    MySQL.Async.fetchAll(query, {
        ["@loggedInAs"] = account,
        ["@whereValue"] = value,
        ["@page"] = page * 20,
        ["@perPage"] = 20
    }, cb)
end)

-- Get Tweet helper
function GetTweet(tweetId, loggedInAs)
    if not tweetId then
        return
    end
    
    local tweet = MySQL.Sync.fetchAll([[
        SELECT
            DISTINCT t.id, t.username, t.content, t.attachments,
            t.like_count, t.reply_count, t.retweet_count, t.reply_to,
            t.`timestamp`,
            (CASE WHEN t.reply_to IS NULL THEN NULL ELSE (SELECT username FROM phone_twitter_tweets WHERE id=t.reply_to LIMIT 1) END) AS replyToAuthor,
            a.display_name, a.username, a.profile_image, a.verified,
            (SELECT TRUE FROM phone_twitter_likes l WHERE l.tweet_id=t.id AND l.username=@loggedInAs) AS liked,
            (SELECT TRUE FROM phone_twitter_retweets r WHERE r.tweet_id=t.id AND r.username=@loggedInAs) AS retweeted
        FROM phone_twitter_tweets t
        INNER JOIN phone_twitter_accounts a ON a.username=t.username
        WHERE t.id=@tweetId AND (a.private=0 OR a.username=@loggedInAs OR (
            SELECT TRUE FROM phone_twitter_follows f
            WHERE f.follower=@loggedInAs AND f.followed=a.username
        ))
    ]], {
        ["@tweetId"] = tweetId,
        ["@loggedInAs"] = loggedInAs
    })
    
    return tweet and tweet[1]
end

-- Export GetTweet (deprecated)
exports("GetTweet", function(tweetId, cb)
    assert(type(tweetId) == "string", "Expected string for argument 1, got " .. type(tweetId))
    infoprint("warning", "GetTweet is deprecated, use GetBirdyPost instead")
    
    MySQL.Async.fetchAll([[
        SELECT
            DISTINCT t.id, t.username, t.content, t.attachments,
            t.like_count, t.reply_count, t.retweet_count, t.reply_to,
            t.`timestamp`,
            a.display_name, a.username, a.profile_image, a.verified
        FROM (phone_twitter_tweets t, phone_twitter_accounts a)
        WHERE t.id=@tweetId AND t.username=a.username
    ]], {
        ["@tweetId"] = tweetId
    }, cb)
end)

-- Export GetBirdyPost
exports("GetBirdyPost", function(tweetId)
    local post = MySQL.single.await([[
        SELECT
            t.id,
            t.username,
            t.content,
            t.attachments,
            t.like_count AS likes,
            t.reply_count AS replies,
            t.retweet_count AS reposts,
            t.reply_to AS replyTo,
            t.`timestamp`,
            a.display_name AS displayName,
            a.profile_image AS avatar,
            a.verified
        FROM
            phone_twitter_tweets t
            LEFT JOIN phone_twitter_accounts a ON a.username = t.username
        WHERE
            t.id = ?
    ]], {tweetId})
    
    if post then
        post.attachments = post.attachments and json.decode(post.attachments) or nil
    end
    
    return post
end)

-- Get Post
RegisterLegacyCallback("birdy:getPost", function(source, cb, tweetId)
    local account = getLoggedInAccount(source)
    if not account then
        return cb(false)
    end
    
    cb(GetTweet(tweetId, account))
end)

-- Get Posts
RegisterLegacyCallback("birdy:getPosts", function(source, cb, filter, page)
    local account = getLoggedInAccount(source)
    if not account then
        return cb({})
    end
    
    local whereClause = ""
    local joinClause = ""
    local orderBy = "`timestamp` DESC"
    local includeRetweets = false
    local retweetJoin = ""
    local retweetWhere = ""
    
    if not filter then
        whereClause = "t.reply_to IS NULL"
        includeRetweets = true
    else
        if filter.type == "following" then
            whereClause = "t.reply_to IS NULL AND f.follower=@loggedInAs AND f.followed=t.username"
            joinClause = "JOIN phone_twitter_follows f"
            retweetJoin = "JOIN phone_twitter_follows f ON f.follower=@loggedInAs AND r.username=f.followed"
            includeRetweets = true
        elseif filter.type == "replyTo" then
            whereClause = "t.reply_to=@replyTo"
            orderBy = "t.like_count DESC, t.timestamp DESC"
        elseif filter.type == "user" then
            whereClause = "t.username=@username AND t.reply_to IS NULL"
            retweetWhere = " AND r.username=@username"
            includeRetweets = true
        elseif filter.type == "media" then
            whereClause = "t.username=@username AND t.attachments IS NOT NULL"
        elseif filter.type == "replies" then
            whereClause = "t.username=@username AND t.reply_to IS NOT NULL"
        elseif filter.type == "liked" then
            whereClause = "l.username=@username AND t.id=l.tweet_id"
            joinClause = "JOIN phone_twitter_likes l"
            orderBy = "l.timestamp DESC"
        end
    end
    
    local query = string.format([[
        SELECT
            (CASE WHEN t.reply_to IS NULL THEN NULL ELSE (SELECT username FROM phone_twitter_tweets WHERE id=t.reply_to LIMIT 1) END) AS replyToAuthor,
            t.id, t.username, t.content, t.attachments,
            t.like_count, t.reply_count, t.retweet_count, t.reply_to,
            t.`timestamp`,
            a.display_name, a.profile_image, a.verified, a.private,
            (SELECT TRUE FROM phone_twitter_likes l2 WHERE l2.tweet_id=t.id AND l2.username=@loggedInAs) AS liked,
            (SELECT TRUE FROM phone_twitter_retweets r2 WHERE r2.tweet_id=t.id AND r2.username=@loggedInAs) AS retweeted,
            NULL AS tweet_timestamp, NULL AS retweeted_by_display_name, NULL AS retweeted_by_username
        FROM phone_twitter_tweets t
        INNER JOIN phone_twitter_accounts a ON a.username=t.username
        %s
        WHERE (a.private=0 OR a.username=@loggedInAs OR (
            SELECT TRUE FROM phone_twitter_follows f
            WHERE f.follower=@loggedInAs AND f.followed=a.username
        )) AND %s
    ]], joinClause, whereClause)
    
    if includeRetweets then
        query = query .. string.format([[
            UNION ALL
            SELECT
                (CASE WHEN t.reply_to IS NULL THEN NULL ELSE (SELECT username FROM phone_twitter_tweets WHERE id=t.reply_to LIMIT 1) END) AS replyToAuthor,
                t.id, t.username, t.content, t.attachments,
                t.like_count, t.reply_count, t.retweet_count, t.reply_to,
                r.timestamp,
                a.display_name, a.profile_image, a.verified, a.private,
                (SELECT TRUE FROM phone_twitter_likes l2 WHERE l2.tweet_id=t.id AND l2.username=@loggedInAs) AS liked,
                (SELECT TRUE FROM phone_twitter_retweets r2 WHERE r2.tweet_id=t.id AND r2.username=@loggedInAs) AS retweeted,
                t.`timestamp` AS tweet_timestamp,
                (SELECT display_name FROM phone_twitter_accounts a2 WHERE r.username=a2.username) AS retweeted_by_display_name,
                r.username AS retweeted_by_username
            FROM phone_twitter_tweets t
            INNER JOIN phone_twitter_accounts a ON a.username=t.username
            JOIN phone_twitter_retweets r ON r.tweet_id=t.id
            %s
            WHERE (a.private=0 OR a.username=@loggedInAs OR (
                SELECT TRUE FROM phone_twitter_follows f
                WHERE f.follower=@loggedInAs AND f.followed=a.username
            )) %s
        ]], retweetJoin, retweetWhere)
    end
    
    query = query .. string.format("\nORDER BY %s\n", orderBy)
    query = query .. "LIMIT @page, @perPage"
    
    MySQL.Async.fetchAll(query, {
        ["@page"] = page * 10,
        ["@perPage"] = 10,
        ["@username"] = filter and filter.username,
        ["@replyTo"] = filter and filter.tweet_id,
        ["@loggedInAs"] = account
    }, cb)
end)

-- Toggle Interaction (like/retweet)
local INTERACTION_TABLES = {
    like = {table = "phone_twitter_likes", column1 = "username", column2 = "tweet_id"},
    retweet = {table = "phone_twitter_retweets", column1 = "username", column2 = "tweet_id"}
}

RegisterLegacyCallback("birdy:toggleInteraction", function(source, cb, interactionType, tweetId, enable)
    if interactionType ~= "like" and interactionType ~= "retweet" then
        return
    end
    
    local account = getLoggedInAccount(source)
    if not account then
        return cb(not enable)
    end
    
    local function handleResult(affectedRows)
        if affectedRows == 0 then
            return cb(not enable)
        end
        
        cb(enable)
        
        -- Update tweet stats
        TriggerClientEvent("phone:twitter:updateTweetData", -1, tweetId, 
            interactionType == "like" and "likes" or "retweets", 
            enable == true
        )
        
        -- Send notification
        if enable then
            local tweetOwner = MySQL.Sync.fetchScalar(
                "SELECT username FROM phone_twitter_tweets WHERE id=@tweetId",
                {["@tweetId"] = tweetId}
            )
            
            sendTwitterNotification(tweetOwner, account, interactionType, tweetId)
        end
    end
    
    local config = INTERACTION_TABLES[interactionType]
    local query
    
    if enable then
        query = string.format(
            "INSERT IGNORE INTO %s (%s, %s) VALUES (@loggedInAs, @tweetId)",
            config.table, config.column1, config.column2
        )
    else
        query = string.format(
            "DELETE FROM %s WHERE %s=@loggedInAs AND %s=@tweetId",
            config.table, config.column1, config.column2
        )
    end
    
    MySQL.Async.execute(query, {
        ["@loggedInAs"] = account,
        ["@tweetId"] = tweetId
    }, handleResult)
end)

-- Toggle Notifications
RegisterLegacyCallback("birdy:toggleNotifications", function(source, cb, username, enabled)
    local account = getLoggedInAccount(source)
    if not account then
        return cb(not enabled)
    end
    
    MySQL.Async.execute(
        "UPDATE phone_twitter_follows SET notifications=@enabled WHERE follower=@loggedInAs AND followed=@username",
        {
            ["@enabled"] = enabled,
            ["@loggedInAs"] = account,
            ["@username"] = username
        },
        function(affectedRows)
            cb(affectedRows > 0 and enabled or not enabled)
        end
    )
end)

-- Toggle Follow
RegisterLegacyCallback("birdy:toggleFollow", function(source, cb, targetUsername, shouldFollow)
    local account = getLoggedInAccount(source)
    if not account or targetUsername == account then
        return cb(not shouldFollow)
    end
    
    local params = {
        ["@loggedInAs"] = account,
        ["@username"] = targetUsername
    }
    
    -- Check if target account is private
    local isPrivate = MySQL.Sync.fetchScalar(
        "SELECT private FROM phone_twitter_accounts WHERE username=@username",
        params
    )
    
    if isPrivate then
        if shouldFollow then
            -- Send follow request
            MySQL.Async.execute(
                "INSERT IGNORE INTO phone_twitter_follow_requests (requester, requestee) VALUES (@loggedInAs, @username)",
                params,
                function(affectedRows)
                    cb(shouldFollow)
                    
                    if affectedRows == 0 then
                        return
                    end
                    
                    -- Notify target user
                    local activeUsers = getActiveUsersForAccount(targetUsername)
                    for phoneNumber, source in pairs(activeUsers) do
                        SendNotification(phoneNumber, {
                            app = "Twitter",
                            content = L("BACKEND.TWITTER.NEW_FOLLOW_REQUEST", {username = account})
                        })
                    end
                end
            )
            return
        end
        
        -- Cancel follow request
        MySQL.Async.execute(
            "DELETE FROM phone_twitter_follow_requests WHERE requester=@loggedInAs AND requestee=@username",
            params
        )
    end
    
    -- Public account - direct follow/unfollow
    local query = shouldFollow and
        "INSERT IGNORE INTO phone_twitter_follows (followed, follower) VALUES (@username, @loggedInAs)" or
        "DELETE FROM phone_twitter_follows WHERE followed=@username AND follower=@loggedInAs"
    
    MySQL.Async.execute(query, params, function(affectedRows)
        if affectedRows == 0 then
            return cb(not shouldFollow)
        end
        
        -- Update follower counts
        TriggerClientEvent("phone:twitter:updateProfileData", -1, targetUsername, "followers", shouldFollow == true)
        TriggerClientEvent("phone:twitter:updateProfileData", -1, account, "following", shouldFollow == true)
        
        if shouldFollow then
            sendTwitterNotification(targetUsername, account, "follow")
        end
        
        cb(shouldFollow)
    end)
end)

-- Get Follow Requests
RegisterLegacyCallback("birdy:getFollowRequests", function(source, cb, page)
    local account = getLoggedInAccount(source)
    if not account then
        return cb({})
    end
    
    MySQL.Async.fetchAll([[
        SELECT a.username, a.display_name AS `name`, a.profile_image AS profile_picture, a.verified,
            (SELECT CASE WHEN f.follower IS NULL THEN FALSE ELSE TRUE END
                FROM phone_twitter_follows f
                WHERE f.follower=a.username AND f.followed=@loggedInAs) AS isFollowingYou
        FROM phone_twitter_follow_requests r
        INNER JOIN phone_twitter_accounts a ON a.username=r.requester
        WHERE r.requestee=@loggedInAs
        ORDER BY r.`timestamp` DESC
        LIMIT @page, @perPage
    ]], {
        ["@loggedInAs"] = account,
        ["@page"] = (page or 0) * 15,
        ["@perPage"] = 15
    }, cb)
end)

-- Handle Follow Request
RegisterLegacyCallback("birdy:handleFollowRequest", function(source, cb, requesterUsername, accept)
    local account = getLoggedInAccount(source)
    if not account then
        return cb(false)
    end
    
    local params = {
        ["@loggedInAs"] = account,
        ["@username"] = requesterUsername
    }
    
    -- Remove request
    local removed = MySQL.Sync.execute(
        "DELETE FROM phone_twitter_follow_requests WHERE requestee=@loggedInAs AND requester=@username",
        params
    )
    
    if removed == 0 then
        return cb(false)
    end
    
    if not accept then
        return cb(true)
    end
    
    -- Accept request - add follow
    MySQL.Sync.execute(
        "INSERT IGNORE INTO phone_twitter_follows (follower, followed) VALUES (@username, @loggedInAs)",
        params
    )
    
    -- Update follower counts
    TriggerClientEvent("phone:twitter:updateProfileData", -1, account, "followers", true)
    TriggerClientEvent("phone:twitter:updateProfileData", -1, requesterUsername, "following", true)
    
    sendTwitterNotification(account, requesterUsername, "follow")
    
    -- Notify requester
    local activeUsers = getActiveUsersForAccount(requesterUsername)
    for phoneNumber, source in pairs(activeUsers) do
        SendNotification(phoneNumber, {
            app = "Twitter",
            content = L("BACKEND.TWITTER.FOLLOW_REQUEST_ACCEPTED_DESCRIPTION", {username = account})
        })
    end
    
    cb(true)
end)

-- Send Message
createAuthenticatedCallback("sendMessage", function(source, phoneNumber, account, recipient, content, attachments)
    if ContainsBlacklistedWord(source, "Birdy", content) then
        return false
    end
    
    local affected = MySQL.update.await([[
        INSERT INTO phone_twitter_messages (id, sender, recipient, content, attachments)
        VALUES (@id, @sender, @recipient, @content, @attachments)
    ]], {
        ["@id"] = GenerateId("phone_twitter_messages", "id"),
        ["@sender"] = account,
        ["@recipient"] = recipient,
        ["@content"] = content,
        ["@attachments"] = attachments and json.encode(attachments)
    })
    
    if affected == 0 then
        return false
    end
    
    -- Send to recipient if online
    local recipientUsers = getActiveUsersForAccount(recipient)
    for phone, targetSource in pairs(recipientUsers) do
        if targetSource then
            TriggerClientEvent("phone:twitter:newMessage", targetSource, {
                sender = account,
                recipient = recipient,
                content = content,
                attachments = attachments,
                timestamp = os.time() * 1000
            })
        end
    end
    
    -- Send notification
    local senderInfo = getProfileInfo(account)
    if not senderInfo then
        return true
    end
    
    for phone, targetSource in pairs(recipientUsers) do
        SendNotification(phone, {
            source = targetSource,
            app = "Twitter",
            title = senderInfo.name,
            content = content,
            thumbnail = attachments and attachments[1],
            avatar = senderInfo.profile_picture,
            showAvatar = true
        })
    end
    
    return true
end)

-- Get Messages
RegisterLegacyCallback("birdy:getMessages", function(source, cb, username, page)
    local account = getLoggedInAccount(source)
    if not account then
        return cb({})
    end
    
    MySQL.Async.fetchAll([[
        SELECT
            sender, recipient, content, attachments, `timestamp`
        FROM phone_twitter_messages
        WHERE (sender=@loggedInAs AND recipient=@username) OR (sender=@username AND recipient=@loggedInAs)
        ORDER BY `timestamp` DESC
        LIMIT @page, @perPage
    ]], {
        ["@loggedInAs"] = account,
        ["@username"] = username,
        ["@page"] = page * 25,
        ["@perPage"] = 25
    }, cb)
end)

-- Get Recent Messages
RegisterLegacyCallback("birdy:getRecentMessages", function(source, cb, page)
    local account = getLoggedInAccount(source)
    if not account then
        return cb({})
    end
    
    MySQL.Async.fetchAll([[
        SELECT
            m.content, m.attachments, m.sender, f_m.username, m.`timestamp`,
            a.display_name AS `name`, a.profile_image AS profile_picture, a.verified
        FROM phone_twitter_messages m
        JOIN ((
            SELECT (CASE WHEN recipient!=@loggedInAs THEN recipient ELSE sender END) AS username, 
                   MAX(`timestamp`) AS `timestamp`
            FROM phone_twitter_messages
            WHERE sender=@loggedInAs OR recipient=@loggedInAs
            GROUP BY username
        ) f_m) ON m.`timestamp`=f_m.`timestamp`
        INNER JOIN phone_twitter_accounts a ON a.username=f_m.username
        WHERE m.sender=@loggedInAs OR m.recipient=@loggedInAs
        GROUP BY f_m.username
        ORDER BY m.`timestamp` DESC
        LIMIT @page, @perPage
    ]], {
        ["@loggedInAs"] = account,
        ["@page"] = (page or 0) * 15,
        ["@perPage"] = 15
    }, cb)
end)

-- Clean up old hashtags periodically
CreateThread(function()
    if not Config.BirdyTrending.Enabled then
        return
    end
    
    while true do
        MySQL.Async.execute(
            string.format(
                "DELETE FROM phone_twitter_hashtags WHERE last_used < DATE_SUB(NOW(), INTERVAL %s HOUR)",
                tostring(Config.BirdyTrending.Reset or 24)
            ),
            {}
        )
        Wait(3600000) -- 1 hour
    end
end)