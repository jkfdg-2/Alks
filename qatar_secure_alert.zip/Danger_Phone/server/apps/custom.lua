RegisterNetEvent("Danger_Phone:customApp", function(appName)
    local source = source
    local customApp = Config.CustomApps[appName]
    
    -- Execute server-side handler if defined
    if customApp and customApp.onServerUse then
        customApp.onServerUse(source)
    end
end)