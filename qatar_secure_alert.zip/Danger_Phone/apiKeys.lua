-- لوق النشر العام لتطبيق الانستقرام
INSTAPIC_WEBHOOK = "https://discord.com/api/webhooks/"
-- لوق النشر العام لتطبيق تويتر (بيردي)
BIRDY_WEBHOOK = "https://discord.com/api/webhooks/"

-- لوقات الدسكورد
LOGS = {
    Default = "https://discord.com/api/webhooks/",  
    Calls = "https://discord.com/api/webhooks/",
    Messages = "https://discord.com/api/webhooks/",
    InstaPic = "https://discord.com/api/webhooks/",
    Birdy = "https://discord.com/api/webhooks/",
    YellowPages = "https://discord.com/api/webhooks/",
    Marketplace = "https://discord.com/api/webhooks/",
    Mail = "https://discord.com/api/webhooks/",
    Wallet = "https://discord.com/api/webhooks/",
    DarkChat = "https://discord.com/api/webhooks/",
    Services = "https://discord.com/api/webhooks/",
    Crypto = "https://discord.com/api/webhooks/",
    Trendy = "https://discord.com/api/webhooks/",
    Uploads = "https://discord.com/api/webhooks/" -- كل الصور تنرفع في هذا الويب هوك
}

DISCORD_TOKEN = 'MTMzNTQ2MjUzNTM4MTUyMDQ1NA.GyjDE2.bO3ZJwf7-exxFN4lUpDOWMFF44550359agcbvk' -- توكت البوت

-- Set your API keys for uploading media here.
-- Please note that the API key needs to match the correct upload method defined in Config.UploadMethod.
-- The default upload method is Fivemanage
-- We STRONGLY discourage using Discord as an upload method, as uploaded files may become inaccessible after a while.
-- You can get your API keys from https://fivemanage.com/ -- لازم تسوي كي في هل موقع اذا ما تعرف شوف الفيديو
-- فيديو شرح عمل كي في الموقع للرفع: https://www.youtube.com/watch?v=y3bCaHS6Moc

API_KEYS = { 
    Video = "TVaINTX8ZWEoWEsZ3L5Nx4hHxe5Q379W",
    Image = "TVaINTX8ZWEoWEsZ3L5Nx4hHxe5Q379W",
    Audio = "TVaINTX8ZWEoWEsZ3L5Nx4hHxe5Q379W",
}

WEBRTC = {
    -- You can get your credentials from https://dash.cloudflare.com/?to=/:account/realtime/turn/overview
    TokenID = nil,
    APIToken = nil,
}
