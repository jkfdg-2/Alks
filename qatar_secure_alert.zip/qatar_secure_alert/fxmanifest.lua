fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'qatar_secure_alert'
author 'Qatar Secure Alert'
description 'In-game security alert & simulation system with iPhone-style NUI phone and admin panel (Standalone / QBCore / ESX)'
version '1.0.0'

ui_page 'html/index.html'

shared_scripts {
    'config.lua',
    'locales/ar.lua',
    'locales/en.lua',
    'shared/utils.lua',
}

client_scripts {
    'client/phone/adapter.lua',
    'client/phone/integrations/*.lua',
    'client/nui.lua',
    'client/alerts.lua',
    'client/main.lua',
}

-- oxmysql is OPTIONAL: it is detected at runtime (see Config.Database), so it is not listed in dependencies.
server_scripts {
    'server/database.lua',
    'server/permissions.lua',
    'server/logs.lua',
    'server/regions.lua',
    'server/alerts.lua',
    'server/main.lua',
}

files {
    'html/index.html',
    'html/style.css',
    'html/app.js',
}
