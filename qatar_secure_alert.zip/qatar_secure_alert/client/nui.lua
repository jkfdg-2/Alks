QSA = QSA or {}
QSA.C = QSA.C or {
    active = {},        -- id -> { type, coords, radius, region, endsAt, token }
    history = {},       -- newest first (يُحفظ في KVP)
    historyIndex = {},  -- id -> entry
    blips = {},         -- id -> { center, radius }
    silenced = {},      -- id -> true
    phoneOpen = false,
    panelOpen = false,
    emergencyLoop = false,
}
local C = QSA.C

function C.Send(msg)
    SendNUIMessage(msg)
end

-- ───────── Init (لغة + ألوان + إعدادات) ─────────
function C.SendInit()
    local lang = Locales[Config.Language] and Config.Language or 'en'
    local strings = Locales[lang]
    C.Send({
        action = 'init',
        lang = lang,
        rtl = strings.__rtl == true,
        dateLocale = strings.__dateLocale or 'en-GB',
        strings = strings,
        types = Config.Types,
        ui = {
            bannerMs = Config.UI.bannerMs,
            emergencySticky = Config.UI.emergencySticky,
            showUnreadBadge = Config.UI.showUnreadBadge,
        },
    })
end

-- ───────── الهاتف ─────────
function C.OpenPhone()
    if C.panelOpen then return end
    if not C.phoneOpen then
        C.phoneOpen = true
        SetNuiFocus(true, true)
    end
    C.Send({ action = 'phone', show = true })
    C.PushAlerts()
    C.Dismiss() -- فتح الهاتف = إيقاف صوت/إشعارات Emergency
end

function C.ClosePhone()
    if not C.phoneOpen then return end
    C.phoneOpen = false
    SetNuiFocus(false, false)
    C.Send({ action = 'phone', show = false })
end

-- ───────── لوحة التحكم ─────────
function C.OpenPanel(data)
    if C.panelOpen then
        C.Send({ action = 'panelData', data = data })
        return
    end
    if C.phoneOpen then C.ClosePhone() end
    C.panelOpen = true
    SetNuiFocus(true, true)
    C.Send({ action = 'panel', show = true, data = data })
end

function C.ClosePanel(fromServer)
    if not C.panelOpen then return end
    C.panelOpen = false
    SetNuiFocus(false, false)
    C.Send({ action = 'panel', show = false })
    if not fromServer then TriggerServerEvent('qatar_secure_alert:server:panelClose') end
end

-- ───────── NUI Callbacks ─────────
RegisterNUICallback('ready', function(_, cb)
    C.nuiReady = true
    C.SendInit()
    C.PushAlerts()
    cb('ok')
end)

RegisterNUICallback('closePhone', function(_, cb)
    C.ClosePhone()
    cb('ok')
end)

RegisterNUICallback('closePanel', function(_, cb)
    C.ClosePanel(false)
    cb('ok')
end)

RegisterNUICallback('markRead', function(data, cb)
    if type(data) == 'table' and type(data.id) == 'string' then C.MarkRead(data.id) end
    cb('ok')
end)

RegisterNUICallback('markAllRead', function(_, cb)
    C.MarkAllRead()
    cb('ok')
end)

RegisterNUICallback('clearHistory', function(_, cb)
    C.ClearHistory()
    cb('ok')
end)

RegisterNUICallback('dismissBanners', function(_, cb)
    C.Dismiss()
    cb('ok')
end)

RegisterNUICallback('panelAction', function(data, cb)
    if type(data) == 'table' and type(data.action) == 'string' then
        TriggerServerEvent('qatar_secure_alert:server:panelAction', data.action, type(data.payload) == 'table' and data.payload or {})
    end
    cb('ok')
end)

RegisterNUICallback('getMyCoords', function(_, cb)
    local c = GetEntityCoords(PlayerPedId())
    cb({ x = c.x, y = c.y, z = c.z })
end)
