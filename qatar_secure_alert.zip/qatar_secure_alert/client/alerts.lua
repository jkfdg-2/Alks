QSA = QSA or {}
local C = QSA.C
local KVP_HISTORY = 'qsa_history_v1'

-- ═════════════ السجل المحلي (لكل لاعب) ═════════════
local savePending = false
local function saveHistory()
    if savePending then return end
    savePending = true
    SetTimeout(500, function()
        savePending = false
        local slim = {}
        for i, e in ipairs(C.history) do
            slim[i] = {
                id = e.id, title = e.title, message = e.message, type = e.type, region = e.region,
                created_at = e.created_at, expires_at = e.expires_at, simulation = e.simulation,
                read = e.read, status = e.status,
            }
        end
        SetResourceKvp(KVP_HISTORY, json.encode(slim))
    end)
end

local function loadHistory()
    local raw = GetResourceKvpString(KVP_HISTORY)
    if not raw or raw == '' then return end
    local ok, list = pcall(json.decode, raw)
    if not ok or type(list) ~= 'table' then return end
    for _, e in ipairs(list) do
        if type(e) == 'table' and type(e.id) == 'string' and not C.historyIndex[e.id] then
            if e.status == 'active' then e.status = 'expired' end -- سيعيد السيرفر تفعيلها عند المزامنة إن كانت ما زالت نشطة
            C.history[#C.history + 1] = e
            C.historyIndex[e.id] = e
        end
    end
end

local function trimHistory()
    local limit = Config.UI.historyLimit or 50
    while #C.history > limit do
        local old = table.remove(C.history)
        C.historyIndex[old.id] = nil
    end
end

local function str(v, max)
    if type(v) ~= 'string' then v = tostring(v or '') end
    if #v > max then v = v:sub(1, max) end
    return v
end

-- ═════════════ الواجهة ═════════════
function C.BuildUiAlerts()
    local now = GetGameTimer()
    local list = {}
    for i, e in ipairs(C.history) do
        local act = C.active[e.id]
        list[i] = {
            id = e.id, title = e.title, message = e.message, type = e.type, region = e.region,
            created_at = e.created_at, simulation = e.simulation == true, read = e.read == true,
            status = act and 'active' or (e.status == 'cleared' and 'cleared' or 'expired'),
            remaining = act and math.max(0, math.floor((act.endsAt - now) / 1000)) or nil,
        }
    end
    return list
end

function C.PushAlerts()
    if not C.nuiReady then return end
    C.Send({ action = 'alerts', alerts = C.BuildUiAlerts() })
end

function C.MarkRead(id)
    local e = C.historyIndex[id]
    if e and not e.read then
        e.read = true
        saveHistory()
        C.PushAlerts()
    end
end

function C.MarkAllRead()
    for _, e in ipairs(C.history) do e.read = true end
    saveHistory()
    C.PushAlerts()
end

function C.ClearHistory()
    local keep = {}
    local keepIndex = {}
    for _, e in ipairs(C.history) do
        if C.active[e.id] then keep[#keep + 1] = e; keepIndex[e.id] = e end
    end
    C.history, C.historyIndex = keep, keepIndex
    saveHistory()
    C.PushAlerts()
end

-- ═════════════ Blips ═════════════
local function removeBlips(id)
    local b = C.blips[id]
    if not b then return end
    if b.center and DoesBlipExist(b.center) then RemoveBlip(b.center) end
    if b.radius and DoesBlipExist(b.radius) then RemoveBlip(b.radius) end
    C.blips[id] = nil
end

local function createBlips(id, a)
    removeBlips(id)
    if not Config.EnableBlips or not a.coords then return end
    local c = a.coords
    local colour = (Config.Types[a.type] or {}).blipColour or 1
    local blips = {}

    blips.center = AddBlipForCoord(c.x + 0.0, c.y + 0.0, c.z + 0.0)
    SetBlipSprite(blips.center, Config.Blip.sprite)
    SetBlipScale(blips.center, Config.Blip.scale)
    SetBlipColour(blips.center, colour)
    SetBlipAsShortRange(blips.center, false)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentSubstringPlayerName(a.region or a.title or 'Alert')
    EndTextCommandSetBlipName(blips.center)

    if Config.EnableRadius and a.radius then
        blips.radius = AddBlipForRadius(c.x + 0.0, c.y + 0.0, c.z + 0.0, a.radius + 0.0)
        SetBlipColour(blips.radius, colour)
        SetBlipAlpha(blips.radius, Config.Blip.radiusAlpha)
    end
    C.blips[id] = blips
end

-- ═════════════ الصوت ═════════════
local function playSound(atype)
    if not Config.EnableSounds then return end
    local s = Config.Sounds[atype]
    if s then PlaySoundFrontend(-1, s.name, s.set, true) end
end

-- صوت Emergency المتكرر: Thread واحد يعمل فقط أثناء وجود Emergency نشط وغير مكتوم
local function ensureEmergencyLoop()
    if C.emergencyLoop then return end
    C.emergencyLoop = true
    CreateThread(function()
        while true do
            local any = false
            for id, a in pairs(C.active) do
                if a.type == 'emergency' and not C.silenced[id] then any = true break end
            end
            if not any then break end
            playSound('emergency')
            Wait(tonumber(Config.EmergencyRepeatInterval) or 5000)
        end
        C.emergencyLoop = false
    end)
end

-- إيقاف الصوت المتكرر وإخفاء الإشعارات المعروضة (لا يمسح الـ Badge)
function C.Dismiss()
    for id in pairs(C.active) do C.silenced[id] = true end
    C.Send({ action = 'dismissBanners' })
end

-- ═════════════ استقبال التنبيهات ═════════════
function C.Deactivate(id, reason)
    local was = C.active[id]
    C.active[id] = nil
    C.silenced[id] = nil
    removeBlips(id)
    QSA.Phone.Clear(id)
    local e = C.historyIndex[id]
    if e then e.status = (reason == 'cleared') and 'cleared' or 'expired' end
    if was then
        saveHistory()
        C.Send({ action = 'removeBanner', id = id })
        C.PushAlerts()
    end
end

function C.Receive(a)
    local atype = Config.Types[a.type] and a.type or 'information'
    local isUpdate = a.update == true
    local ttl = tonumber(a.ttl) or 0

    local entry = C.historyIndex[a.id]
    local seen = entry ~= nil
    if not entry then
        entry = { id = a.id, read = false }
        table.insert(C.history, 1, entry)
        C.historyIndex[a.id] = entry
    end
    entry.title = str(a.title, 200)
    entry.message = str(a.message, 1000)
    entry.type = atype
    entry.region = a.region and str(a.region, 100) or nil
    entry.created_at = tonumber(a.created_at) or 0
    entry.expires_at = tonumber(a.expires_at) or 0
    entry.simulation = a.simulation == true
    if isUpdate then entry.read = false end
    trimHistory()

    if ttl > 0 then
        entry.status = 'active'
        local prev = C.active[a.id]
        local token = (prev and prev.token or 0) + 1
        local coords
        if type(a.coords) == 'table' and tonumber(a.coords.x) and tonumber(a.coords.y) then
            coords = { x = tonumber(a.coords.x), y = tonumber(a.coords.y), z = tonumber(a.coords.z) or 0.0 }
        end
        C.active[a.id] = {
            type = atype, coords = coords, radius = tonumber(a.radius), region = entry.region,
            title = entry.title, endsAt = GetGameTimer() + ttl * 1000, token = token,
        }
        if not prev or isUpdate then createBlips(a.id, C.active[a.id]) end
        SetTimeout(ttl * 1000 + 300, function()
            local cur = C.active[a.id]
            if cur and cur.token == token then C.Deactivate(a.id, 'expired') end
        end)
    else
        entry.status = 'expired'
    end
    saveHistory()

    local ui = {
        id = entry.id, title = entry.title, message = entry.message, type = entry.type,
        region = entry.region, created_at = entry.created_at, simulation = entry.simulation,
        remaining = ttl > 0 and ttl or nil, update = isUpdate,
    }

    -- إشعار: للتنبيه الجديد أو التحديث فقط (إعادة المزامنة بعد إعادة التشغيل لا تعيد الصوت/الإشعار)
    if not seen or isUpdate then
        local handled = false
        if not isUpdate then
            handled = QSA.Phone.Notify({
                id = entry.id, title = entry.title, message = entry.message, type = entry.type,
                region = entry.region, coords = C.active[a.id] and C.active[a.id].coords or nil,
                radius = C.active[a.id] and C.active[a.id].radius or nil,
                simulation = entry.simulation, remaining = ttl,
            })
        end
        if not handled or Config.ShowBuiltInBannerWithExternalPhone then
            C.Send({ action = 'notify', alert = ui })
        end
        if not isUpdate and ttl > 0 then
            C.silenced[a.id] = nil
            if atype == 'emergency' and Config.EmergencyRepeatSound then
                ensureEmergencyLoop()
            else
                playSound(atype)
            end
        elseif not isUpdate then
            playSound(atype)
        end
    end
    C.PushAlerts()
end

RegisterNetEvent('qatar_secure_alert:client:receiveAlert', function(a)
    if type(a) ~= 'table' or type(a.id) ~= 'string' or #a.id > 64 then return end
    if type(a.message) ~= 'string' then return end
    C.Receive(a)
end)

RegisterNetEvent('qatar_secure_alert:client:clearAlert', function(id, reason)
    if type(id) ~= 'string' then return end
    C.Deactivate(id, reason)
end)

RegisterNetEvent('qatar_secure_alert:client:feedback', function(r)
    if type(r) ~= 'table' then return end
    C.Send({ action = 'toast', ok = r.ok == true, msg = tostring(r.msg or '') })
end)

-- ═════════════ Exports (كلاينت) ═════════════
-- exports["qatar_secure_alert"]:IsPlayerInAlertZone() -> boolean, alertId|nil
exports('IsPlayerInAlertZone', function()
    local p = GetEntityCoords(PlayerPedId())
    for id, a in pairs(C.active) do
        if a.coords and a.radius then
            local dx, dy = p.x - a.coords.x, p.y - a.coords.y
            if math.sqrt(dx * dx + dy * dy) <= a.radius then return true, id end
        end
    end
    return false
end)

-- exports["qatar_secure_alert"]:GetActiveAlerts() -> array (التنبيهات النشطة عند هذا اللاعب)
exports('GetActiveAlerts', function()
    local out = {}
    for id, a in pairs(C.active) do
        local e = C.historyIndex[id]
        out[#out + 1] = {
            id = id, type = a.type, title = a.title, region = a.region, radius = a.radius,
            coords = a.coords, message = e and e.message or '',
        }
    end
    return out
end)

-- ═════════════ تنظيف عند إيقاف الـ Resource ═════════════
AddEventHandler('onResourceStop', function(res)
    if res ~= GetCurrentResourceName() then return end
    for id in pairs(C.blips) do removeBlips(id) end
    if C.phoneOpen or C.panelOpen then SetNuiFocus(false, false) end
end)

loadHistory()
