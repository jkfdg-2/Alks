QSA = QSA or {}
local C = QSA.C
local EVT = 'qatar_secure_alert:'

-- ═════════════ أوامر الكلاينت ═════════════
-- /alertphone : فتح هاتف التنبيهات (NUI)
RegisterCommand('alertphone', function()
    if C.phoneOpen then C.ClosePhone() else C.OpenPhone() end
end, false)

-- /dismissalert : إخفاء الإشعارات وإيقاف صوت Emergency المتكرر
RegisterCommand('dismissalert', function()
    C.Dismiss()
end, false)

local function mapKey(command, description, key)
    if type(key) == 'string' and key ~= '' then
        RegisterKeyMapping(command, description, 'keyboard', key)
    end
end
mapKey('alertphone', 'Secure Alert: open phone', Config.Keys.phone)
mapKey('dismissalert', 'Secure Alert: dismiss alert', Config.Keys.dismiss)
mapKey('alertpanel', 'Secure Alert: admin panel', Config.Keys.panel)

-- ═════════════ أحداث لوحة التحكم (من السيرفر فقط) ═════════════
RegisterNetEvent(EVT .. 'client:openPanel', function(data)
    if type(data) ~= 'table' then return end
    C.OpenPanel(data)
end)

RegisterNetEvent(EVT .. 'client:panelData', function(data)
    if type(data) ~= 'table' or not C.panelOpen then return end
    C.Send({ action = 'panelData', data = data })
end)

RegisterNetEvent(EVT .. 'client:panelResult', function(r)
    if type(r) ~= 'table' then return end
    C.Send({ action = 'panelResult', result = r })
end)

RegisterNetEvent(EVT .. 'client:panelClosed', function()
    C.ClosePanel(true)
end)

-- ═════════════ مزامنة عند الدخول / إعادة تشغيل الـ Resource ═════════════
CreateThread(function()
    while not NetworkIsPlayerActive(PlayerId()) do Wait(500) end
    Wait(1500)
    TriggerServerEvent(EVT .. 'server:requestSync')
    -- إرسال init مرة أخرى احتياطاً (قد تكون الصفحة حمّلت قبل تسجيل الـ Callbacks)
    C.SendInit()
    C.PushAlerts()

    -- اقتراحات الأوامر في الشات (إن وُجد resource chat، وإلا لا يحدث شيء)
    local lang = Config.Language == 'en'
    TriggerEvent('chat:addSuggestion', '/alert', lang and 'Send an alert' or 'إرسال تنبيه', {
        { name = 'target', help = 'all | region | id:N | group:name' },
        { name = 'level', help = 'information | warning | alert | emergency' },
        { name = 'message', help = '"..."' },
    })
    TriggerEvent('chat:addSuggestion', '/sendalert', lang and 'Send an alert with a title' or 'إرسال تنبيه بعنوان', {
        { name = 'target', help = 'all | region | id:N | group:name' },
        { name = 'level', help = 'information | warning | alert | emergency' },
        { name = 'title', help = '"..."' },
        { name = 'message', help = '"..."' },
    })
    TriggerEvent('chat:addSuggestion', '/simalert', lang and 'Send a simulation alert' or 'إرسال تنبيه محاكاة', {
        { name = 'level', help = 'information | warning | alert | emergency' },
        { name = 'target', help = 'optional' },
    })
    TriggerEvent('chat:addSuggestion', '/alerttest', lang and 'Test the phone UI' or 'اختبار واجهة الهاتف', {
        { name = 'level', help = 'information | warning | alert | emergency' },
    })
    TriggerEvent('chat:addSuggestion', '/clearalerts', lang and 'Clear alerts' or 'إلغاء التنبيهات', {
        { name = 'alertId', help = 'optional' },
    })
    TriggerEvent('chat:addSuggestion', '/alertpanel', lang and 'Open the admin panel' or 'فتح لوحة التحكم')
    TriggerEvent('chat:addSuggestion', '/alertphone', lang and 'Open the alerts phone' or 'فتح هاتف التنبيهات')
end)
