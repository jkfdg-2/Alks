-- Standalone: هاتف NUI الخاص بـ Qatar Secure Alert (يُستخدم تلقائياً عند غياب هاتف خارجي).
-- لا يحتاج أي تعبئة. يظهر الإشعار والـ Badge والسجل من html/.
QSA.Phone.Register('standalone', {
    implemented = false, -- false = دائماً يستخدم واجهة NUI الداخلية
    notify = function() return false end,
})
