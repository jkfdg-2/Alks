-- ═════════════════════════════════════════════════════════════
--  Danger_Phone Adapter
--  يرسل الإنذار إلى سكربت الجوال Danger_Phone (Resource name = Config.DangerPhone.resource).
--
--  لا نخمّن API الخاص بسكربتك: حدّد في Config.DangerPhone إحدى الطريقتين:
--    notifyExport = 'اسم_الـ_export'   -> exports[resource]:اسم(payload)
--    notifyEvent  = 'اسم_الـ_event'    -> TriggerEvent(اسم, payload)   (event محلي على الكلاينت)
--  وإن كان الـ event/export عندك يستقبل (title, message) بدل جدول: غيّر Config.DangerPhone.argsMode = 'args'.
--
--  payload = { id, title, message, type, region, coords, radius, simulation, remaining }
--  يعمل هذا الـ Adapter فقط عند ضبط إحدى الطريقتين وتشغيل Danger_Phone؛ وإلا يعمل هاتف NUI الداخلي.
-- ═════════════════════════════════════════════════════════════
local function cfg()
    return Config.DangerPhone or {}
end

local function nonEmpty(v) return type(v) == 'string' and v ~= '' end

local function send(kind, payload, alertId)
    local c = cfg()
    local name = kind == 'notify' and 'notify' or 'clear'
    local export, event = c[name .. 'Export'], c[name .. 'Event']
    if not nonEmpty(export) and not nonEmpty(event) then return false end
    local useArgs = kind == 'notify' and c.argsMode == 'args'
    if nonEmpty(export) then
        local res = exports[c.resource or 'Danger_Phone']
        if useArgs then res[export](res, payload.title, payload.message, payload)
        else res[export](res, payload or alertId) end
    else
        if useArgs then TriggerEvent(event, payload.title, payload.message, payload)
        else TriggerEvent(event, payload or alertId) end
    end
    return true
end

local def = {
    notify = function(alert) return send('notify', alert) end,
    clear  = function(alertId) send('clear', nil, alertId) end,
}

-- implemented يتبع الإعداد؛ والـ resource يُقرأ من Config
setmetatable(def, {
    __index = function(_, k)
        local c = cfg()
        if k == 'implemented' then
            return nonEmpty(c.notifyExport) or nonEmpty(c.notifyEvent)
        elseif k == 'resource' then
            return c.resource or 'Danger_Phone'
        end
    end,
})

QSA.Phone.Register('danger_phone', def)
