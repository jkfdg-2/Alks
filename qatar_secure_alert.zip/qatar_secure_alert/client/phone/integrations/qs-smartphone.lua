-- ═════════════════════════════════════════════════════════════
--  qs-smartphone Adapter (قالب)
--  لا نفترض API غير مؤكد. راجع توثيق qs-smartphone المرفق مع نسختك،
--  اكتب استدعاء الإشعار في notify() وأرجع true، ثم غيّر implemented إلى true.
--  إلى أن يتم ذلك يعمل هاتف NUI الداخلي تلقائياً.
-- ═════════════════════════════════════════════════════════════
QSA.Phone.Register('qs-smartphone', {
    resource = 'qs-smartphone',
    implemented = false,

    notify = function(alert)
        -- TriggerEvent('<EVENT_FROM_YOUR_PHONE_DOCS>', alert.title, alert.message)
        -- return true
        return false
    end,

    clear = function(alertId) end,
})
