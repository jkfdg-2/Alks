-- ═════════════════════════════════════════════════════════════
--  qb-phone Adapter (قالب)
--  لا نفترض API غير مؤكد. اختلفت إصدارات qb-phone وتعديلات السيرفرات كثيراً.
--  لتفعيله:
--    1) افتح ملفات/توثيق qb-phone عندك وابحث عن طريقة إرسال إشعار مخصص.
--    2) اكتب استدعاءها داخل notify() وأرجع true.
--    3) غيّر implemented إلى true.
--  إلى أن يتم ذلك يعمل هاتف NUI الداخلي تلقائياً.
--
--  alert = { id, title, message, type, region, coords, radius, simulation, remaining }
-- ═════════════════════════════════════════════════════════════
QSA.Phone.Register('qb-phone', {
    resource = 'qb-phone',
    implemented = false,

    notify = function(alert)
        -- مثال هيكلي (غير مفعّل):
        -- TriggerEvent('<EVENT_FROM_YOUR_QB_PHONE_VERSION>', alert.title, alert.message)
        -- return true
        return false
    end,

    clear = function(alertId)
        -- اختياري: إزالة الإشعار من الهاتف إن كان يدعم ذلك
    end,
})
