-- ═════════════════════════════════════════════════════════════
--  Custom Adapter (جاهز للعمل بدون أي API خارجي)
--  يرسل Event محلي (على الكلاينت) باسم تحدده في Config.CustomPhone.notifyEvent
--  فيلتقطه مطوّر سكربت الهاتف عندك بسطر واحد:
--
--     AddEventHandler('my_phone:client:alertNotification', function(alert)
--         -- alert = { id, title, message, type, region, coords, radius, simulation, remaining }
--         -- اعرض الإشعار داخل هاتفك هنا
--     end)
--
--  عند ضبط notifyEvent يصبح هذا الـ Adapter فعّالاً (Config.PhoneIntegration = 'custom' أو 'auto').
--  إذا تركته فارغاً يعمل هاتف NUI الداخلي.
-- ═════════════════════════════════════════════════════════════
local function cfg()
    return Config.CustomPhone or {}
end

local def = {
    notify = function(alert)
        local ev = cfg().notifyEvent
        if type(ev) ~= 'string' or ev == '' then return false end
        TriggerEvent(ev, alert)
        return true
    end,
    clear = function(alertId)
        local ev = cfg().clearEvent
        if type(ev) == 'string' and ev ~= '' then TriggerEvent(ev, alertId) end
    end,
}

-- implemented يتبع الإعداد مباشرة
setmetatable(def, {
    __index = function(_, k)
        if k == 'implemented' then
            local ev = cfg().notifyEvent
            return type(ev) == 'string' and ev ~= ''
        end
    end,
})

QSA.Phone.Register('custom', def)
