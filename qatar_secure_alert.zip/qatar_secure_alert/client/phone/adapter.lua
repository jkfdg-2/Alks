-- ═════════════════════════════════════════════════════════════
--  Phone Adapter  |  طبقة تكامل الهاتف (مستقلة عن النظام الأساسي)
--
--  كل Adapter يسجّل نفسه عبر QSA.Phone.Register(name, def) من ملف داخل
--  client/phone/integrations/. التعريف:
--    resource    = اسم الـ Resource للهاتف (للتحقق أنه يعمل)  [اختياري]
--    implemented = true فقط بعد تعبئة الدوال أدناه (وإلا يُتجاهل ويُستخدم هاتف NUI الخاص بالسكربت)
--    notify(alert) -> true إذا عرض الهاتف الخارجي الإشعار (عندها لا يظهر إشعار NUI الخاص بنا)
--    clear(alertId) [اختياري] عند إلغاء/انتهاء التنبيه
--
--  alert = { id, title, message, type, region, coords = {x,y,z}|nil, radius, simulation, remaining(ثواني) }
--
--  لا نفترض أي API لهاتف خارجي: إذا لم يُعبّأ الـ Adapter يعمل هاتف NUI الداخلي تلقائياً.
-- ═════════════════════════════════════════════════════════════
QSA = QSA or {}
QSA.Phone = QSA.Phone or { adapters = {}, warned = {} }
local Phone = QSA.Phone

local AUTO_ORDER = { 'danger_phone', 'qb-phone', 'qs-smartphone', 'roadphone' }

function Phone.Register(name, def)
    def.name = name
    Phone.adapters[name] = def
end

local function usable(def)
    if not def or def.implemented ~= true then return false end
    if def.resource and GetResourceState(def.resource) ~= 'started' then return false end
    return true
end

-- يرجع الـ Adapter الفعّال أو nil (nil = هاتف NUI الداخلي)
function Phone.Resolve()
    local mode = string.lower(Config.PhoneIntegration or 'auto')
    if mode == 'standalone' then return nil end
    if mode == 'auto' then
        for _, name in ipairs(AUTO_ORDER) do
            if usable(Phone.adapters[name]) then return Phone.adapters[name] end
        end
        if usable(Phone.adapters.custom) then return Phone.adapters.custom end
        return nil
    end
    local def = Phone.adapters[mode]
    if usable(def) then return def end
    if not Phone.warned[mode] then
        Phone.warned[mode] = true
        print(('[qatar_secure_alert] phone adapter "%s" is not implemented or its resource is not started: using built-in NUI phone.'):format(mode))
    end
    return nil
end

function Phone.ActiveName()
    local def = Phone.Resolve()
    return def and def.name or 'standalone'
end

-- true إذا تعامل الهاتف الخارجي مع الإشعار
function Phone.Notify(alert)
    local def = Phone.Resolve()
    if not def or type(def.notify) ~= 'function' then return false end
    local ok, handled = pcall(def.notify, alert)
    if not ok then
        print(('[qatar_secure_alert] phone adapter "%s" error: %s'):format(def.name, tostring(handled)))
        return false
    end
    return handled == true
end

function Phone.Clear(alertId)
    local def = Phone.Resolve()
    if not def or type(def.clear) ~= 'function' then return end
    pcall(def.clear, alertId)
end
