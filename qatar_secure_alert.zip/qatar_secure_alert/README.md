# Qatar Secure Alert

نظام إنذار ومحاكاة **داخل سيرفر FiveM فقط**: ينشئ المسؤول تنبيهًا فيظهر للاعبين المستهدفين داخل هاتف iPhone-style (NUI) داخل اللعبة. لا يتصل بأي مصدر خارجي ولا بأنظمة حقيقية.

- Standalone افتراضيًا، ويدعم QBCore وESX (اختياري، لا شيء إجباري).
- يتطلب **OneSync** (لفلترة اللاعبين حسب المنطقة من السيرفر).
- `oxmysql` اختياري. بدونه يعمل كل شيء والسجل يبقى في الذاكرة.

## 1) شجرة المشروع

```
qatar_secure_alert/
├── fxmanifest.lua
├── config.lua
├── README.md
├── sql/install.sql              (اختياري، الجداول تُنشأ تلقائيًا)
├── shared/utils.lua
├── locales/ar.lua · en.lua
├── server/
│   ├── main.lua                 أحداث، أوامر، لوحة التحكم، Exports
│   ├── alerts.lua               التحقق، الاستهداف، الإنشاء/الإلغاء/التعديل، الانتهاء
│   ├── permissions.lua          الأدوار (ACE / Identifiers / QBCore / ESX) + Rate limit
│   ├── regions.lua              المناطق (إضافة/تعديل/حذف + حفظ KVP)
│   ├── logs.lua                 Audit logs + Discord Webhook اختياري
│   └── database.lua             oxmysql اختياري
├── client/
│   ├── main.lua                 أوامر الكلاينت، مفاتيح، مزامنة
│   ├── alerts.lua               الاستقبال، Blips، الأصوات، السجل المحلي
│   ├── nui.lua                  الهاتف/اللوحة + NUI callbacks
│   └── phone/
│       ├── adapter.lua          طبقة التكامل (مستقلة)
│       └── integrations/        standalone · qb-phone · qs-smartphone · roadphone · custom
└── html/ index.html · style.css · app.js
```

## 2) التثبيت

1. انسخ المجلد `qatar_secure_alert` إلى `resources/`.
2. في `server.cfg`:

```cfg
# اختياري (قبل السكربت):
ensure oxmysql
ensure qatar_secure_alert

# الصلاحيات (مثال):
add_ace group.admin qsa.admin allow
add_principal identifier.license:XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX group.admin

add_ace group.qsa_super qsa.superadmin allow
add_principal identifier.license:YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY group.qsa_super

# Webhook اختياري (لا تضعه في الكود):
set qsa_discord_webhook "<رابط الـ Webhook>"
```

3. أعد تشغيل السيرفر أو `ensure qatar_secure_alert`.

## 3) الـ Dependencies

| | |
|---|---|
| إجباري | FiveM Server بـ **OneSync** و`lua54` (مفعّل في الـ manifest) |
| اختياري | `oxmysql` (حفظ السجل واستعادة التنبيهات النشطة بعد إعادة التشغيل) |
| اختياري | `qb-core` أو `es_extended` (مجموعات الإدارة/الوظائف) |
| اختياري | resource `chat` (اقتراحات الأوامر) |

## 4) الإعدادات (config.lua)

كل شيء في `config.lua` ومعلّق. أهمها:

| الإعداد | المعنى |
|---|---|
| `Config.Framework` | `standalone` / `qbcore` / `esx` / `auto` |
| `Config.Language` | `ar` (RTL) أو `en` (LTR) |
| `Config.SimulationMode` | `true` = كل التنبيهات بعلامة SIMULATION / TEST |
| `Config.PhoneIntegration` | `auto` / `standalone` / `qb-phone` / `qs-smartphone` / `roadphone` / `custom` |
| `Config.EnableBlips` / `EnableRadius` / `EnableSounds` | الخريطة والصوت |
| `Config.EmergencyRepeatSound` / `EmergencyRepeatInterval` | صوت Emergency المتكرر (ms) |
| `Config.MaxAlertHistory` / `AlertCooldown` | حجم السجل / فاصل بين إنذارين لنفس المسؤول (ثواني) |
| `Config.Regions` | المناطق الابتدائية |
| `Config.AcePermissions` / `AdminIdentifiers` / `AdminGroups` | مصادر الأدوار |
| `Config.RolePermissions` | ماذا يستطيع كل دور |
| `Config.Limits` / `RateLimit` | حدود الطول/النطاق/المدة + معدل الطلبات |
| `Config.Database` / `Config.Webhook` | قاعدة البيانات / ديسكورد |

**الأدوار** (يُؤخذ الأعلى): `superadmin` كل شيء · `admin` إنشاء/إلغاء/تعديل/مناطق/سجل · `operator` إرسال + مشاهدة النشطة · `viewer` السجل فقط. Console السيرفر دائمًا superadmin.

## 5) الأوامر

| الأمر | الصلاحية | الوصف |
|---|---|---|
| `/alert <الهدف> <المستوى> "الرسالة"` | create | `/alert ليوا emergency "إنذار تجريبي"` · `/alert all warning "رسالة"` |
| `/sendalert <الهدف> <المستوى> "العنوان" "الرسالة"` | create | نفس الأعلى مع عنوان |
| `/simalert [المستوى] [الهدف]` | create | تنبيه محاكاة (افتراضيًا لك أنت فقط) |
| `/alerttest [المستوى]` | panel | يعرض تنبيهًا تجريبيًا لك فقط (لا يُحفظ) لاختبار الهاتف |
| `/clearalerts [alertId]` | clear | إلغاء الكل أو تنبيه واحد |
| `/alertpanel` | panel | لوحة التحكم |
| `/alertphone` (F10) | الجميع | فتح هاتف التنبيهات |
| `/dismissalert` | الجميع | إخفاء الإشعار وإيقاف صوت Emergency |

**الهدف:** `all` أو اسم المنطقة (بين علامتي اقتباس إذا فيه مسافة: `"Al Wakra"`) أو `id:12` أو `group:police`.
**المستوى:** `information` `warning` `alert` `emergency` (وأسماء مختصرة مثل `info`).

## 6) Events

| Event | الاتجاه | الوصف |
|---|---|---|
| `qatar_secure_alert:server:sendAlert` | client → server | يتطلب صلاحية `create` (تُفحص في السيرفر) |
| `qatar_secure_alert:server:clearAlert` | client → server | صلاحية `clear` |
| `qatar_secure_alert:server:panelOpen` | client → server | صلاحية `panel` |
| `qatar_secure_alert:client:receiveAlert` | server → client | استقبال التنبيه (للاستخدام الداخلي) |

```lua
TriggerServerEvent("qatar_secure_alert:server:sendAlert", {
    title = "إنذار أمني", message = "حدث تجريبي",
    type = "emergency", region = "ليوا", radius = 500
})
```

> من **سكربت سيرفر** استخدم الـ Exports (الـ Event أعلاه مخصص للكلاينت ويتجاهل الاستدعاء من السيرفر).

حقول `data`: `title` `message` `type` `region` `radius` `duration` (ثواني) `target` (`all|region|player|group`) `player` `group` `coords` + `regionLabel` (منطقة مخصصة) `simulation`.

## 7) Exports

```lua
-- سيرفر
local id, err = exports["qatar_secure_alert"]:SendAlert(data)            -- id أو nil + سبب
local id, err = exports["qatar_secure_alert"]:SendRegionAlert("ليوا", data)
local ok      = exports["qatar_secure_alert"]:ClearAlert(alertId)
local list    = exports["qatar_secure_alert"]:GetActiveAlerts()
local inside, alertId = exports["qatar_secure_alert"]:IsPlayerInAlertZone(playerId)

-- كلاينت
local inside, alertId = exports["qatar_secure_alert"]:IsPlayerInAlertZone()
local list = exports["qatar_secure_alert"]:GetActiveAlerts()
```

## 8) إضافة منطقة جديدة

- **من اللعبة:** `/alertpanel` ← المناطق ← الاسم والإحداثيات (زر "استخدم موقعي") والنطاق ← حفظ. (تحتاج صلاحية `regions`)
- **من الإعدادات:** أضف في `Config.Regions`:

```lua
{ name = "الوكرة", coords = vector3(0.0, 0.0, 0.0), radius = 500.0 },
```

بعد أول تعديل من اللوحة تُحفظ المناطق (Resource KVP) وتتقدم على `Config.Regions`؛ زر **إعادة للإعدادات** يرجعها من الملف.

## 9) ربط سكربت هاتف مختلف

الكود لا يفترض أي API لهاتف خارجي. لذلك:

- **`custom` (جاهز):** اضبط `Config.CustomPhone.notifyEvent = 'my_phone:client:alert'` و`Config.PhoneIntegration = 'custom'`، ثم في سكربت الهاتف:

```lua
AddEventHandler('my_phone:client:alert', function(alert)
    -- alert = { id, title, message, type, region, coords, radius, simulation, remaining }
end)
```

- **qb-phone / qs-smartphone / roadphone:** ملفات قوالب في `client/phone/integrations/`. افتح الملف، اكتب استدعاء إشعار هاتفك داخل `notify(alert)` وأرجع `true`، ثم غيّر `implemented = true`. إلى ذلك الحين يُستخدم هاتف NUI الداخلي تلقائيًا.
- لإضافة هاتف جديد: انسخ أي قالب وغيّر الاسم و`resource`، ثم أضف اسمه في `AUTO_ORDER` داخل `adapter.lua` إذا أردت اكتشافًا تلقائيًا.

## 10) تشغيل Simulation Mode

`Config.SimulationMode = true` ← كل تنبيه يظهر معه **SIMULATION / TEST** (في الإشعار والهاتف واللوحة). لا مصدر خارجي ولا بيانات حقيقية. للاستخدام الحقيقي داخل الرول بلاي اجعلها `false`. وللتجربة السريعة: `/simalert emergency`.

## 11) طريقة الاختبار

**آليًا (تم تشغيلها):** مجلد `tests/` — `bash tests/run_all.sh`
(Lua syntax، JS، تطابق الـ Events/Exports/الترجمات، منطق السيرفر بمحاكاة FiveM، منطق الكلاينت، واجهة NUI بـ jsdom).

**يدويًا داخل السيرفر (قبل الاعتماد):**
1. `/alerttest emergency` ← يظهر إشعار كبير + صوت متكرر + Badge، `F10` يفتح الهاتف.
2. لاعبان: واحد داخل المنطقة وواحد خارجها، `/alert ليوا warning "اختبار"` ← يصل للداخل فقط.
3. `/alert id:<رقم> info "x"` · `/alert all alert "x"` · جرّب المستويات الأربعة.
4. `/clearalerts` ثم تأكد أن الإشعار/الـ Blip اختفى. اترك تنبيهًا ينتهي بمدته.
5. لاعب بدون صلاحية يجرب `/alert` ← مرفوض ويظهر في سجل السيرفر `[unauthorized]`.
6. `/alertpanel` بكل دور (superadmin/admin/operator/viewer).
7. أعد تشغيل الـ Resource (مع oxmysql تعود التنبيهات النشطة).
8. راقب F8 وكونسول السيرفر: يجب ألا تظهر أخطاء.
9. بدّل `Config.Language` بين `ar` و`en` وتأكد من RTL/LTR.

## ملاحظات

- التحقق من الصلاحيات وطول النص ونوع الإنذار والمنطقة والنطاق والمدة و**Rate limit** كلها في السيرفر؛ الكلاينت لا يُوثق به.
- النصوص تُعرض بـ `textContent` (لا HTML)، فلا يمكن حقن كود عبر العنوان أو الرسالة.
- الأداء: لا Loops كل Frame. الفحص الدوري الوحيد في السيرفر يعمل **فقط أثناء وجود تنبيه نشط** (كل `Config.LateEntrantInterval`)، وصوت Emergency المتكرر Thread يعمل فقط أثناء وجود Emergency غير مكتوم.
- هذا النظام للمحاكاة والرول بلاي داخل السيرفر فقط. لا تربطه بأنظمة حقيقية.
