-- Qatar Secure Alert (اختياري): الجداول تُنشأ تلقائياً عند التشغيل إذا كان oxmysql شغّال.
-- استخدم هذا الملف فقط إذا أردت إنشاءها يدوياً.

CREATE TABLE IF NOT EXISTS `secure_alerts` (
        `alert_id` VARCHAR(40) NOT NULL,
        `sender` VARCHAR(120) NOT NULL DEFAULT '',
        `title` VARCHAR(255) NOT NULL,
        `message` TEXT NOT NULL,
        `type` VARCHAR(20) NOT NULL,
        `region` VARCHAR(100) NOT NULL DEFAULT '',
        `payload` LONGTEXT NULL,
        `created_at` BIGINT NOT NULL,
        `expires_at` BIGINT NOT NULL,
        PRIMARY KEY (`alert_id`),
        KEY `idx_expires` (`expires_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `secure_alert_history` (
        `alert_id` VARCHAR(40) NOT NULL,
        `sender` VARCHAR(120) NOT NULL DEFAULT '',
        `title` VARCHAR(255) NOT NULL,
        `message` TEXT NOT NULL,
        `type` VARCHAR(20) NOT NULL,
        `region` VARCHAR(100) NOT NULL DEFAULT '',
        `status` VARCHAR(20) NOT NULL DEFAULT 'active',
        `ended_by` VARCHAR(120) NOT NULL DEFAULT '',
        `simulation` TINYINT(1) NOT NULL DEFAULT 0,
        `created_at` BIGINT NOT NULL,
        `expires_at` BIGINT NOT NULL,
        `ended_at` BIGINT NOT NULL DEFAULT 0,
        PRIMARY KEY (`alert_id`),
        KEY `idx_created` (`created_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `secure_alert_logs` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `action` VARCHAR(40) NOT NULL,
        `actor` VARCHAR(160) NOT NULL DEFAULT '',
        `details` TEXT NULL,
        `created_at` BIGINT NOT NULL,
        PRIMARY KEY (`id`),
        KEY `idx_action` (`action`),
        KEY `idx_created` (`created_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
