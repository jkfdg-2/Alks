Config = {}

-- ═══════════════════════════════════════════════════════════════
--  الإعدادات العامة | General
-- ═══════════════════════════════════════════════════════════════
Config.Framework        = 'standalone' -- 'standalone' | 'qbcore' | 'esx' | 'auto'  (لا يوجد Framework إجباري)
Config.Language         = 'ar'         -- 'ar' | 'en'
Config.SimulationMode   = true         -- true = كل التنبيهات تظهر بعلامة SIMULATION / TEST
Config.PhoneIntegration = 'auto'       -- 'auto' | 'standalone' | 'qb-phone' | 'qs-smartphone' | 'roadphone' | 'custom'
Config.EnableBlips      = true         -- Blip لمركز المنطقة على الخريطة
Config.EnableRadius     = true         -- دائرة نصف القطر على الخريطة
Config.EnableSounds     = true
Config.MaxAlertHistory  = 50           -- عدد التنبيهات المحفوظة في السجل (الذاكرة / لوحة التحكم)
Config.AlertCooldown    = 5            -- ثواني بين كل إنذارين من نفس المسؤول (0 = تعطيل)
Config.Debug            = false

-- Emergency
Config.EmergencyRepeatSound    = true
Config.EmergencyRepeatInterval = 5000  -- ms

-- ═══════════════════════════════════════════════════════════════
--  المناطق | Regions
--  هذي المناطق هي القيم الابتدائية. عند التعديل من لوحة التحكم تُحفظ المناطق
--  (Resource KVP) وتتغلب على هذي القائمة. زر "إعادة للإعدادات" في لوحة التحكم يرجعها.
--  الإحداثيات أدناه أمثلة على خريطة GTA، غيّرها حسب سيرفرك.
-- ═══════════════════════════════════════════════════════════════
Config.Regions = {
    {
        name   = 'ليوا',
        coords = vector3(195.0, -934.0, 30.7),
        radius = 500.0,
    },
    {
        name   = 'ساندي شورز',
        coords = vector3(1853.0, 3689.0, 34.0),
        radius = 600.0,
    },
    {
        name   = 'بوليتو',
        coords = vector3(-100.0, 6460.0, 31.0),
        radius = 700.0,
    },
}

Config.AllowCustomCoords = true   -- السماح بإنذار لإحداثيات مخصصة (من لوحة التحكم / الـ Event)
Config.Use3DDistance     = false  -- false = تجاهل الارتفاع عند حساب المسافة

-- ═══════════════════════════════════════════════════════════════
--  الصلاحيات | Permissions  (تُفحص دائماً في السيرفر)
--  الأدوار: superadmin > admin > operator > viewer
--  يُؤخذ أعلى دور من المصادر التالية:
--    1) ACE (الأنسب للـ Standalone)  -> Config.AcePermissions
--    2) Identifiers مباشرة            -> Config.AdminIdentifiers
--    3) مجموعات الـ Framework          -> Config.AdminGroups (QBCore / ESX)
--  Console السيرفر دائماً superadmin.
-- ═══════════════════════════════════════════════════════════════
Config.AcePermissions = {
    superadmin = 'qsa.superadmin',
    admin      = 'qsa.admin',
    operator   = 'qsa.operator',
    viewer     = 'qsa.viewer',
}
-- مثال في server.cfg:
--   add_ace group.admin qsa.admin allow
--   add_principal identifier.license:xxxxxxxx group.admin

Config.AdminIdentifiers = {
    -- ['license:xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'] = 'superadmin',
}

Config.AdminGroups = {
    -- QBCore: أسماء الصلاحيات (god/admin/mod) | ESX: اسم المجموعة (superadmin/admin/mod)
    superadmin = { 'god', 'superadmin' },
    admin      = { 'admin' },
    operator   = { 'mod', 'moderator' },
    viewer     = {},
}

-- الصلاحيات المتاحة: panel, dashboard, create, active, clear, edit, history, regions
Config.RolePermissions = {
    superadmin = { '*' },
    admin      = { 'panel', 'dashboard', 'create', 'active', 'clear', 'edit', 'history', 'regions' },
    operator   = { 'panel', 'dashboard', 'create', 'active' },
    viewer     = { 'panel', 'history' },
}

-- ═══════════════════════════════════════════════════════════════
--  الاستهداف بالمجموعات | Group targeting
--  الإرسال لمجموعة يطابق: (1) ACE باسم  qsa.group.<group>  (2) وظيفة اللاعب في QBCore/ESX
--  مثال: add_ace identifier.license:xxxx qsa.group.police allow
--  أو عرّف دالة خاصة:  Config.GroupResolver = function(src, group) return false end
-- ═══════════════════════════════════════════════════════════════
Config.GroupResolver = nil

-- ═══════════════════════════════════════════════════════════════
--  حدود وتحقق | Limits & validation
-- ═══════════════════════════════════════════════════════════════
Config.DefaultDuration = 300   -- ثانية
Config.Limits = {
    title       = 60,     -- أقصى طول للعنوان (حروف)
    message     = 400,    -- أقصى طول للرسالة (حروف)
    minRadius   = 10.0,
    maxRadius   = 10000.0,
    minDuration = 10,     -- ثانية
    maxDuration = 86400,  -- ثانية (24 ساعة)
}

Config.RateLimit = {          -- max طلبات لكل window ثانية، لكل لاعب
    create = { max = 6,  window = 60 },
    panel  = { max = 40, window = 10 },
    sync   = { max = 6,  window = 30 },
    test   = { max = 10, window = 30 },
}

Config.LateEntrantInterval  = 5000  -- ms: توصيل التنبيه النشط للاعبين الذين دخلوا المنطقة/السيرفر لاحقاً (0 = تعطيل)
Config.ShowSenderToPlayers  = false -- إظهار اسم المرسل للاعبين العاديين

-- ═══════════════════════════════════════════════════════════════
--  مستويات الخطورة | Alert types
-- ═══════════════════════════════════════════════════════════════
Config.Types = {
    information = { color = '#3b82f6', blipColour = 3  },
    warning     = { color = '#f59e0b', blipColour = 5  },
    alert       = { color = '#f97316', blipColour = 17 },
    emergency   = { color = '#ef4444', blipColour = 1  },
}

Config.Blip = { sprite = 1, scale = 0.9, radiusAlpha = 90 }

-- أصوات GTA الأصلية (PlaySoundFrontend). يمكن تغييرها.
Config.Sounds = {
    information = { name = 'Text_Arrive_Tone',     set = 'Phone_SoundSet_Default' },
    warning     = { name = 'Text_Arrive_Tone',     set = 'Phone_SoundSet_Default' },
    alert       = { name = 'Event_Message_Purple', set = 'GTAO_FM_Events_Soundset' },
    emergency   = { name = 'Beep_Red',             set = 'DLC_HEIST_HACKING_SNAKE_SOUNDS' },
}

-- ═══════════════════════════════════════════════════════════════
--  الواجهة | UI
-- ═══════════════════════════════════════════════════════════════
Config.UI = {
    bannerMs         = 7000,  -- مدة ظهور إشعار الهاتف (ms)
    emergencySticky  = true,  -- إشعار Emergency يبقى حتى الإغلاق/الإلغاء/الانتهاء
    showUnreadBadge  = true,  -- Badge صغير بعدد غير المقروء عندما يكون الهاتف مغلق
    historyLimit     = 50,    -- سجل التنبيهات داخل الهاتف (لكل لاعب)
}

Config.Keys = {               -- '' = بدون زر (الأوامر تعمل دائماً). يمكن للاعب تغييرها من إعدادات FiveM
    phone   = 'F10',
    dismiss = '',
    panel   = '',
}

-- ═══════════════════════════════════════════════════════════════
--  تكامل الهاتف | Phone integration  (انظر client/phone/integrations)
--  custom: يرسل Event محلي على الكلاينت ليلتقطه أي سكربت هاتف (اتركه فارغاً لتعطيله)
-- ═══════════════════════════════════════════════════════════════
Config.CustomPhone = {
    notifyEvent = '',  -- مثال: 'my_phone:client:alertNotification'
    clearEvent  = '',
}
Config.ShowBuiltInBannerWithExternalPhone = false

-- ═══════════════════════════════════════════════════════════════
--  قاعدة البيانات (اختيارية) | Database (optional, oxmysql)
-- ═══════════════════════════════════════════════════════════════
Config.Database = {
    enabled  = true,       -- إذا لم يتوفر oxmysql يعمل النظام بدونها (سجل في الذاكرة فقط)
    resource = 'oxmysql',
}

-- ═══════════════════════════════════════════════════════════════
--  Discord Webhook (اختياري)
--  لا تضع الرابط في الكود المنشور: استخدم convar في server.cfg:
--     set qsa_discord_webhook "<رابط الـ Webhook>"
--  أو ضعه في Config.Webhook.url محلياً.
-- ═══════════════════════════════════════════════════════════════
Config.Webhook = {
    enabled  = false,
    url      = '',
    username = 'Secure Alert',
    events = {
        create       = true,
        clear        = true,
        expire       = false,
        edit         = true,
        panel_open   = true,
        unauthorized = true,
        rate_limited = false,
        region       = true,
    },
}
