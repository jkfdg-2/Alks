'use strict';
(function () {
  // ───────────────────────── أدوات ─────────────────────────
  var RES = (typeof GetParentResourceName === 'function') ? GetParentResourceName() : 'qatar_secure_alert';
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function post(name, data) {
    return fetch('https://' + RES + '/' + name, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json; charset=UTF-8' },
      body: JSON.stringify(data || {})
    });
  }
  function postQuiet(name, data) { post(name, data).catch(function () {}); }
  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined && text !== null) n.textContent = String(text);
    return n;
  }
  function clear(node) { while (node.firstChild) node.removeChild(node.firstChild); }
  function pad(n) { return n < 10 ? '0' + n : '' + n; }
  function len(s) { return Array.from(String(s || '')).length; }

  var ICONS = {
    information: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="currentColor"/><rect x="11" y="10" width="2" height="7" rx="1" fill="#fff"/><circle cx="12" cy="7.2" r="1.3" fill="#fff"/></svg>',
    warning: '<svg viewBox="0 0 24 24"><path d="M12 2.5 22.6 21H1.4z" fill="currentColor" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/><rect x="11" y="9" width="2" height="6" rx="1" fill="#fff"/><circle cx="12" cy="17.4" r="1.2" fill="#fff"/></svg>',
    alert: '<svg viewBox="0 0 24 24"><path d="M12 22a2.4 2.4 0 0 0 2.4-2.4H9.6A2.4 2.4 0 0 0 12 22zm7-6.5V11a7 7 0 0 0-5.5-6.8V3.5a1.5 1.5 0 0 0-3 0v.7A7 7 0 0 0 5 11v4.5L3 17.5V19h18v-1.5z" fill="currentColor"/></svg>',
    emergency: '<svg viewBox="0 0 24 24"><path d="M8 2h8l6 6v8l-6 6H8l-6-6V8z" fill="currentColor"/><rect x="11" y="6.5" width="2" height="7" rx="1" fill="#fff"/><circle cx="12" cy="16.6" r="1.3" fill="#fff"/></svg>'
  };
  function icon(type) {
    var s = el('span', 'ico');
    s.innerHTML = ICONS[type] || ICONS.information; // رموز ثابتة فقط (بدون بيانات مستخدم)
    return s;
  }
  function validType(t) { return ICONS[t] ? t : 'information'; }

  // ───────────────────────── الحالة ─────────────────────────
  var S = {
    lang: 'ar', rtl: true, dateLocale: 'ar-u-nu-latn', strings: {}, types: {}, ui: { bannerMs: 7000, emergencySticky: true, showUnreadBadge: true },
    alerts: [], phoneOpen: false, panelOpen: false, ptab: 'active', sheetId: null,
    panel: null, tab: null, editingRegion: null, editingAlert: null, initialized: false, ticker: null, creating: false
  };

  function t(key) {
    var s = S.strings[key];
    if (s === undefined) s = key;
    for (var i = 1; i < arguments.length; i++) s = String(s).replace(/%[sd]/, arguments[i]);
    return s;
  }
  function levelLabel(type) { return t('level_' + validType(type)); }
  function statusLabel(st) { return t('status_' + (st || 'expired')); }

  function fmtTime(ts) {
    if (!ts) return '';
    var d = new Date(ts * 1000);
    try { return d.toLocaleString(S.dateLocale, { dateStyle: 'medium', timeStyle: 'short' }); } catch (e) { return d.toLocaleString(); }
  }
  function fmtRel(ts) {
    if (!ts) return '';
    var diff = Math.round(ts - Date.now() / 1000);
    var abs = Math.abs(diff);
    if (abs < 45) return t('now');
    var unit = 'minute', val = Math.round(diff / 60);
    if (abs >= 86400) { unit = 'day'; val = Math.round(diff / 86400); }
    else if (abs >= 3600) { unit = 'hour'; val = Math.round(diff / 3600); }
    try { return new Intl.RelativeTimeFormat(S.dateLocale, { numeric: 'auto' }).format(val, unit); } catch (e) { return fmtTime(ts); }
  }
  function fmtCd(sec) {
    sec = Math.max(0, Math.floor(sec));
    var h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
    return h ? h + ':' + pad(m) + ':' + pad(s) : m + ':' + pad(s);
  }
  function countdown(endsAt) {
    var c = el('span', 'countdown', fmtCd((endsAt - Date.now()) / 1000));
    c.setAttribute('data-ends', String(endsAt));
    return c;
  }

  // ───────────────────────── i18n / Init ─────────────────────────
  function applyI18n() {
    document.documentElement.dir = S.rtl ? 'rtl' : 'ltr';
    document.documentElement.lang = S.lang;
    $$('[data-i18n]').forEach(function (n) { n.textContent = t(n.getAttribute('data-i18n')); });
    $$('[data-i18n-ph]').forEach(function (n) { n.setAttribute('placeholder', t(n.getAttribute('data-i18n-ph'))); });
    updateTitleCounters();
  }

  function applyTypes(types) {
    S.types = types || {};
    Object.keys(S.types).forEach(function (k) {
      var c = S.types[k] && S.types[k].color;
      if (c && /^#[0-9a-fA-F]{3,8}$/.test(c)) document.documentElement.style.setProperty('--c-' + k, c);
    });
  }

  function onInit(m) {
    S.initialized = true;
    S.lang = m.lang || 'ar';
    S.rtl = m.rtl === true;
    S.dateLocale = m.dateLocale || 'en-GB';
    S.strings = m.strings || {};
    if (m.ui) { S.ui.bannerMs = m.ui.bannerMs || 7000; S.ui.emergencySticky = m.ui.emergencySticky !== false; S.ui.showUnreadBadge = m.ui.showUnreadBadge !== false; }
    applyTypes(m.types);
    applyI18n();
    renderPhone();
    if (S.panel) renderPanel();
  }

  // ───────────────────────── Ticker (عدّاد تنازلي) ─────────────────────────
  function startTicker() {
    if (S.ticker) return;
    S.ticker = setInterval(tick, 1000);
    tick();
  }
  function stopTickerIfIdle() {
    if (!S.phoneOpen && !S.panelOpen && S.ticker) { clearInterval(S.ticker); S.ticker = null; }
  }
  function tick() {
    var now = Date.now();
    $$('.countdown[data-ends]').forEach(function (n) { n.textContent = fmtCd((Number(n.getAttribute('data-ends')) - now) / 1000); });
    if (S.phoneOpen) {
      var d = new Date();
      var hm = pad(d.getHours()) + ':' + pad(d.getMinutes());
      $('#clock').textContent = hm;
      $('#lock-time').textContent = hm;
    }
  }

  // ───────────────────────── Toast ─────────────────────────
  var toastTimer = null;
  function toast(msg, ok) {
    var n = $('#toast');
    n.textContent = msg;
    n.className = ok ? '' : 'err';
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { n.classList.add('hidden'); }, 3200);
  }

  // ───────────────────────── Banners ─────────────────────────
  var bannerTimers = {};
  function removeBanner(id, immediate) {
    var node = document.getElementById('banner-' + id);
    clearTimeout(bannerTimers[id]);
    delete bannerTimers[id];
    if (!node) return;
    node.removeAttribute('id'); // حتى لا يختلط مع إشعار جديد بنفس المعرّف أثناء حركة الخروج
    if (immediate) { if (node.parentNode) node.parentNode.removeChild(node); return; }
    node.classList.add('leaving');
    setTimeout(function () { if (node.parentNode) node.parentNode.removeChild(node); }, 450);
  }
  function removeAllBanners() {
    $$('#banners .banner').forEach(function (n) { removeBanner(n.id.replace(/^banner-/, '')); });
  }

  function showBanner(a) {
    var type = validType(a.type);
    removeBanner(a.id, true);
    var node = el('div', 'banner lvl-' + type + (type === 'emergency' ? ' emergency' : ''));
    node.id = 'banner-' + a.id;
    node.appendChild(icon(type));

    var body = el('div', 'b-body');
    var top = el('div', 'b-top');
    top.appendChild(el('span', '', t(a.update ? 'phone_updated' : 'phone_new_alert')));
    top.appendChild(el('span', '', t('now')));
    body.appendChild(top);
    body.appendChild(el('div', 'b-title', a.title));
    body.appendChild(el('div', 'b-msg', a.message));

    var meta = el('div', 'b-meta');
    if (a.simulation) meta.appendChild(el('span', 'sim-tag', t('simulation_tag')));
    meta.appendChild(el('span', 'b-chip lvl', t('level') + ': ' + levelLabel(type)));
    if (a.region) meta.appendChild(el('span', 'b-chip', t('region') + ': ' + a.region));
    body.appendChild(meta);
    node.appendChild(body);

    $('#banners').appendChild(node);
    requestAnimationFrame(function () { requestAnimationFrame(function () { node.classList.add('show'); }); });

    if (!(type === 'emergency' && S.ui.emergencySticky)) {
      bannerTimers[a.id] = setTimeout(function () { removeBanner(a.id); }, S.ui.bannerMs);
    }
  }

  // ───────────────────────── Badge ─────────────────────────
  function unreadCount() { return S.alerts.filter(function (a) { return !a.read; }).length; }
  function updateBadges() {
    var n = unreadCount();
    var ab = $('#app-badge');
    ab.textContent = n > 99 ? '99+' : String(n);
    ab.classList.toggle('hidden', n === 0);
    var show = n > 0 && !S.phoneOpen && !S.panelOpen && S.ui.showUnreadBadge;
    $('#badge').classList.toggle('hidden', !show);
    $('#badge-count').textContent = n > 99 ? '99+' : String(n);
  }

  // ───────────────────────── الهاتف ─────────────────────────
  function fitPhone() {
    var k = Math.min(1, (window.innerHeight - 30) / 700);
    $('#phone').style.setProperty('--k', String(k));
  }

  function notifItem(a, onClick) {
    var type = validType(a.type);
    var b = el('button', 'notif lvl-' + type + (a.read ? ' read' : ''));
    b.type = 'button';
    b.appendChild(icon(type));
    var body = el('div', 'n-body');
    var title = el('div', 'n-title');
    if (!a.read) title.appendChild(el('span', 'n-dot'));
    title.appendChild(el('span', '', a.title));
    body.appendChild(title);
    body.appendChild(el('div', 'n-msg', a.message));
    var meta = el('div', 'n-meta');
    if (a.simulation) meta.appendChild(el('span', 'sim-tag', t('simulation_tag')));
    meta.appendChild(el('span', '', fmtRel(a.created_at)));
    if (a.region) meta.appendChild(el('span', '', a.region));
    var st = el('span', 'st ' + (a.status === 'active' ? 'active' : ''));
    if (a.status === 'active' && a.endsAt) st.appendChild(countdown(a.endsAt)); else st.textContent = statusLabel(a.status);
    meta.appendChild(st);
    body.appendChild(meta);
    b.appendChild(body);
    b.addEventListener('click', onClick);
    return b;
  }

  function renderPhone() {
    var home = $('#home-notifs');
    clear(home);
    var recent = S.alerts.slice(0, 3);
    if (!recent.length) home.appendChild(el('div', 'empty', t('phone_no_alerts')));
    recent.forEach(function (a) { home.appendChild(notifItem(a, function () { openSheet(a.id); })); });

    var list = $('#app-list');
    clear(list);
    var items = S.alerts.filter(function (a) { return S.ptab === 'all' || a.status === 'active'; });
    if (!items.length) list.appendChild(el('div', 'empty', t('phone_no_alerts')));
    items.forEach(function (a) { list.appendChild(notifItem(a, function () { openSheet(a.id); })); });

    $$('.seg').forEach(function (s) { s.classList.toggle('on', s.getAttribute('data-ptab') === S.ptab); });
    $('#lock-date').textContent = new Date().toLocaleDateString(S.dateLocale, { weekday: 'long', day: 'numeric', month: 'long' });
    updateBadges();
    if (S.sheetId) renderSheet();
    if (S.phoneOpen) tick();
  }

  function showView(name) {
    $('#view-home').classList.toggle('hidden', name !== 'home');
    $('#view-app').classList.toggle('hidden', name !== 'app');
  }

  function renderSheet() {
    var a = S.alerts.filter(function (x) { return x.id === S.sheetId; })[0];
    if (!a) { closeSheet(); return; }
    var type = validType(a.type);
    var body = $('#sheet-body');
    clear(body);
    var wrap = el('div', 'lvl-' + type);
    var head = el('div', 's-head');
    head.appendChild(icon(type));
    var ht = el('div');
    ht.appendChild(el('div', 's-title', a.title));
    if (a.simulation) ht.appendChild(el('span', 'sim-tag', t('simulation_tag')));
    head.appendChild(ht);
    wrap.appendChild(head);
    wrap.appendChild(el('div', 's-msg', a.message));

    var rows = el('div', 's-rows');
    function row(label, valueNode) {
      var r = el('div', 's-row');
      r.appendChild(el('span', '', label));
      if (typeof valueNode === 'string') r.appendChild(el('span', '', valueNode)); else r.appendChild(valueNode);
      rows.appendChild(r);
    }
    if (a.region) row(t('region'), a.region);
    row(t('level'), el('span', 'lvlv', levelLabel(type)));
    row(t('time'), fmtTime(a.created_at));
    if (a.status === 'active' && a.endsAt) row(t('remaining'), countdown(a.endsAt)); else row(t('status'), statusLabel(a.status));
    wrap.appendChild(rows);
    body.appendChild(wrap);
  }

  function openSheet(id) {
    S.sheetId = id;
    renderSheet();
    $('#sheet').classList.remove('hidden');
    var a = S.alerts.filter(function (x) { return x.id === id; })[0];
    if (a && !a.read) { a.read = true; postQuiet('markRead', { id: id }); renderPhone(); }
    tick();
  }
  function closeSheet() {
    S.sheetId = null;
    $('#sheet').classList.add('hidden');
  }

  function setPhone(show) {
    S.phoneOpen = show;
    var p = $('#phone');
    if (show) {
      fitPhone();
      p.classList.add('enter');
      p.classList.remove('hidden');
      showView('home');
      closeSheet();
      renderPhone();
      requestAnimationFrame(function () { requestAnimationFrame(function () { p.classList.remove('enter'); }); });
      startTicker();
    } else {
      p.classList.add('hidden');
      closeSheet();
      stopTickerIfIdle();
      updateBadges();
    }
  }

  function setAlerts(list) {
    var now = Date.now();
    S.alerts = (Array.isArray(list) ? list : []).map(function (a) {
      a.type = validType(a.type);
      a.endsAt = (a.status === 'active' && typeof a.remaining === 'number') ? now + a.remaining * 1000 : null;
      return a;
    });
    renderPhone();
  }

  // ───────────────────────── لوحة التحكم ─────────────────────────
  var TABS = ['dashboard', 'create', 'active', 'history', 'regions'];
  function perms() { return (S.panel && S.panel.perms) || {}; }
  function can(p) { return perms()[p] === true; }

  function setTab(name) {
    S.tab = name;
    TABS.forEach(function (tn) { $('#tab-' + tn).classList.toggle('hidden', tn !== name); });
    $$('#panel-nav .nav-btn').forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-tab') === name); });
    $('#panel-heading').textContent = t('nav_' + name);
    tick();
  }

  function firstAllowedTab() {
    for (var i = 0; i < TABS.length; i++) if (can(TABS[i]) || (TABS[i] === 'dashboard' && can('dashboard'))) return TABS[i];
    return 'dashboard';
  }

  function openPanel(data) {
    S.panelOpen = true;
    $('#panel').classList.remove('hidden');
    S.panel = null; S.tab = null;
    applyPanelData(data);
    startTicker();
    updateBadges();
  }
  function closePanelUI() {
    S.panelOpen = false;
    $('#panel').classList.add('hidden');
    $('#modal').classList.add('hidden');
    stopTickerIfIdle();
    updateBadges();
  }

  function applyPanelData(d) {
    if (!d) return;
    var first = !S.panel;
    var base = Date.now();
    var st = d.serverTime || 0;
    (d.active || []).forEach(function (a) { a.endsAt = base + (a.expires_at - st) * 1000; });
    S.panel = d;
    renderPanel();
    if (first) {
      $('#c-duration').value = d.config && d.config.defaultDurationMin ? d.config.defaultDurationMin : 5;
    }
  }

  function renderPanel() {
    var d = S.panel;
    if (!d) return;
    $$('#panel-nav .nav-btn').forEach(function (b) { b.classList.toggle('hidden', !can(b.getAttribute('data-perm'))); });
    $('#role-chip').textContent = t('role_' + d.role);
    $('#sim-chip').classList.toggle('hidden', !(d.config && d.config.simulation));
    $('#nav-active-count').textContent = String((d.active || []).length);
    if (!S.tab || !can(S.tab === 'dashboard' ? 'dashboard' : S.tab)) setTab(firstAllowedTab()); else setTab(S.tab);

    renderDashboard();
    renderActive();
    renderHistory();
    renderRegions();
    fillRegionSelect();
    updateTitleCounters();
  }

  function levelTag(type) {
    var s = el('span', 'tag lvl-' + validType(type), levelLabel(type));
    s.style.background = 'color-mix(in srgb, var(--c) 22%, transparent)';
    s.style.color = 'var(--c)';
    return s;
  }
  function statusTag(st) { return el('span', 'tag ' + st, statusLabel(st)); }

  function targetText(a) {
    switch (a.target_kind) {
      case 'all': return t('target_all');
      case 'player': return t('target_player') + ' #' + a.target_value;
      case 'group': return t('target_group') + ': ' + a.target_value;
      case 'region': return t('target_region');
      default: return '';
    }
  }

  function alertRow(a) {
    var type = validType(a.type);
    var r = el('div', 'row lvl-' + type);
    r.appendChild(icon(type));
    var main = el('div', 'r-main');
    main.appendChild(el('div', 'r-title', a.title));
    main.appendChild(el('div', 'r-sub', a.message));
    r.appendChild(main);
    var sub = el('div', 'r-main');
    sub.appendChild(el('div', 'r-title', a.region || '—'));
    sub.appendChild(el('div', 'r-sub', [targetText(a), a.sender].filter(Boolean).join(' · ')));
    r.appendChild(sub);
    var stCell = el('div');
    stCell.appendChild(statusTag(a.status));
    r.appendChild(stCell);
    r.appendChild(el('div', 'r-sub', fmtTime(a.created_at)));
    return r;
  }

  function renderDashboard() {
    var d = S.panel;
    var s = d.stats || {};
    $('#st-players').textContent = s.players || 0;
    $('#st-total').textContent = s.total || 0;
    $('#st-active').textContent = s.active || 0;
    $('#st-cleared').textContent = s.cleared || 0;
    $('#st-expired').textContent = s.expired || 0;
    var box = $('#dash-recent');
    clear(box);
    var recent = d.recent || [];
    if (!recent.length) box.appendChild(el('div', 'empty', t('history_none')));
    recent.forEach(function (a) { box.appendChild(alertRow(a)); });
  }

  // two-step confirm: أول ضغطة تغيّر النص، الثانية تنفّذ
  function confirmButton(btn, action) {
    var armed = false, timer = null, original = btn.textContent;
    btn.addEventListener('click', function () {
      if (!armed) {
        armed = true; btn.classList.add('confirm'); btn.textContent = t('confirm');
        timer = setTimeout(function () { armed = false; btn.classList.remove('confirm'); btn.textContent = original; }, 3000);
        return;
      }
      clearTimeout(timer); armed = false; btn.classList.remove('confirm'); btn.textContent = original;
      action();
    });
  }

  function renderActive() {
    var list = $('#active-list');
    clear(list);
    var items = S.panel.active || [];
    $('#clear-all').classList.toggle('hidden', !can('clear') || !items.length);
    if (!items.length) { list.appendChild(el('div', 'empty', t('active_none'))); return; }
    items.forEach(function (a) {
      var type = validType(a.type);
      var c = el('div', 'card lvl-' + type);
      var head = el('div', 'c-head');
      head.appendChild(icon(type));
      head.appendChild(el('span', '', a.title));
      c.appendChild(head);
      c.appendChild(el('div', 'c-msg', a.message));
      var meta = el('div', 'c-meta');
      if (a.simulation) meta.appendChild(el('span', 'sim-tag', t('simulation_tag')));
      meta.appendChild(levelTag(type));
      if (a.region) meta.appendChild(el('span', '', t('region') + ': ' + a.region));
      meta.appendChild(el('span', '', targetText(a)));
      if (a.sender) meta.appendChild(el('span', '', t('sender') + ': ' + a.sender));
      var cd = el('span', '', t('remaining') + ': ');
      cd.appendChild(countdown(a.endsAt));
      meta.appendChild(cd);
      c.appendChild(meta);
      var actions = el('div', 'c-actions');
      if (can('edit')) {
        var eb = el('button', 'ghost-btn', t('edit')); eb.type = 'button';
        eb.addEventListener('click', function () { openEdit(a); });
        actions.appendChild(eb);
      }
      if (can('clear')) {
        var cb = el('button', 'ghost-btn danger', t('clear_alert')); cb.type = 'button';
        confirmButton(cb, function () { panelAction('clear', { id: a.id }); });
        actions.appendChild(cb);
      }
      c.appendChild(actions);
      list.appendChild(c);
    });
  }

  function renderHistory() {
    var box = $('#history-list');
    clear(box);
    var q = ($('#h-search').value || '').trim().toLowerCase();
    var lv = $('#h-level').value;
    var items = (S.panel.history || []).filter(function (a) {
      if (lv && a.type !== lv) return false;
      if (!q) return true;
      return [a.title, a.message, a.region, a.sender, a.id].join(' ').toLowerCase().indexOf(q) !== -1;
    });
    if (!items.length) { box.appendChild(el('div', 'empty', t('history_none'))); return; }
    items.forEach(function (a) { box.appendChild(alertRow(a)); });
  }

  function renderRegions() {
    var box = $('#region-list');
    clear(box);
    var regions = S.panel.regions || [];
    if (!regions.length) box.appendChild(el('div', 'empty', t('region_none')));
    regions.forEach(function (r) {
      var row = el('div', 'row reg');
      row.appendChild(el('div', 'r-title', r.name));
      row.appendChild(el('div', 'r-sub', r.x.toFixed(1) + ', ' + r.y.toFixed(1) + ', ' + r.z.toFixed(1)));
      row.appendChild(el('div', 'r-sub', r.radius + ' m'));
      var actions = el('div', 'c-actions');
      var eb = el('button', 'ghost-btn', t('edit')); eb.type = 'button';
      eb.addEventListener('click', function () { editRegion(r); });
      actions.appendChild(eb);
      var db = el('button', 'ghost-btn danger', t('delete')); db.type = 'button';
      confirmButton(db, function () { panelAction('deleteRegion', { name: r.name }); });
      actions.appendChild(db);
      row.appendChild(actions);
      box.appendChild(row);
    });
    var editable = can('regions');
    $('#region-form').classList.toggle('hidden', !editable);
    $$('#region-list .c-actions').forEach(function (n) { n.classList.toggle('hidden', !editable); });
  }

  function fillRegionSelect() {
    var sel = $('#c-region');
    var prev = sel.value;
    clear(sel);
    (S.panel.regions || []).forEach(function (r) {
      var o = el('option', '', r.name + ' (' + r.radius + ' m)');
      o.value = r.name;
      sel.appendChild(o);
    });
    if (prev) sel.value = prev;
    var customOpt = $('#c-target option[value="custom"]');
    if (customOpt) customOpt.hidden = !(S.panel.config && S.panel.config.allowCustomCoords);
  }

  function panelAction(action, payload) {
    postQuiet('panelAction', { action: action, payload: payload || {} });
  }

  // ───────── نموذج الإنشاء ─────────
  function updateTargetBoxes() {
    var k = $('#c-target').value;
    $('#t-region').classList.toggle('hidden', k !== 'region');
    $('#t-custom').classList.toggle('hidden', k !== 'custom');
    $('#t-player').classList.toggle('hidden', k !== 'player');
    $('#t-group').classList.toggle('hidden', k !== 'group');
    $('#t-radius').classList.toggle('hidden', k !== 'region' && k !== 'custom');
  }

  function updateTitleCounters() {
    var lim = (S.panel && S.panel.config && S.panel.config.limits) || { title: 60, message: 400 };
    var tl = len($('#c-title').value), ml = len($('#c-message').value);
    var tc = $('#c-title-count'), mc = $('#c-message-count');
    tc.textContent = tl + ' / ' + lim.title; tc.classList.toggle('over', tl > lim.title);
    mc.textContent = ml + ' / ' + lim.message; mc.classList.toggle('over', ml > lim.message);
  }

  function setCreating(on) {
    S.creating = on;
    var b = $('#c-send');
    b.disabled = on;
    b.textContent = on ? t('f_sending') : t('f_send');
  }

  function numOrUndef(id) {
    var v = $(id).value;
    if (v === '' || v === null) return undefined;
    var n = Number(v);
    return isFinite(n) ? n : undefined;
  }

  function submitCreate(ev) {
    ev.preventDefault();
    if (S.creating) return;
    var lim = (S.panel && S.panel.config && S.panel.config.limits) || { title: 60, message: 400 };
    var title = $('#c-title').value, message = $('#c-message').value.trim();
    if (!message) { toast(t('err_message_required'), false); return; }
    if (len(title) > lim.title) { toast(t('err_title_too_long'), false); return; }
    if (len(message) > lim.message) { toast(t('err_message_too_long'), false); return; }
    var kind = $('#c-target').value;
    var p = { title: title, message: message, type: $('#c-type').value, targetKind: kind, durationMin: numOrUndef('#c-duration') };
    if (kind === 'region') { p.region = $('#c-region').value; p.radius = numOrUndef('#c-radius'); }
    if (kind === 'custom') {
      p.label = $('#c-label').value; p.x = numOrUndef('#c-x'); p.y = numOrUndef('#c-y'); p.z = numOrUndef('#c-z'); p.radius = numOrUndef('#c-radius');
      if (p.x === undefined || p.y === undefined) { toast(t('err_invalid_coords'), false); return; }
      if (p.z === undefined) p.z = 0;
    }
    if (kind === 'player') p.player = numOrUndef('#c-player');
    if (kind === 'group') p.group = $('#c-group').value.trim();
    setCreating(true);
    panelAction('create', p);
    setTimeout(function () { if (S.creating) setCreating(false); }, 5000);
  }

  function myCoords(fill) {
    post('getMyCoords').then(function (r) { return r.json(); }).then(function (c) {
      if (c && typeof c.x === 'number') fill(c);
    }).catch(function () {});
  }
  function r2(n) { return Math.round(n * 100) / 100; }

  // ───────── تعديل تنبيه ─────────
  function openEdit(a) {
    S.editingAlert = a.id;
    $('#e-title').value = a.title;
    $('#e-message').value = a.message;
    $('#e-add').value = 0;
    $('#modal').classList.remove('hidden');
  }
  function submitEdit(ev) {
    ev.preventDefault();
    if (!S.editingAlert) return;
    panelAction('update', { id: S.editingAlert, title: $('#e-title').value, message: $('#e-message').value, addMinutes: numOrUndef('#e-add') || 0 });
    S.editingAlert = null;
    $('#modal').classList.add('hidden');
  }

  // ───────── المناطق ─────────
  function editRegion(r) {
    S.editingRegion = r.name;
    $('#r-name').value = r.name; $('#r-radius').value = r.radius;
    $('#r-x').value = r.x; $('#r-y').value = r.y; $('#r-z').value = r.z;
    $('#r-cancel').classList.remove('hidden');
    $('#r-name').focus();
  }
  function resetRegionForm() {
    S.editingRegion = null;
    ['#r-name', '#r-radius', '#r-x', '#r-y', '#r-z'].forEach(function (id) { $(id).value = ''; });
    $('#r-cancel').classList.add('hidden');
  }
  function submitRegion(ev) {
    ev.preventDefault();
    var name = $('#r-name').value.trim();
    var x = numOrUndef('#r-x'), y = numOrUndef('#r-y'), z = numOrUndef('#r-z'), radius = numOrUndef('#r-radius');
    if (!name || x === undefined || y === undefined || radius === undefined) { toast(t('err_invalid_region_data'), false); return; }
    panelAction('saveRegion', { oldName: S.editingRegion || undefined, name: name, x: x, y: y, z: z === undefined ? 0 : z, radius: radius });
  }

  // ───────────────────────── الأحداث ─────────────────────────
  function bindUI() {
    $('#app-icon').addEventListener('click', function () { showView('app'); });
    $('#app-back').addEventListener('click', function () { showView('home'); });
    $('#mark-all').addEventListener('click', function () {
      S.alerts.forEach(function (a) { a.read = true; });
      postQuiet('markAllRead'); renderPhone();
    });
    $('#clear-history').addEventListener('click', function () { postQuiet('clearHistory'); });
    $$('.seg').forEach(function (b) { b.addEventListener('click', function () { S.ptab = b.getAttribute('data-ptab'); renderPhone(); }); });
    $('#sheet-close').addEventListener('click', closeSheet);
    $('#home-indicator').addEventListener('click', function () {
      if (S.sheetId) { closeSheet(); return; }
      if (!$('#view-app').classList.contains('hidden')) { showView('home'); return; }
      postQuiet('closePhone');
    });

    $$('#panel-nav .nav-btn').forEach(function (b) { b.addEventListener('click', function () { setTab(b.getAttribute('data-tab')); }); });
    $('#panel-close').addEventListener('click', function () { postQuiet('closePanel'); });
    $('#c-target').addEventListener('change', updateTargetBoxes);
    $('#c-title').addEventListener('input', updateTitleCounters);
    $('#c-message').addEventListener('input', updateTitleCounters);
    $('#create-form').addEventListener('submit', submitCreate);
    $('#c-mypos').addEventListener('click', function () {
      myCoords(function (c) { $('#c-x').value = r2(c.x); $('#c-y').value = r2(c.y); $('#c-z').value = r2(c.z); });
    });
    $('#h-search').addEventListener('input', function () { if (S.panel) renderHistory(); });
    $('#h-level').addEventListener('change', function () { if (S.panel) renderHistory(); });
    confirmButton($('#clear-all'), function () { panelAction('clearAll'); });
    $('#region-form').addEventListener('submit', submitRegion);
    $('#r-cancel').addEventListener('click', resetRegionForm);
    $('#r-mypos').addEventListener('click', function () {
      myCoords(function (c) { $('#r-x').value = r2(c.x); $('#r-y').value = r2(c.y); $('#r-z').value = r2(c.z); });
    });
    confirmButton($('#r-reset'), function () { panelAction('resetRegions'); resetRegionForm(); });
    $('#edit-form').addEventListener('submit', submitEdit);
    $('#e-cancel').addEventListener('click', function () { S.editingAlert = null; $('#modal').classList.add('hidden'); });

    window.addEventListener('keydown', function (e) {
      if (e.key !== 'Escape') return;
      if (!$('#modal').classList.contains('hidden')) { $('#modal').classList.add('hidden'); return; }
      if (S.sheetId) { closeSheet(); return; }
      if (S.panelOpen) { postQuiet('closePanel'); return; }
      if (S.phoneOpen) postQuiet('closePhone');
    });
    window.addEventListener('resize', fitPhone);
    updateTargetBoxes();
  }

  function onPanelResult(r) {
    if (!r) return;
    if (r.action === 'create') {
      setCreating(false);
      if (r.ok) { $('#c-title').value = ''; $('#c-message').value = ''; updateTitleCounters(); }
    }
    if (r.action === 'saveRegion' && r.ok) resetRegionForm();
  }

  // ───────────────────────── رسائل Lua ─────────────────────────
  window.addEventListener('message', function (ev) {
    var m = ev.data;
    if (!m || typeof m.action !== 'string') return;
    switch (m.action) {
      case 'init': onInit(m); break;
      case 'notify': if (m.alert) showBanner(m.alert); break;
      case 'removeBanner': removeBanner(m.id); break;
      case 'dismissBanners': removeAllBanners(); break;
      case 'alerts': setAlerts(m.alerts); break;
      case 'phone': setPhone(m.show === true); break;
      case 'panel': if (m.show) openPanel(m.data); else closePanelUI(); break;
      case 'panelData': if (S.panelOpen) applyPanelData(m.data); break;
      case 'panelResult': onPanelResult(m.result); break;
      case 'toast': toast(m.msg || '', m.ok === true); break;
    }
  });

  // ───────────────────────── Boot ─────────────────────────
  bindUI();
  var readyTries = 0;
  (function sendReady() {
    if (S.initialized || readyTries++ > 60) return;
    postQuiet('ready');
    setTimeout(sendReady, 700);
  })();
})();
