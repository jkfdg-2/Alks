QSA = QSA or {}
QSA.Utils = QSA.Utils or {}
local U = QSA.Utils

QSA.Levels = { 'information', 'warning', 'alert', 'emergency' }

local TYPE_ALIASES = {
    information = 'information', info = 'information', i = 'information',
    ['معلومات'] = 'information', ['معلومة'] = 'information',
    warning = 'warning', warn = 'warning', w = 'warning', ['تحذير'] = 'warning',
    alert = 'alert', a = 'alert', ['إنذار'] = 'alert', ['انذار'] = 'alert',
    emergency = 'emergency', emerg = 'emergency', e = 'emergency',
    ['عاجل'] = 'emergency', ['طوارئ'] = 'emergency',
}

-- ترجمة: _L('key', ...) حسب Config.Language مع fallback للإنجليزية
function _L(key, ...)
    local pack = (Locales and (Locales[Config.Language] or Locales.en)) or {}
    local s = pack[key]
    if s == nil and Locales and Locales.en then s = Locales.en[key] end
    if s == nil then s = key end
    if select('#', ...) > 0 then
        local ok, res = pcall(string.format, s, ...)
        if ok then return res end
    end
    return s
end

function U.Debug(...)
    if Config.Debug then print('[qatar_secure_alert]', ...) end
end

function U.Trim(s)
    if type(s) ~= 'string' then return '' end
    local r = s:gsub('^%s+', '')
    r = r:gsub('%s+$', '')
    return r
end

function U.IsFinite(n)
    return type(n) == 'number' and n == n and n ~= math.huge and n ~= -math.huge
end

function U.NormalizeType(t)
    if type(t) ~= 'string' then return nil end
    return TYPE_ALIASES[string.lower(U.Trim(t))]
end

-- ينظف النص ويتحقق من الطول. يرجع: value  أو  nil, 'invalid'|'too_long'
function U.Sanitize(value, maxLen)
    if value == nil then return '' end
    if type(value) == 'number' then value = tostring(value) end
    if type(value) ~= 'string' then return nil, 'invalid' end
    -- حذف محارف التحكم عدا Tab (9) و New line (10)
    value = (value:gsub('[\0-\8\11-\31\127]', ''))
    value = U.Trim(value)
    value = (value:gsub('\n\n\n+', '\n\n'))
    local len = utf8.len(value)
    if not len then return nil, 'invalid' end
    if len > maxLen then return nil, 'too_long' end
    return value
end

-- يقبل vector3 أو {x=,y=,z=} أو {1,2,3}. يرجع x,y,z أو nil
function U.ToXYZ(c)
    if c == nil then return nil end
    local t = type(c)
    local x, y, z
    if t == 'table' then
        x, y, z = c.x or c[1], c.y or c[2], c.z or c[3]
    elseif t == 'vector3' or t == 'vector4' then
        x, y, z = c.x, c.y, c.z
    else
        return nil
    end
    x, y, z = tonumber(x), tonumber(y), tonumber(z or 0.0)
    if not x or not y or not z then return nil end
    if not (U.IsFinite(x) and U.IsFinite(y) and U.IsFinite(z)) then return nil end
    return x + 0.0, y + 0.0, z + 0.0
end

function U.Distance(ax, ay, az, bx, by, bz)
    local dx, dy = ax - bx, ay - by
    if Config.Use3DDistance then
        local dz = (az or 0.0) - (bz or 0.0)
        return math.sqrt(dx * dx + dy * dy + dz * dz)
    end
    return math.sqrt(dx * dx + dy * dy)
end

-- تقسيم نص الأمر مع دعم علامات الاقتباس "..."
function U.Tokenize(s)
    local tokens = {}
    if type(s) ~= 'string' then return tokens end
    local i, n = 1, #s
    while i <= n do
        local c = s:sub(i, i)
        if c:match('%s') then
            i = i + 1
        elseif c == '"' then
            local j = s:find('"', i + 1, true)
            if j then
                tokens[#tokens + 1] = s:sub(i + 1, j - 1)
                i = j + 1
            else
                tokens[#tokens + 1] = s:sub(i + 1)
                i = n + 1
            end
        else
            local j = s:find('%s', i)
            if j then
                tokens[#tokens + 1] = s:sub(i, j - 1)
                i = j
            else
                tokens[#tokens + 1] = s:sub(i)
                i = n + 1
            end
        end
    end
    return tokens
end
