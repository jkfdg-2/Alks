QSA = QSA or {}
QSA.Perms = {}
local P = QSA.Perms

local ROLE_ORDER = { 'viewer', 'operator', 'admin', 'superadmin' }
local ROLE_RANK = { viewer = 1, operator = 2, admin = 3, superadmin = 4 }
P.PERMISSIONS = { 'panel', 'dashboard', 'create', 'active', 'clear', 'edit', 'history', 'regions' }
P.ROLES = ROLE_ORDER

-- ───────────── Framework (اختياري) ─────────────
local fw = { name = 'standalone', obj = nil, warned = false }

local function wantedFramework()
    local want = string.lower(Config.Framework or 'standalone')
    if want == 'auto' then
        if GetResourceState('qb-core') == 'started' then return 'qbcore' end
        if GetResourceState('es_extended') == 'started' then return 'esx' end
        return 'standalone'
    end
    return want
end

-- يجلب كائن الـ Framework عند الحاجة (lazy) حتى لا يعتمد على ترتيب تشغيل الـ Resources
local function framework()
    local want = wantedFramework()
    if want == 'standalone' then return 'standalone', nil end
    if fw.obj and fw.name == want then return fw.name, fw.obj end
    local ok, obj
    if want == 'qbcore' then
        ok, obj = pcall(function() return exports['qb-core']:GetCoreObject() end)
    elseif want == 'esx' then
        ok, obj = pcall(function() return exports['es_extended']:getSharedObject() end)
    else
        return 'standalone', nil
    end
    if ok and obj then
        fw.name, fw.obj = want, obj
        return fw.name, fw.obj
    end
    if not fw.warned then
        fw.warned = true
        print(('[qatar_secure_alert] framework "%s" not available yet, using ACE/identifiers only.'):format(want))
    end
    return 'standalone', nil
end

-- إذا أُعيد تشغيل الـ Framework نمسح الكائن المخزّن ليُجلب من جديد
AddEventHandler('onResourceStop', function(res)
    if res == 'qb-core' or res == 'qbx_core' or res == 'es_extended' then fw.obj = nil end
end)

function P.FrameworkName()
    local name = framework()
    return name
end

local function frameworkRole(src)
    local name, obj = framework()
    if not obj then return nil end
    local best
    for _, role in ipairs(ROLE_ORDER) do
        local groups = (Config.AdminGroups and Config.AdminGroups[role]) or {}
        for _, group in ipairs(groups) do
            local has = false
            if name == 'qbcore' then
                local ok, r = pcall(obj.Functions.HasPermission, src, group)
                if not ok then fw.obj = nil end
                has = ok and r == true
            elseif name == 'esx' then
                local ok, xPlayer = pcall(obj.GetPlayerFromId, src)
                if not ok then fw.obj = nil end
                if ok and xPlayer and xPlayer.getGroup then
                    local okG, g = pcall(xPlayer.getGroup)
                    has = okG and g == group
                end
            end
            if has then best = role break end
        end
    end
    return best
end

-- ───────────── الأدوار ─────────────
-- يرجع أعلى دور للاعب أو nil. Console (0) = superadmin
function P.GetRole(src)
    src = tonumber(src)
    if src == nil then return nil end
    if src == 0 then return 'superadmin' end

    local best, bestRank = nil, 0
    local function consider(role)
        local r = role and ROLE_RANK[role]
        if r and r > bestRank then best, bestRank = role, r end
    end

    local ids = GetPlayerIdentifiers(src) or {}
    local map = Config.AdminIdentifiers or {}
    for _, id in ipairs(ids) do consider(map[id]) end

    for role, ace in pairs(Config.AcePermissions or {}) do
        if type(ace) == 'string' and ace ~= '' and IsPlayerAceAllowed(src, ace) then consider(role) end
    end

    consider(frameworkRole(src))
    return best
end

function P.PermissionSet(role)
    local set = {}
    if not role then return set end
    for _, perm in ipairs((Config.RolePermissions or {})[role] or {}) do
        if perm == '*' then
            for _, all in ipairs(P.PERMISSIONS) do set[all] = true end
        else
            set[perm] = true
        end
    end
    return set
end

-- يرجع: allowed(boolean), role
function P.Has(src, perm)
    local role = P.GetRole(src)
    if not role then return false, nil end
    return P.PermissionSet(role)[perm] == true, role
end

-- هل اللاعب ضمن مجموعة؟ (ACE qsa.group.<name> أو وظيفة QBCore/ESX أو Config.GroupResolver)
function P.PlayerInGroup(src, group)
    if type(group) ~= 'string' or group == '' then return false end
    if IsPlayerAceAllowed(src, 'qsa.group.' .. group) then return true end
    if type(Config.GroupResolver) == 'function' then
        local ok, r = pcall(Config.GroupResolver, src, group)
        if ok and r == true then return true end
    end
    local name, obj = framework()
    if not obj then return false end
    if name == 'qbcore' then
        local ok, player = pcall(obj.Functions.GetPlayer, src)
        local job = ok and player and player.PlayerData and player.PlayerData.job
        return job ~= nil and job.name == group
    elseif name == 'esx' then
        local ok, xPlayer = pcall(obj.GetPlayerFromId, src)
        local job = ok and xPlayer and xPlayer.job
        return job ~= nil and job.name == group
    end
    return false
end

-- ───────────── Rate limiting (نافذة بالثواني) ─────────────
local buckets = {}

function P.RateLimit(src, name, max, windowSec)
    local now = os.time()
    local key = tostring(src) .. ':' .. name
    local fresh = {}
    for _, t in ipairs(buckets[key] or {}) do
        if now - t < windowSec then fresh[#fresh + 1] = t end
    end
    if #fresh >= max then
        buckets[key] = fresh
        return false
    end
    fresh[#fresh + 1] = now
    buckets[key] = fresh
    return true
end

function P.ClearBuckets(src)
    local prefix = tostring(src) .. ':'
    for k in pairs(buckets) do
        if k:sub(1, #prefix) == prefix then buckets[k] = nil end
    end
end
