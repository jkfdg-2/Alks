QSA = QSA or {}
QSA.Logs = { buffer = {} }

local COLORS = {
    create = 15105570, clear = 9807270, expire = 9807270, edit = 3447003,
    panel_open = 3066993, unauthorized = 15158332, rate_limited = 15844367, region = 10181046,
}
local MAX_BUFFER = 200
local hookWindow = { start = 0, count = 0 }

local function webhookUrl()
    local cfg = Config.Webhook or {}
    if cfg.url and cfg.url ~= '' then return cfg.url end
    return GetConvar('qsa_discord_webhook', '')
end

local function actorLabel(src)
    src = tonumber(src)
    if not src or src == 0 then return 'Console' end
    local name = GetPlayerName(src) or 'unknown'
    local license = ''
    for _, id in ipairs(GetPlayerIdentifiers(src) or {}) do
        if id:sub(1, 8) == 'license:' then license = id break end
    end
    if license ~= '' then return ('%s [%d] (%s)'):format(name, src, license) end
    return ('%s [%d]'):format(name, src)
end

local function detailsToString(details)
    if details == nil then return '' end
    if type(details) == 'string' then return details end
    local ok, s = pcall(json.encode, details)
    return ok and s or tostring(details)
end

local function truncate(s, n)
    if #s <= n then return s end
    return s:sub(1, n - 3) .. '...'
end

local function sendWebhook(action, actor, details)
    local cfg = Config.Webhook or {}
    if not cfg.enabled then return end
    if not (cfg.events and cfg.events[action]) then return end
    local url = webhookUrl()
    if url == '' then return end
    local now = os.time()
    if now - hookWindow.start >= 60 then hookWindow.start, hookWindow.count = now, 0 end
    if hookWindow.count >= 20 then return end -- حماية من تجاوز حد Discord
    hookWindow.count = hookWindow.count + 1

    local body = json.encode({
        username = cfg.username or 'Secure Alert',
        allowed_mentions = { parse = {} },
        embeds = { {
            title = ('Secure Alert | %s'):format(action),
            description = truncate(('**Actor:** %s\n%s'):format(actor, details), 1800),
            color = COLORS[action] or 8355711,
            timestamp = os.date('!%Y-%m-%dT%H:%M:%SZ', now),
        } },
    })
    PerformHttpRequest(url, function() end, 'POST', body, { ['Content-Type'] = 'application/json' })
end

-- QSA.Log('create', src, {id=...})
function QSA.Log(action, src, details)
    local actor = actorLabel(src)
    local text = detailsToString(details)
    local now = os.time()

    local buf = QSA.Logs.buffer
    buf[#buf + 1] = { action = action, actor = actor, details = text, at = now }
    if #buf > MAX_BUFFER then table.remove(buf, 1) end

    print(('[qatar_secure_alert][%s] %s %s'):format(action, actor, text))

    QSA.DB.Exec('INSERT INTO secure_alert_logs (action, actor, details, created_at) VALUES (?, ?, ?, ?)',
        { action, truncate(actor, 160), text, now })
    sendWebhook(action, actor, text)
end
