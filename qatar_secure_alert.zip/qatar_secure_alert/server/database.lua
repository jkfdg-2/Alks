-- قاعدة البيانات اختيارية (oxmysql). إذا لم تتوفر يعمل النظام بالذاكرة فقط.
QSA = QSA or {}
QSA.DB = { enabled = false }
local DB = QSA.DB

local SCHEMA = {
    [[CREATE TABLE IF NOT EXISTS `secure_alerts` (
        `alert_id` VARCHAR(40) NOT NULL,
        `sender` VARCHAR(120) NOT NULL DEFAULT '',
        `title` VARCHAR(255) NOT NULL,
        `message` TEXT NOT NULL,
        `type` VARCHAR(20) NOT NULL,
        `region` VARCHAR(100) NOT NULL DEFAULT '',
        `payload` LONGTEXT NULL,
        `created_at` BIGINT NOT NULL,
        `expires_at` BIGINT NOT NULL,
        PRIMARY KEY (`alert_id`),
        KEY `idx_expires` (`expires_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci]],
    [[CREATE TABLE IF NOT EXISTS `secure_alert_history` (
        `alert_id` VARCHAR(40) NOT NULL,
        `sender` VARCHAR(120) NOT NULL DEFAULT '',
        `title` VARCHAR(255) NOT NULL,
        `message` TEXT NOT NULL,
        `type` VARCHAR(20) NOT NULL,
        `region` VARCHAR(100) NOT NULL DEFAULT '',
        `status` VARCHAR(20) NOT NULL DEFAULT 'active',
        `ended_by` VARCHAR(120) NOT NULL DEFAULT '',
        `simulation` TINYINT(1) NOT NULL DEFAULT 0,
        `created_at` BIGINT NOT NULL,
        `expires_at` BIGINT NOT NULL,
        `ended_at` BIGINT NOT NULL DEFAULT 0,
        PRIMARY KEY (`alert_id`),
        KEY `idx_created` (`created_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci]],
    [[CREATE TABLE IF NOT EXISTS `secure_alert_logs` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `action` VARCHAR(40) NOT NULL,
        `actor` VARCHAR(160) NOT NULL DEFAULT '',
        `details` TEXT NULL,
        `created_at` BIGINT NOT NULL,
        PRIMARY KEY (`id`),
        KEY `idx_action` (`action`),
        KEY `idx_created` (`created_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci]],
}

-- تنفيذ استعلام (callback اختياري). لا يرمي أخطاء إذا لم تتوفر القاعدة.
function DB.Exec(sql, params, cb)
    if not DB.enabled then
        if cb then cb(nil) end
        return
    end
    local resource = (Config.Database and Config.Database.resource) or 'oxmysql'
    local ok, err = pcall(function()
        exports[resource]:query(sql, params or {}, function(result)
            if cb then cb(result) end
        end)
    end)
    if not ok then
        print(('[qatar_secure_alert] database error: %s'):format(tostring(err)))
        if cb then cb(nil) end
    end
end

-- يفعّل القاعدة إن وُجدت ويُنشئ الجداول. onReady(enabled)
function DB.Init(onReady)
    local cfg = Config.Database or {}
    if not cfg.enabled then
        DB.enabled = false
        if onReady then onReady(false) end
        return
    end
    if GetResourceState(cfg.resource or 'oxmysql') ~= 'started' then
        DB.enabled = false
        print('[qatar_secure_alert] oxmysql not started: running without database (history kept in memory).')
        if onReady then onReady(false) end
        return
    end
    DB.enabled = true
    local function step(i)
        if i > #SCHEMA then
            print('[qatar_secure_alert] database ready (secure_alerts, secure_alert_history, secure_alert_logs).')
            if onReady then onReady(true) end
            return
        end
        DB.Exec(SCHEMA[i], {}, function() step(i + 1) end)
    end
    step(1)
end
