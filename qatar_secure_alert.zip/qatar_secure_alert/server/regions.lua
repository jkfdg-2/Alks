QSA = QSA or {}
QSA.Regions = {}
local R = QSA.Regions
local U = QSA.Utils

local KVP_KEY = 'qsa_regions_v1'
local list = {}

local function normalize(r)
    if type(r) ~= 'table' then return nil end
    local name = U.Sanitize(r.name, 40)
    if not name or name == '' or name:find('\n', 1, true) then return nil end
    local x, y, z = U.ToXYZ(r.coords or r)
    local radius = tonumber(r.radius)
    if not x then return nil end
    if math.abs(x) > 20000 or math.abs(y) > 20000 or math.abs(z) > 5000 then return nil end
    local L = Config.Limits
    if not radius or not U.IsFinite(radius) or radius < L.minRadius or radius > L.maxRadius then return nil end
    return { name = name, x = x, y = y, z = z, radius = radius + 0.0 }
end

local function sameName(a, b)
    return string.lower(a) == string.lower(b)
end

local function indexOf(name)
    for i, r in ipairs(list) do
        if sameName(r.name, name) then return i end
    end
end

local function loadFromConfig()
    list = {}
    for _, r in ipairs(Config.Regions or {}) do
        local n = normalize(r)
        if n and not indexOf(n.name) then
            list[#list + 1] = n
        else
            print(('[qatar_secure_alert] invalid or duplicate region in Config.Regions ignored: %s'):format(tostring(r and r.name)))
        end
    end
end

function R.Load()
    local raw = GetResourceKvpString(KVP_KEY)
    if raw and raw ~= '' then
        local ok, decoded = pcall(json.decode, raw)
        if ok and type(decoded) == 'table' then
            list = {}
            for _, r in ipairs(decoded) do
                local n = normalize(r)
                if n and not indexOf(n.name) then list[#list + 1] = n end
            end
            return
        end
    end
    loadFromConfig()
end

local function save()
    SetResourceKvp(KVP_KEY, json.encode(list))
end

function R.List()
    local out = {}
    for i, r in ipairs(list) do
        out[i] = { name = r.name, x = r.x, y = r.y, z = r.z, radius = r.radius }
    end
    return out
end

function R.Find(name)
    if type(name) ~= 'string' then return nil end
    name = U.Trim(name)
    local i = indexOf(name)
    return i and list[i] or nil
end

-- إضافة أو تعديل. oldName=nil => إضافة. يرجع true أو false, errKey
function R.Upsert(oldName, data)
    local n = normalize(data)
    if not n then return false, 'invalid_region_data' end
    if oldName ~= nil and oldName ~= '' then
        local i = indexOf(oldName)
        if not i then return false, 'region_not_found' end
        local clash = indexOf(n.name)
        if clash and clash ~= i then return false, 'region_exists' end
        list[i] = n
    else
        local i = indexOf(n.name)
        if i then return false, 'region_exists' end
        list[#list + 1] = n
    end
    save()
    return true, n
end

function R.Delete(name)
    local i = indexOf(type(name) == 'string' and name or '')
    if not i then return false, 'region_not_found' end
    table.remove(list, i)
    save()
    return true
end

function R.Reset()
    DeleteResourceKvp(KVP_KEY)
    loadFromConfig()
    return true
end
