QSA = QSA or {}
QSA.Alerts = {}
QSA.State = {
    active = {},        -- id -> alert
    history = {},       -- newest first (حد أقصى Config.MaxAlertHistory)
    delivered = {},     -- id -> { [src] = true }
    panelViewers = {},  -- src -> true
    lastCreate = {},    -- src -> os.time()
    counters = { total = 0, cleared = 0, expired = 0 },
    watcher = false,
}

local A, S, U, P = QSA.Alerts, QSA.State, QSA.Utils, QSA.Perms

-- ═════════════ أدوات داخلية ═════════════
local function onlinePlayerSet()
    local set = {}
    for _, p in ipairs(GetPlayers()) do set[tonumber(p)] = true end
    return set
end

local function playerCoords(src)
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return nil end
    local c = GetEntityCoords(ped)
    if not c then return nil end
    return c.x, c.y, c.z
end

local function newId()
    local id
    repeat
        id = ('QSA-%s-%04d'):format(os.date('%y%m%d-%H%M%S'), math.random(0, 9999))
    until not S.active[id]
    return id
end

local function resolveTarget(data)
    local t = data.target
    local kind, value
    if type(t) == 'table' then
        kind, value = t.kind or t.type, t.value
    elseif type(t) == 'string' then
        kind = t
    end
    if kind == nil then
        if data.player ~= nil then kind = 'player'
        elseif data.group ~= nil then kind = 'group'
        elseif data.region ~= nil or data.coords ~= nil then kind = 'region'
        else kind = 'all' end
    end
    if type(kind) ~= 'string' then return nil end
    kind = string.lower(kind)
    if kind == 'custom' then kind = 'region' end
    if kind == 'player' then
        if value == nil then value = data.player end
    elseif kind == 'group' then
        if value == nil then value = data.group end
    elseif kind ~= 'all' and kind ~= 'region' then
        return nil
    end
    return kind, value
end

-- ═════════════ التحقق وبناء الإنذار ═════════════
-- ctx = { src = number|nil, trusted = bool, sender = string|nil, role = string|nil }
function A.Build(data, ctx)
    ctx = ctx or {}
    if type(data) ~= 'table' then return nil, 'invalid_data' end
    local L = Config.Limits

    local atype = U.NormalizeType(data.type == nil and 'information' or data.type)
    if not atype then return nil, 'invalid_type' end

    local title, terr = U.Sanitize(data.title, L.title)
    if terr then return nil, (terr == 'too_long') and 'title_too_long' or 'invalid_text' end
    if title == '' then title = _L('default_title') end

    local message, merr = U.Sanitize(data.message, L.message)
    if merr then return nil, (merr == 'too_long') and 'message_too_long' or 'invalid_text' end
    if message == '' then return nil, 'message_required' end

    local duration = data.duration
    if duration == nil then duration = Config.DefaultDuration end
    duration = tonumber(duration)
    if not duration or not U.IsFinite(duration) or duration < L.minDuration or duration > L.maxDuration then
        return nil, 'invalid_duration'
    end
    duration = math.floor(duration)

    local kind, value = resolveTarget(data)
    if not kind then return nil, 'invalid_target' end

    -- المنطقة / الإحداثيات
    local x, y, z, radius, regionName
    if data.coords ~= nil then
        if not (ctx.trusted or Config.AllowCustomCoords) then return nil, 'custom_coords_disabled' end
        x, y, z = U.ToXYZ(data.coords)
        if not x or math.abs(x) > 20000 or math.abs(y) > 20000 or math.abs(z) > 5000 then
            return nil, 'invalid_coords'
        end
        local label, lerr = U.Sanitize(data.regionLabel or data.region, 60)
        if lerr then return nil, 'invalid_text' end
        regionName = (label ~= '' and label) or _L('custom_area')
        radius = tonumber(data.radius)
        if radius == nil and kind == 'region' then return nil, 'invalid_radius' end
    elseif data.region ~= nil and data.region ~= '' then
        local r = QSA.Regions.Find(data.region)
        if not r then return nil, 'invalid_region' end
        x, y, z, regionName = r.x, r.y, r.z, r.name
        radius = tonumber(data.radius) or r.radius
    elseif kind == 'region' then
        return nil, 'region_required'
    end
    if radius ~= nil then
        if not U.IsFinite(radius) or radius < L.minRadius or radius > L.maxRadius then
            return nil, 'invalid_radius'
        end
        radius = radius + 0.0
    end

    -- اللاعب / المجموعة
    if kind == 'player' then
        local pid = tonumber(value)
        if not pid or pid ~= math.floor(pid) or not onlinePlayerSet()[pid] then return nil, 'player_not_found' end
        value = pid
    elseif kind == 'group' then
        if type(value) ~= 'string' or #value > 32 or not value:match('^[%w_%-%.]+$') then
            return nil, 'invalid_group'
        end
    else
        value = nil
    end

    local sender = ctx.sender
    if not sender then
        if ctx.src and ctx.src > 0 then
            sender = ('%s [%d]'):format(GetPlayerName(ctx.src) or 'unknown', ctx.src)
        else
            sender = 'Console'
        end
    end

    local now = os.time()
    return {
        id = newId(),
        sender = sender,
        sender_id = ctx.src or 0,
        sender_role = ctx.role or '',
        title = title,
        message = message,
        type = atype,
        region = regionName,
        x = x, y = y, z = z,
        radius = radius,
        target_kind = kind,
        target_value = value,
        simulation = (Config.SimulationMode == true) or (data.simulation == true),
        created_at = now,
        expires_at = now + duration,
        status = 'active',
    }
end

-- نسخة بيانات بسيطة (بدون vectors) للـ Exports / الكلاينت / اللوحة
function A.Public(alert, forPanel)
    local t = {
        id = alert.id, title = alert.title, message = alert.message, type = alert.type,
        region = alert.region, radius = alert.radius,
        created_at = alert.created_at, expires_at = alert.expires_at,
        status = alert.status, simulation = alert.simulation == true,
    }
    if alert.x then t.coords = { x = alert.x, y = alert.y, z = alert.z } end
    if forPanel then
        t.sender = alert.sender
        t.target_kind = alert.target_kind
        t.target_value = alert.target_value
        t.ended_at = alert.ended_at
        t.ended_by = alert.ended_by
    elseif Config.ShowSenderToPlayers then
        t.sender = alert.sender
    end
    return t
end

-- ═════════════ الاستهداف والتوصيل ═════════════
function A.IsEligible(alert, src)
    local kind = alert.target_kind
    if kind == 'all' then return true end
    if kind == 'player' then return tonumber(alert.target_value) == src end
    if kind == 'group' then return P.PlayerInGroup(src, alert.target_value) end
    if kind == 'region' then
        local px, py, pz = playerCoords(src)
        if not px or not alert.x or not alert.radius then return false end
        return U.Distance(px, py, pz, alert.x, alert.y, alert.z) <= alert.radius
    end
    return false
end

function A.Deliver(alert, src, isUpdate)
    local payload = A.Public(alert, false)
    payload.ttl = math.max(0, alert.expires_at - os.time())
    if isUpdate then payload.update = true end
    TriggerClientEvent('qatar_secure_alert:client:receiveAlert', src, payload)
    local d = S.delivered[alert.id]
    if not d then d = {}; S.delivered[alert.id] = d end
    d[src] = true
end

-- يوصّل لمن لم يستلم بعد وينطبق عليه الاستهداف. يرجع عدد من وصلهم
function A.DeliverPending(alert)
    local d = S.delivered[alert.id]
    if not d then d = {}; S.delivered[alert.id] = d end
    local count = 0
    for _, p in ipairs(GetPlayers()) do
        local src = tonumber(p)
        if src and not d[src] and A.IsEligible(alert, src) then
            A.Deliver(alert, src)
            count = count + 1
        end
    end
    return count
end

-- مزامنة لاعب (دخول السيرفر / إعادة تشغيل الـ Resource): يرسل كل النشط المناسب له
function A.SyncPlayer(src)
    local n = 0
    for _, alert in pairs(S.active) do
        if A.IsEligible(alert, src) then
            A.Deliver(alert, src)
            n = n + 1
        end
    end
    return n
end

local function ensureWatcher()
    local interval = tonumber(Config.LateEntrantInterval) or 0
    if S.watcher or interval <= 0 then return end
    S.watcher = true
    CreateThread(function()
        while next(S.active) do
            Wait(interval)
            for _, alert in pairs(S.active) do
                if alert.target_kind ~= 'player' then A.DeliverPending(alert) end
            end
        end
        S.watcher = false
    end)
end

-- ═════════════ قاعدة البيانات ═════════════
local function persistActive(a)
    QSA.DB.Exec('REPLACE INTO secure_alerts (alert_id, sender, title, message, type, region, payload, created_at, expires_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
        { a.id, a.sender or '', a.title, a.message, a.type, a.region or '', json.encode({
            x = a.x, y = a.y, z = a.z, radius = a.radius,
            target_kind = a.target_kind, target_value = a.target_value,
            simulation = a.simulation, sender_id = a.sender_id, sender_role = a.sender_role,
        }), a.created_at, a.expires_at })
end

local function persistHistory(a)
    QSA.DB.Exec('REPLACE INTO secure_alert_history (alert_id, sender, title, message, type, region, status, ended_by, simulation, created_at, expires_at, ended_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        { a.id, a.sender or '', a.title, a.message, a.type, a.region or '', a.status, a.ended_by or '',
          a.simulation and 1 or 0, a.created_at, a.expires_at, a.ended_at or 0 })
end

-- ═════════════ إنشاء / تعديل / إلغاء ═════════════
local function scheduleExpiry(alert)
    alert.expiry_token = (alert.expiry_token or 0) + 1
    local token = alert.expiry_token
    local function arm()
        local ms = math.max(0, alert.expires_at - os.time()) * 1000 + 250
        SetTimeout(ms, function()
            local cur = S.active[alert.id]
            if not cur or cur ~= alert or alert.expiry_token ~= token then return end
            if alert.expires_at > os.time() then arm() return end
            A.End(alert.id, 'expired', 'system')
        end)
    end
    arm()
end

-- يرجع alert, deliveredCount  أو  nil, errKey
function A.Create(data, ctx)
    local alert, err = A.Build(data, ctx)
    if not alert then return nil, err end

    S.active[alert.id] = alert
    table.insert(S.history, 1, alert)
    while #S.history > Config.MaxAlertHistory do table.remove(S.history) end
    S.counters.total = S.counters.total + 1

    persistActive(alert)
    persistHistory(alert)
    scheduleExpiry(alert)

    local count = A.DeliverPending(alert)
    ensureWatcher()

    QSA.Log('create', (ctx and ctx.src) or 0, {
        id = alert.id, type = alert.type, title = alert.title, target = alert.target_kind,
        region = alert.region, sender = alert.sender, simulation = alert.simulation, delivered = count,
    })
    QSA.BroadcastPanel()
    return alert, count
end

-- status: 'cleared' | 'expired'
function A.End(id, status, actor)
    local alert = S.active[id]
    if not alert then return false end
    S.active[id] = nil
    alert.status = status
    alert.ended_at = os.time()
    alert.ended_by = actor or ''
    if status == 'expired' then
        S.counters.expired = S.counters.expired + 1
    else
        S.counters.cleared = S.counters.cleared + 1
    end

    local d = S.delivered[id]
    S.delivered[id] = nil
    for src in pairs(d or {}) do
        TriggerClientEvent('qatar_secure_alert:client:clearAlert', src, id, status)
    end

    QSA.DB.Exec('DELETE FROM secure_alerts WHERE alert_id = ?', { id })
    persistHistory(alert)
    QSA.Log(status == 'expired' and 'expire' or 'clear', (type(actor) == 'number') and actor or 0,
        { id = id, status = status, by = tostring(actor or '') })
    QSA.BroadcastPanel()
    return true
end

function A.ClearAll(actor)
    local ids = {}
    for id in pairs(S.active) do ids[#ids + 1] = id end
    local n = 0
    for _, id in ipairs(ids) do
        if A.End(id, 'cleared', actor) then n = n + 1 end
    end
    return n
end

-- fields = { title=, message=, addSeconds= }
function A.Update(id, fields, actor, actorSrc)
    local a = S.active[id]
    if not a then return false, 'alert_not_found' end
    if type(fields) ~= 'table' then return false, 'invalid_data' end
    local L = Config.Limits

    local newTitle, newMessage
    if fields.title ~= nil then
        local v, e = U.Sanitize(fields.title, L.title)
        if e then return false, (e == 'too_long') and 'title_too_long' or 'invalid_text' end
        if v ~= '' then newTitle = v end
    end
    if fields.message ~= nil then
        local v, e = U.Sanitize(fields.message, L.message)
        if e then return false, (e == 'too_long') and 'message_too_long' or 'invalid_text' end
        if v ~= '' then newMessage = v end
    end
    local newExpires
    local add = tonumber(fields.addSeconds)
    if add and add ~= 0 and U.IsFinite(add) then
        newExpires = a.expires_at + math.floor(add)
        local remaining = newExpires - os.time()
        if remaining < L.minDuration or remaining > L.maxDuration then return false, 'invalid_duration' end
    end

    if newTitle then a.title = newTitle end
    if newMessage then a.message = newMessage end
    if newExpires then
        a.expires_at = newExpires
        scheduleExpiry(a)
    end

    persistActive(a)
    persistHistory(a)
    for src in pairs(S.delivered[id] or {}) do A.Deliver(a, src, true) end

    QSA.Log('edit', actorSrc or 0, { id = id, title = a.title, expires_at = a.expires_at, by = tostring(actor or '') })
    QSA.BroadcastPanel()
    return true
end

-- ═════════════ استعلامات ═════════════
function A.GetActiveList(forPanel)
    local list = {}
    for _, a in pairs(S.active) do list[#list + 1] = A.Public(a, forPanel) end
    table.sort(list, function(x, y) return x.created_at > y.created_at end)
    return list
end

function A.GetHistoryList()
    local list = {}
    for _, a in ipairs(S.history) do list[#list + 1] = A.Public(a, true) end
    return list
end

-- هل اللاعب داخل نطاق أي إنذار نشط؟  true, alertId
function A.IsPlayerInAlertZone(src)
    src = tonumber(src)
    if not src then return false end
    local px, py, pz = playerCoords(src)
    if not px then return false end
    for id, a in pairs(S.active) do
        if a.x and a.radius and U.Distance(px, py, pz, a.x, a.y, a.z) <= a.radius then
            return true, id
        end
    end
    return false
end

-- ═════════════ تحميل من قاعدة البيانات ═════════════
local function rowToAlert(row)
    return {
        id = row.alert_id, sender = row.sender or '', title = row.title, message = row.message,
        type = row.type, region = (row.region and row.region ~= '') and row.region or nil,
        status = row.status or 'active', ended_by = row.ended_by or '',
        simulation = tonumber(row.simulation) == 1,
        created_at = tonumber(row.created_at) or 0, expires_at = tonumber(row.expires_at) or 0,
        ended_at = tonumber(row.ended_at) or 0, sender_id = 0, sender_role = '',
        target_kind = 'all',
    }
end

function A.LoadFromDB(cb)
    if not QSA.DB.enabled then if cb then cb() end return end
    local now = os.time()
    local limit = math.floor(tonumber(Config.MaxAlertHistory) or 50)

    QSA.DB.Exec('UPDATE secure_alert_history SET status = ?, ended_at = expires_at WHERE status = ? AND expires_at <= ?',
        { 'expired', 'active', now }, function()
    QSA.DB.Exec('DELETE FROM secure_alerts WHERE expires_at <= ?', { now }, function()
    QSA.DB.Exec('SELECT * FROM secure_alert_history ORDER BY created_at DESC LIMIT ' .. limit, {}, function(hrows)
        S.history = {}
        for _, row in ipairs(hrows or {}) do S.history[#S.history + 1] = rowToAlert(row) end

        QSA.DB.Exec('SELECT * FROM secure_alerts WHERE expires_at > ?', { now }, function(arows)
            for _, row in ipairs(arows or {}) do
                local alert
                for _, h in ipairs(S.history) do
                    if h.id == row.alert_id then alert = h break end
                end
                if not alert then
                    alert = rowToAlert(row)
                    table.insert(S.history, 1, alert)
                end
                local okp, payload = pcall(json.decode, row.payload or '{}')
                payload = (okp and type(payload) == 'table') and payload or {}
                alert.status = 'active'
                alert.x, alert.y, alert.z, alert.radius = payload.x, payload.y, payload.z, payload.radius
                alert.target_kind = payload.target_kind or 'all'
                alert.target_value = payload.target_value
                alert.simulation = payload.simulation == true
                alert.sender_id = payload.sender_id or 0
                alert.sender_role = payload.sender_role or ''
                S.active[alert.id] = alert
                scheduleExpiry(alert)
            end
            while #S.history > Config.MaxAlertHistory do table.remove(S.history) end

            QSA.DB.Exec('SELECT COUNT(*) AS c FROM secure_alert_history', {}, function(crow)
                local c = crow and crow[1] and tonumber(crow[1].c)
                if c then S.counters.total = c end
                for _, alert in pairs(S.active) do A.DeliverPending(alert) end
                if next(S.active) then ensureWatcher() end
                if cb then cb() end
            end)
        end)
    end) end) end)
end

function A.OnPlayerDropped(src)
    S.panelViewers[src] = nil
    S.lastCreate[src] = nil
    P.ClearBuckets(src)
    for _, d in pairs(S.delivered) do d[src] = nil end
end
