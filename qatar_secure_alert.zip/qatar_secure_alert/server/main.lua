QSA = QSA or {}
local A, S, U, P = QSA.Alerts, QSA.State, QSA.Utils, QSA.Perms
local EVT = 'qatar_secure_alert:'

-- ═════════════ مساعدات ═════════════
local function errMsg(err)
    local key = 'err_' .. tostring(err)
    local msg = _L(key)
    if msg == key then return _L('err_unknown') end
    return msg
end

local function reply(src, ok, msg)
    if src == 0 then
        print(('[qatar_secure_alert] %s'):format(msg))
    else
        TriggerClientEvent(EVT .. 'client:feedback', src, { ok = ok, msg = msg })
    end
end

-- التحقق من الصلاحية في السيرفر + تسجيل المحاولة غير المسموحة. يرجع الدور أو nil
local function requirePerm(src, perm, action)
    local allowed, role = P.Has(src, perm)
    if not allowed then
        QSA.Log('unauthorized', src, { action = action, perm = perm, role = role or 'none' })
        reply(src, false, _L('err_no_permission'))
        return nil
    end
    return role
end

local function rateLimited(src, bucket)
    if src == 0 then return false end
    local cfg = (Config.RateLimit or {})[bucket] or { max = 20, window = 10 }
    if P.RateLimit(src, bucket, cfg.max, cfg.window) then return false end
    QSA.Log('rate_limited', src, { bucket = bucket })
    reply(src, false, _L('err_rate_limited'))
    return true
end

local function validSource(src)
    src = tonumber(src)
    if not src or src <= 0 then return nil end
    return src
end

-- إنشاء إنذار بصلاحيات المستخدم. يرجع ok, alert|errKey, count
local function userCreate(src, data, via)
    local role = requirePerm(src, 'create', via)
    if not role then return false, 'no_permission' end
    if rateLimited(src, 'create') then return false, 'rate_limited' end

    if src > 0 then
        local cooldown = tonumber(Config.AlertCooldown) or 0
        local last = S.lastCreate[src]
        local now = os.time()
        if cooldown > 0 and last and now - last < cooldown then
            reply(src, false, _L('err_cooldown', cooldown - (now - last)))
            return false, 'cooldown'
        end
    end

    local alert, countOrErr = A.Create(data, { src = src, role = role })
    if not alert then
        reply(src, false, errMsg(countOrErr))
        return false, countOrErr
    end
    if src > 0 then S.lastCreate[src] = os.time() end
    reply(src, true, _L('ok_sent', alert.id, countOrErr))
    return true, alert, countOrErr
end

-- ═════════════ لوحة التحكم: البيانات ═════════════
local function countActive()
    local n = 0
    for _ in pairs(S.active) do n = n + 1 end
    return n
end

function QSA.BuildPanelData(src)
    local role = P.GetRole(src)
    local perms = P.PermissionSet(role)
    if not perms.panel then return nil end
    local L = Config.Limits
    local d = {
        role = role,
        perms = perms,
        serverTime = os.time(),
        config = {
            simulation = Config.SimulationMode == true,
            allowCustomCoords = Config.AllowCustomCoords == true,
            limits = {
                title = L.title, message = L.message,
                minRadius = L.minRadius, maxRadius = L.maxRadius,
                minDurationMin = math.ceil(L.minDuration / 60), maxDurationMin = math.floor(L.maxDuration / 60),
            },
            defaultDurationMin = math.max(1, math.floor((Config.DefaultDuration or 300) / 60)),
        },
    }
    if perms.dashboard then
        local recent = {}
        for i = 1, math.min(5, #S.history) do recent[i] = A.Public(S.history[i], true) end
        d.stats = {
            players = #GetPlayers(),
            total = S.counters.total,
            active = countActive(),
            cleared = S.counters.cleared,
            expired = S.counters.expired,
        }
        d.recent = recent
    end
    if perms.active then d.active = A.GetActiveList(true) end
    if perms.history then d.history = A.GetHistoryList() end
    if perms.create or perms.regions then d.regions = QSA.Regions.List() end
    return d
end

function QSA.PushPanel(src)
    local data = QSA.BuildPanelData(src)
    if data then
        TriggerClientEvent(EVT .. 'client:panelData', src, data)
    else
        S.panelViewers[src] = nil
        TriggerClientEvent(EVT .. 'client:panelClosed', src)
    end
end

local broadcastPending = false
function QSA.BroadcastPanel()
    if broadcastPending or not next(S.panelViewers) then return end
    broadcastPending = true
    SetTimeout(300, function()
        broadcastPending = false
        for src in pairs(S.panelViewers) do
            if GetPlayerName(src) then QSA.PushPanel(src) else S.panelViewers[src] = nil end
        end
    end)
end

local function openPanel(src)
    src = validSource(src)
    if not src then return end
    if rateLimited(src, 'panel') then return end
    local role = requirePerm(src, 'panel', 'panel_open')
    if not role then return end
    S.panelViewers[src] = true
    QSA.Log('panel_open', src, { role = role })
    TriggerClientEvent(EVT .. 'client:openPanel', src, QSA.BuildPanelData(src))
end

-- ═════════════ أحداث الشبكة (كلها تُفحص في السيرفر) ═════════════
-- API للـ Resources الأخرى على الكلاينت: يتطلب أن يملك اللاعب صلاحية create.
-- للـ Resources على السيرفر استخدم exports (SendAlert) لأنها موثوقة وبدون صلاحيات لاعب.
RegisterNetEvent(EVT .. 'server:sendAlert', function(data)
    local src = validSource(source)
    if not src then
        print('[qatar_secure_alert] server:sendAlert is a client->server event. From server scripts use exports["qatar_secure_alert"]:SendAlert(data).')
        return
    end
    if type(data) ~= 'table' then return end
    userCreate(src, data, 'event:sendAlert')
end)

RegisterNetEvent(EVT .. 'server:clearAlert', function(alertId)
    local src = validSource(source)
    if not src or type(alertId) ~= 'string' then return end
    if rateLimited(src, 'panel') then return end
    if not requirePerm(src, 'clear', 'event:clearAlert') then return end
    local ok = A.End(alertId, 'cleared', src)
    reply(src, ok, ok and _L('ok_cleared') or _L('err_alert_not_found'))
end)

RegisterNetEvent(EVT .. 'server:requestSync', function()
    local src = validSource(source)
    if not src then return end
    if P.RateLimit(src, 'sync', Config.RateLimit.sync.max, Config.RateLimit.sync.window) == false then return end
    A.SyncPlayer(src)
end)

RegisterNetEvent(EVT .. 'server:panelOpen', function()
    openPanel(source)
end)

RegisterNetEvent(EVT .. 'server:panelClose', function()
    local src = validSource(source)
    if src then S.panelViewers[src] = nil end
end)

-- ═════════════ إجراءات اللوحة ═════════════
local PanelActions = {}

PanelActions.refresh = function(src)
    if not requirePerm(src, 'panel', 'panel_refresh') then return end
    S.panelViewers[src] = true
    QSA.PushPanel(src)
end

PanelActions.create = function(src, p)
    local data = {
        title = p.title, message = p.message, type = p.type,
        target = p.targetKind, radius = tonumber(p.radius),
        simulation = p.simulation == true,
    }
    local mins = tonumber(p.durationMin)
    if mins then data.duration = mins * 60 end
    if p.targetKind == 'custom' then
        data.target = 'region'
        data.coords = { x = p.x, y = p.y, z = p.z }
        data.regionLabel = p.label
    elseif p.targetKind == 'region' then
        data.region = p.region
    elseif p.targetKind == 'player' then
        data.player = p.player
    elseif p.targetKind == 'group' then
        data.group = p.group
    end
    local ok = userCreate(src, data, 'panel:create')
    return ok
end

PanelActions.clear = function(src, p)
    if not requirePerm(src, 'clear', 'panel:clear') then return false end
    if type(p.id) ~= 'string' then return false end
    local ok = A.End(p.id, 'cleared', src)
    reply(src, ok, ok and _L('ok_cleared') or _L('err_alert_not_found'))
    return ok
end

PanelActions.clearAll = function(src)
    if not requirePerm(src, 'clear', 'panel:clearAll') then return false end
    local n = A.ClearAll(src)
    reply(src, true, _L('ok_cleared_all', n))
    return true
end

PanelActions.update = function(src, p)
    if not requirePerm(src, 'edit', 'panel:update') then return false end
    if type(p.id) ~= 'string' then return false end
    local add = tonumber(p.addMinutes)
    local ok, err = A.Update(p.id, {
        title = p.title, message = p.message, addSeconds = add and add * 60 or nil,
    }, src, src)
    reply(src, ok, ok and _L('ok_updated') or errMsg(err))
    return ok
end

PanelActions.saveRegion = function(src, p)
    if not requirePerm(src, 'regions', 'panel:saveRegion') then return false end
    local ok, res = QSA.Regions.Upsert(p.oldName, { name = p.name, coords = { x = p.x, y = p.y, z = p.z }, radius = p.radius })
    if ok then QSA.Log('region', src, { action = p.oldName and 'update' or 'add', name = res.name }) end
    reply(src, ok, ok and _L('ok_region_saved') or errMsg(res))
    return ok
end

PanelActions.deleteRegion = function(src, p)
    if not requirePerm(src, 'regions', 'panel:deleteRegion') then return false end
    local ok, err = QSA.Regions.Delete(p.name)
    if ok then QSA.Log('region', src, { action = 'delete', name = tostring(p.name) }) end
    reply(src, ok, ok and _L('ok_region_deleted') or errMsg(err))
    return ok
end

PanelActions.resetRegions = function(src)
    if not requirePerm(src, 'regions', 'panel:resetRegions') then return false end
    QSA.Regions.Reset()
    QSA.Log('region', src, { action = 'reset' })
    reply(src, true, _L('ok_regions_reset'))
    return true
end

RegisterNetEvent(EVT .. 'server:panelAction', function(action, payload)
    local src = validSource(source)
    if not src or type(action) ~= 'string' then return end
    if type(payload) ~= 'table' then payload = {} end
    if rateLimited(src, 'panel') then return end
    local handler = PanelActions[action]
    if not handler then
        QSA.Log('unauthorized', src, { action = 'unknown_panel_action', value = action:sub(1, 40) })
        reply(src, false, _L('err_unknown_action'))
        return
    end
    local ok = handler(src, payload)
    TriggerClientEvent(EVT .. 'client:panelResult', src, { action = action, ok = ok == true })
    QSA.BroadcastPanel()
end)

AddEventHandler('playerDropped', function()
    local src = tonumber(source)
    if src then A.OnPlayerDropped(src) end
end)

-- ═════════════ الأوامر ═════════════
local function parseTarget(token)
    local lower = string.lower(token)
    if lower == 'all' or token == 'الجميع' then return { target = 'all' } end
    local id = lower:match('^id:(%d+)$') or lower:match('^player:(%d+)$')
    if id then return { target = 'player', player = tonumber(id) } end
    local group = token:match('^[gG][rR][oO][uU][pP]:(.+)$')
    if group then return { target = 'group', group = group } end
    return { target = 'region', region = token }
end

local function restOf(tokens, from)
    local parts = {}
    for i = from, #tokens do parts[#parts + 1] = tokens[i] end
    return table.concat(parts, ' ')
end

local function commandTokens(raw)
    local tokens = U.Tokenize(raw or '')
    table.remove(tokens, 1) -- اسم الأمر
    return tokens
end

-- /alert <target> <type> "message"
RegisterCommand('alert', function(source, _, raw)
    local src = tonumber(source) or 0
    local tokens = commandTokens(raw)
    if #tokens < 3 then return reply(src, false, _L('err_usage_alert')) end
    local data = parseTarget(tokens[1])
    data.type = tokens[2]
    data.message = restOf(tokens, 3)
    userCreate(src, data, 'command:alert')
end, false)

-- /sendalert <target> <type> "title" "message"
RegisterCommand('sendalert', function(source, _, raw)
    local src = tonumber(source) or 0
    local tokens = commandTokens(raw)
    if #tokens < 4 then return reply(src, false, _L('err_usage_sendalert')) end
    local data = parseTarget(tokens[1])
    data.type = tokens[2]
    data.title = tokens[3]
    data.message = restOf(tokens, 4)
    userCreate(src, data, 'command:sendalert')
end, false)

-- /simalert [type] [target]  -> إنذار محاكاة (افتراضياً للاعب نفسه)
RegisterCommand('simalert', function(source, args)
    local src = tonumber(source) or 0
    local data = {
        type = args[1] or 'information',
        title = _L('default_title'),
        message = _L('sim_message'),
        simulation = true,
    }
    if args[2] then
        for k, v in pairs(parseTarget(args[2])) do data[k] = v end
    elseif src > 0 then
        data.target, data.player = 'player', src
    else
        data.target = 'all'
    end
    userCreate(src, data, 'command:simalert')
end, false)

-- /alerttest [type] -> تنبيه تجريبي للاعب نفسه فقط (لا يُسجّل ولا يُحفظ)
RegisterCommand('alerttest', function(source, args)
    local src = tonumber(source) or 0
    if src == 0 then return reply(0, false, _L('err_in_game_only')) end
    if rateLimited(src, 'test') then return end
    if not requirePerm(src, 'panel', 'command:alerttest') then return end
    local atype = U.NormalizeType(args[1] or 'information') or 'information'
    local now = os.time()
    TriggerClientEvent(EVT .. 'client:receiveAlert', src, {
        id = ('QSA-TEST-%d-%d'):format(src, now), title = _L('test_title'), message = _L('test_message'),
        type = atype, region = _L('test_region'), simulation = true,
        created_at = now, expires_at = now + 30, ttl = 30,
    })
    reply(src, true, _L('ok_test'))
end, false)

-- /clearalerts [alertId]
RegisterCommand('clearalerts', function(source, args)
    local src = tonumber(source) or 0
    if not requirePerm(src, 'clear', 'command:clearalerts') then return end
    if rateLimited(src, 'panel') then return end
    if args[1] then
        local ok = A.End(tostring(args[1]), 'cleared', src)
        reply(src, ok, ok and _L('ok_cleared') or _L('err_alert_not_found'))
    else
        reply(src, true, _L('ok_cleared_all', A.ClearAll(src)))
    end
end, false)

-- /alertpanel -> لوحة التحكم
RegisterCommand('alertpanel', function(source)
    local src = tonumber(source) or 0
    if src == 0 then return reply(0, false, _L('err_in_game_only')) end
    openPanel(src)
end, false)

-- ═════════════ Exports (سيرفر) ═════════════
-- exports["qatar_secure_alert"]:SendAlert(data)             -> alertId | nil, errKey
-- exports["qatar_secure_alert"]:SendRegionAlert(region, data)-> alertId | nil, errKey
-- exports["qatar_secure_alert"]:ClearAlert(alertId)         -> boolean
-- exports["qatar_secure_alert"]:GetActiveAlerts()           -> array
-- exports["qatar_secure_alert"]:IsPlayerInAlertZone(playerId) -> boolean, alertId|nil
exports('SendAlert', function(data)
    local resource = GetInvokingResource() or 'server'
    local sender = (type(data) == 'table' and type(data.sender) == 'string' and data.sender ~= '') and data.sender or ('resource:' .. resource)
    local alert, count = A.Create(data, { trusted = true, sender = sender:sub(1, 100) })
    if not alert then return nil, count end
    return alert.id
end)

exports('SendRegionAlert', function(region, data)
    if type(data) ~= 'table' then return nil, 'invalid_data' end
    local copy = {}
    for k, v in pairs(data) do copy[k] = v end
    copy.region = region
    copy.target = 'region'
    local resource = GetInvokingResource() or 'server'
    local sender = (type(copy.sender) == 'string' and copy.sender ~= '') and copy.sender or ('resource:' .. resource)
    local alert, count = A.Create(copy, { trusted = true, sender = sender:sub(1, 100) })
    if not alert then return nil, count end
    return alert.id
end)

exports('ClearAlert', function(alertId)
    if type(alertId) ~= 'string' then return false end
    return A.End(alertId, 'cleared', 'resource:' .. (GetInvokingResource() or 'server'))
end)

exports('GetActiveAlerts', function()
    return A.GetActiveList(true)
end)

exports('IsPlayerInAlertZone', function(playerId)
    return A.IsPlayerInAlertZone(playerId)
end)

-- ═════════════ التشغيل ═════════════
local function startup()
    QSA.Regions.Load()
    QSA.DB.Init(function(enabled)
        A.LoadFromDB(function()
            print(('[qatar_secure_alert] started | framework=%s | simulation=%s | database=%s | regions=%d | active=%d'):format(
                P.FrameworkName(), tostring(Config.SimulationMode), tostring(enabled), #QSA.Regions.List(), countActive()))
        end)
    end)
end

AddEventHandler('onResourceStart', function(res)
    if res == GetCurrentResourceName() then
        math.randomseed(os.time())
        startup()
    elseif res == ((Config.Database or {}).resource or 'oxmysql') and not QSA.DB.enabled then
        -- oxmysql بدأ بعدنا
        QSA.DB.Init(function(enabled)
            if enabled then A.LoadFromDB() end
        end)
    end
end)
